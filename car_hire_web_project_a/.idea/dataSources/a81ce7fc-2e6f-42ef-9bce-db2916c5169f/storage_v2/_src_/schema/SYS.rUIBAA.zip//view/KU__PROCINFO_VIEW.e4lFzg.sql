create view KU$_PROCINFO_VIEW as
  select
  obj#,
  procedure#,
  overload#,
  procedurename,
  properties,
  itypeobj#,
  spare1,
  spare2,
  spare3,
  spare4
  from procedureinfo$
/

