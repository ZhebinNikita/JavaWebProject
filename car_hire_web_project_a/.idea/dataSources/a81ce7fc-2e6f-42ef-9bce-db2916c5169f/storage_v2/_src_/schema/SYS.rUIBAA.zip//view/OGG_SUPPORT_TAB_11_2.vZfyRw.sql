create view OGG_SUPPORT_TAB_11_2 as
  select u.name owner, o.name name, o.type#, o.obj#,
 (case
  /* INTERNAL - The following are tables that are system maintained */
  when ( exists (select 1 from system.logstdby$skip_support s
                 where s.name = u.name and action = 0))
    or bitand(o.flags,
                2                                       /* temporary object */
              + 16                                      /* secondary object */
              + 32                                  /* in-memory temp table */
              + 128                           /* dropped table (RecycleBin) */
             ) != 0
    or bitand(t.flags,
                134217728  /* 0x08000000          in-memory temporary table */
              + 536870912  /* 0x20000000  Mapping Tab for Phys rowid of IOT */
             ) != 0
    or bitand(t.property,
                512        /* 0x00000200               iot OVeRflow segment */
              + 8192       /* 0x00002000                       nested table */
              + 4194304    /* 0x00400000             global temporary table */
              + 8388608    /* 0x00800000   session-specific temporary table */
              + 134217728  /* 0x08000000                    Is a Sub object */
              + 2147483648 /* 0x80000000                     eXternal TaBle */
              + 4294967296 /* 0x100000000                              Cube */
              + 8589934592 /* 0x200000000                      FBA Internal */
             ) != 0
    or bitand(t.trigflag,
                536870912  /* 0x20000000                  DDLs autofiltered */
               ) != 0
    or exists (select 1 from sys.secobj$ so           /* ODCI storage table */
               where o.obj# = so.secobj#)
    or exists (select 1 from sys.opqtype$ opq       /* XML OR storage table */
               where o.obj# = opq.obj#
                 and bitand(opq.flags, 32) = 32)
  then -1
  ----------------------------------------------
  /* SUPPORT_MODE "NONE" */
  when exists (
    select 1 from sys.col$ c
             where t.obj# = c.obj#
             /* table doesnt have at least one scalar column */
             and ((c.type# in (8,24,58,112,113,114,115,121,123)
                  or bitand(c.property, 128) = 128)
             and (bitand(t.property, 1) = 0          /* not a typed table or */
             and 0 = (select count(*) from sys.col$ c2
               where t.obj# = c2.obj#
               and bitand(c2.property, 32)  != 32              /* Not hidden */
               and bitand(c2.property, 8)   != 8              /* Not virtual */
               and bitand(c2.property, 128) != 128      /* not stored in lob */
               and (c2.type# in ( 1,                             /* VARCHAR2 */
                                  2,                               /* NUMBER */
                                  12,                                /* DATE */
                                  23,                                 /* RAW */
                                  96,                                /* CHAR */
                                  100,                       /* BINARY FLOAT */
                                  101,                      /* BINARY DOUBLE */
                                  180,                     /* TIMESTAMP (..) */
                                  181,       /* TIMESTAMP(..) WITH TIME ZONE */
                                  182,         /* INTERVAL YEAR(..) TO MONTH */
                                  183,     /* INTERVAL DAY(..) TO SECOND(..) */
                                  231) /* TIMESTAMP(..) WITH LOCAL TIME ZONE */
                )))))
    or bitand(t.property, 131072) != 0                    /* AQ queue tables */
  then 3
  --------------------------------------
  /* SUPPORT_MODE "ID KEY" */
  when (bitand(t.property, 1 ) = 1    /* 0x00000001             typed table */
        AND not exists          /* Only XML/CLOB Typed Tables Are Supported */
          (select 1
             from  sys.col$ cc, sys.opqtype$ opq
             where cc.name = 'SYS_NC_ROWINFO$' and cc.type# = 58 and
                   opq.obj# = cc.obj# and opq.intcol# = cc.intcol# and
                   opq.type = 1 and cc.obj# = t.obj#
                   and bitand(opq.flags,4) = 4             /* stored as lob */
                   and bitand(opq.flags,64) = 0     /* not stored as binary */
                   and bitand(opq.flags,512) = 0))     /* not hierarch enab */
    or bitand(t.property,
             /* This clause is only for performance; they could be
                excluded by the column datatype checks below */
                  4        /* 0x00000004           has nested-TABLE columns */
                + 8        /* 0x00000008                    has REF columns */
               + 16        /* 0x00000010                  has array columns */
             ) != 0
             -----------------------------------------
             /* unsupp view joins col$, here we subquery it */
    or exists (select 1 from sys.col$ c
               where t.obj# = c.obj#
             -----------------------------------------
             /*  ignore any hidden columns in this subquery */
               and bitand(c.property, 32) != 32                /* Not hidden */
             -----------------------------------------
             /* table has an unsupported datatype */
               and ((c.type# not in (
                                  1,                             /* VARCHAR2 */
                                  2,                               /* NUMBER */
                                  8,                                 /* LONG */
                                  12,                                /* DATE */
                                  24,                            /* LONG RAW */
                                  96,                                /* CHAR */
                                  100,                       /* BINARY FLOAT */
                                  101,                      /* BINARY DOUBLE */
                                  112,                     /* CLOB and NCLOB */
                                  113,                               /* BLOB */
                                  114,                              /* BFILE */
                                  115,                              /* CFILE */
                                  180,                     /* TIMESTAMP (..) */
                                  181,       /* TIMESTAMP(..) WITH TIME ZONE */
                                  182,         /* INTERVAL YEAR(..) TO MONTH */
                                  183,     /* INTERVAL DAY(..) TO SECOND(..) */
                                  231) /* TIMESTAMP(..) WITH LOCAL TIME ZONE */
                  and (c.type# != 23                      /* RAW not RAW OID */
                  or (c.type# = 23 and bitand(c.property, 2) = 2))
                  and (c.type# != 58                               /* OPAQUE */
                  or (c.type# = 58                        /* XMLTYPE as CLOB */
                      and not exists (select 1 from opqtype$ opq
                                       where opq.type=1
                                         and bitand(opq.flags, 4) = 4
                                         and bitand(opq.flags,64) = 0
                                         and bitand(opq.flags,512) = 0
                                         and opq.obj#=c.obj#
                                         and opq.intcol#=c.intcol#))))
             -----------------------------------------
             /* table has a dedup securefile column */
             or  (c.type# in (112, 113)
             and exists (select 1 from logstdby_support_11lob lb
                          where lb.obj# = o.obj#
                            and lb.col# = c.col#
                            and lb.dedupsecurefile = 1)))
             ) /* end col$ exists subquery */
  then 0
  ----------------------------------------------
  /* SUPPORT_MODE "FULL" */
  else 1 end) gensby
  from sys.obj$ o, sys.user$ u, sys.tab$ t
  where o.owner# = u.user#
  and o.obj# = t.obj#
/

