create view KU$_TAB_COMPART_VIEW as
  select tcp.obj#, value(o), tcp.dataobj#, tcp.bo#,
         dbms_metadata.get_partn(2,tcp.bo#,tcp.part#),
         tcp.hiboundlen,
         sys.dbms_metadata_util.long2varchar(tcp.hiboundlen,
                                    'SYS.TABCOMPART$',
                                    'HIBOUNDVAL',
                                    tcp.rowid),
         cast( multiset(select * from ku$_ilm_policy_view p
                                 where p.obj_num = tcp.obj#
                                 order by p.policy_num
                                  ) as ku$_ilm_policy_list_t
             ),
         tcp.subpartcnt,
         sys.dbms_metadata.check_match_template_par(tcp.obj#, tcp.subpartcnt),
         cast(multiset(select * from ku$_tab_subpart_view tsp
                       where tsp.pobj_num = tcp.obj#
                       order by tsp.subpart_num
                      ) as ku$_tab_subpart_list_t
                  ),
         sys.dbms_metadata.check_match_template_lob(tcp.obj#, tcp.subpartcnt),
         cast(multiset(select * from ku$_lobcomppart_view lc
                       where lc.part_obj_num = tcp.obj#
                        order by lc.intcol_num
                      ) as ku$_lobcomppart_list_t
                  ),
         tcp.flags, ts.name, ts.blocksize,
         tcp.defpctfree, tcp.defpctused, tcp.definitrans,
         tcp.defmaxtrans, tcp.definiexts, tcp.defextsize, tcp.defminexts,
         tcp.defmaxexts, tcp.defextpct, tcp.deflists, tcp.defgroups,
         tcp.deflogging, tcp.defbufpool, to_char(tcp.analyzetime,'YYYY/MM/DD HH24:MI:SS'), tcp.samplesize,
         tcp.rowcnt, tcp.blkcnt, tcp.empcnt, tcp.avgspc, tcp.chncnt,
         tcp.avgrln, tcp.spare1,
         -- Convert 'spare2' to a value that the pre-11.2 xsl stylesheet
         -- can process: if archive compressed and version < 11.2,
         -- turn off compression.  The block format for archive compression
         -- is not supported pre-11.2, so the compression bits must be
         -- set to NOCOMPRESS.
         case when bitand(tcp.spare2,8+16+32+64)=0 then tcp.spare2
              when dbms_metadata.get_version >= '11.02.00.00.00'
                   then tcp.spare2
              else 2
         end,
         tcp.spare3, tcp.defmaxsize,
         tcp.bhiboundval,
         (select svcname  from imsvc$ svc
                 where svc.obj# = tcp.obj# and svc.subpart# is null),
         (select svcflags from imsvc$ svc
                 where svc.obj# = tcp.obj# and svc.subpart# is null)
  from ku$_schemaobj_view o, tabcompart$ tcp, ts$ ts
  where tcp.obj# = o.obj_num
        AND tcp.defts# = ts.ts#
/

