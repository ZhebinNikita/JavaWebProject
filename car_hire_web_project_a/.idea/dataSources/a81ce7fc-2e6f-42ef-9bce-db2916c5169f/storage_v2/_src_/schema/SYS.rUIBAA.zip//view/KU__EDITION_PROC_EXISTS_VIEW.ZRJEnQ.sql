create view KU$_EDITION_PROC_EXISTS_VIEW as
  select oo.obj#, o.owner_name, oo.type#
  from  sys.ku$_edition_schemaobj_view o, sys.ku$_edition_obj_view oo
  where (oo.type# = 7 or oo.type# = 8 or oo.type# = 9 or oo.type# = 11)
    and oo.obj#  = o.obj_num and oo.linkname is NULL
 and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (oo.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

