create view KU$_11_2_SYSGRANT_VIEW as
  select * from ku$_sysgrant_view t
  where t.privilege >  -351
/

