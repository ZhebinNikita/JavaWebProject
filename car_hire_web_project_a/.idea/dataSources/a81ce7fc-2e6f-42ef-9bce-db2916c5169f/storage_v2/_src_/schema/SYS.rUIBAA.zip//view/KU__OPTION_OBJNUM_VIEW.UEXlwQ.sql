create view KU$_OPTION_OBJNUM_VIEW as
  select o.obj_num, 'T', value(o),i.tgt_type, i.flags, i.tag,
         i.beginning_tgt_version, i.ending_tgt_version,
         i.alt_name, i.alt_schema
  from ku$_expreg i, ku$_schemaobj_view o
  where ((bitand(i.flags,1)=0 and
          o.name=i.tgt_object and
          (bitand(i.flags,8)=0)) or
         (bitand(i.flags,1)=1 and
          o.name like i.tgt_object and
           -- check for excluded object
          (select count(*)
           from ku$_expreg xi
           where (bitand(xi.flags,8)=8)
                 and i.tgt_schema = xi.tgt_schema
                 and xi.tgt_object = o.name) = 0 ))
    AND o.owner_name=i.tgt_schema
    AND i.tgt_type=o.type_num
/

