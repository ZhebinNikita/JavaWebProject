create view CDB_CUBE_ATTR_UNIQUE_KEYS as
  SELECT k."OWNER",k."DIMENSION_NAME",k."ATTRIBUTE_NAME",k."UNIQUE_KEY_LEVEL_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_CUBE_ATTR_UNIQUE_KEYS") k
/

comment on table CDB_CUBE_ATTR_UNIQUE_KEYS
is 'OLAP Unique Key Attributes in the database in all containers'
/

