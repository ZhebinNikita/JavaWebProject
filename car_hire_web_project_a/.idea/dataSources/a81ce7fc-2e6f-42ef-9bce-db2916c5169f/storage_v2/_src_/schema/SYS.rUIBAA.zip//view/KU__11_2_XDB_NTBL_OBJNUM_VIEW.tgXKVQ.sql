create view KU$_11_2_XDB_NTBL_OBJNUM_VIEW as
  select t.* from ku$_xdb_ntable_objnum_view t
  where bitand(t.property2,2097152)=0
/

