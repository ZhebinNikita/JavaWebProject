create view KU$_SIMPLE_COL_VIEW as
  select c.obj#,
         c.col#,
         c.intcol#,
         c.segcol#,
         bitand(c.property, 4294967295),
         trunc(c.property / power(2,32)),
         c.name,
         case
          when c.type#=123 or c.type#=122 or c.type#=112
          then sys.dbms_metadata_util.get_fullattrname(
                        c.obj#, c.col#, c.intcol#, c.type#)
          else sys.dbms_metadata_util.get_attrname(
                        c.obj#, c.intcol#)
         end,
         c.type#,
         c.deflength,
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
                or c.deflength > 4000
           then null
           else
             sys.dbms_metadata_util.func_index_default(c.deflength,
                                                       c.rowid)
         end,
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
                or c.deflength <= 4000
           then null
           when c.deflength <= 32000
           then
             sys.dbms_metadata_util.func_index_defaultc(c.deflength,
                                                        c.rowid)
           else
             sys.dbms_metadata_util.long2clob(c.deflength,
                                              'SYS.COL$',
                                              'DEFAULT$',
                                              c.rowid)
         end,
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
           then null
           else
            (select sys.dbms_metadata.parse_default(u.name,o.name,
                                                    c.deflength,c.rowid)
             from obj$ o, user$ u
             where o.obj#=c.obj# and o.owner#=u.user#)
         end
  from col$ c
/

