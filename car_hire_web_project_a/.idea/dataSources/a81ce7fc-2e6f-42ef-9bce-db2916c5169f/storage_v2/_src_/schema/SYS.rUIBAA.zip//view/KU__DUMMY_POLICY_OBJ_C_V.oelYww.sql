create view KU$_DUMMY_POLICY_OBJ_C_V as
  select '0','0',NULL
    from dual
   where 1=0      -- return 0 rows
/

