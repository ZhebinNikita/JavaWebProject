create view KU$_XMLSCHEMA_TYPES_VIEW as
  select t.tabobj_num tabobjno, typo.obj_num typeobjno,
         st.typname typename, st.typowner typeowner
  from (
      select c.xmldata.sqltype typname,
             c.xmldata.sqlschema typowner,
             (select s.sys_nc_oid$ from xdb.xdb$schema s
              where ref(s)=c.xmldata.parent_schema) tschemaoid
      from xdb.xdb$complex_type c
      union
      select e.xmldata.property.sqlcolltype typname,
             e.xmldata.property.sqlcollschema typowner,
             (select s.sys_nc_oid$ from xdb.xdb$schema s
              where ref(s)=e.xmldata.property.parent_schema) tschemaoid
      from xdb.xdb$element e
      where
        not exists (select 1
          from xdb.xdb$element e2
          where e2.xmldata.property.sqlcolltype = e.xmldata.property.sqlcolltype
                and e2.xmldata.property.sqlcollschema =
                     e.xmldata.property.sqlcollschema
                and e2.xmldata.property.parent_schema <>
                     e.xmldata.property.parent_schema) ) st,
    ku$_schemaobj_view typo, ku$_table_xmlschema_view t
  where st.typname is not null and
        st.typowner is not null and
        ((st.typowner <> 'XDB') or
         ((st.typname not like 'XDB$%%') and (st.typname <> 'XMLTYPE'))) and
        typo.name=st.typname and typo.owner_name=st.typowner and
        t.schemaoid=tschemaoid
/

