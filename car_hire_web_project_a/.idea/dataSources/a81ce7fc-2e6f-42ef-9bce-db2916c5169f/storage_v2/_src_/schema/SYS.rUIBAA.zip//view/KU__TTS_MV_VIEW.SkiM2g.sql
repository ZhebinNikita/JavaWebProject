create view KU$_TTS_MV_VIEW as
  select o.owner#, t.obj#, ts.name              -- unpartitioned heap tables
  from   sys.obj$ o, sys.tab$ t, sys.user$ u, sys.snap$ s, sys.ts$ ts
  where  s.sowner = u.name
  and    s.tname  = o.name
  and    o.owner# = u.user#
  and    o.type#  = 2
  and    o.obj#   = t.obj#
  and    t.ts#    = ts.ts#
  and    bitand(t.property, 32+64+512) = 0
 UNION ALL
  select o.owner#, t.obj#, ts.name              -- simple partitions
  from   sys.obj$ o, sys.tab$ t, sys.tabpart$ tp,
         sys.user$ u, sys.snap$ s, sys.ts$ ts
  where  s.sowner = u.name
  and    s.tname  = o.name
  and    o.owner# = u.user#
  and    o.type#  = 2
  and    o.obj#   = t.obj#
  and    bitand(t.property, 32+64+512) = 32
  and    t.obj#   = tp.bo#
  and    tp.ts#   = ts.ts#
 UNION ALL
  select o.owner#, t.obj#, ts.name              -- composite partitions
  from   sys.obj$ o, sys.tab$ t,
         sys.tabcompart$ tcp, sys.tabsubpart$ tsp,
         sys.user$ u, sys.snap$ s, sys.ts$ ts
  where  s.sowner = u.name
  and    s.tname  = o.name
  and    o.owner# = u.user#
  and    o.type#  = 2
  and    o.obj#   = t.obj#
  and    bitand(t.property, 32+64+512) = 32
  and    t.obj#   = tcp.bo#
  and    tcp.obj# = tsp.pobj#
  and    tsp.ts#  = ts.ts#
 UNION ALL
  select o.owner#, t.obj#, ts.name              -- IOTs
  from   sys.obj$ o, sys.tab$ t, sys.ind$ i,
         sys.user$ u, sys.snap$ s, sys.ts$ ts
  where  s.sowner = u.name
  and    s.tname  = o.name
  and    o.owner# = u.user#
  and    o.type#  = 2
  and    o.obj#   = t.obj#
  and    bitand(t.property, 32+64+512) = 64
  and    i.ts#    = ts.ts#
  and    i.obj#   = t.pctused$
 UNION ALL
  select o.owner#, t.obj#, ts.name              -- PIOTs
  from   sys.obj$ o, sys.tab$ t, sys.indpart$ ip,
         sys.user$ u, sys.snap$ s, sys.ts$ ts
  where  s.sowner = u.name
  and    s.tname  = o.name
  and    o.owner# = u.user#
  and    o.type#  = 2
  and    o.obj#   = t.obj#
  and    bitand(t.property, 32+64+512) = 32 + 64
  and    ip.ts#   = ts.ts#
  and    ip.bo#   = t.pctused$
/

