create view KU$_SUBLOBFRAG_VIEW as
  select lf.fragobj#, null, l.intcol#,
        (select value(o) from ku$_schemaobj_view o
         where o.obj_num = lf.fragobj#),
        (select value(s) from ku$_storage_view s
         where s.file_num  = lf.file#
         and   s.block_num = lf.block#
         and   s.ts_num    = lf.ts#),
        (select value(s) from ku$_deferred_stg_view s
         where s.obj_num = lf.fragobj#),
        (select ts.name from ts$ ts where lf.ts# = ts.ts#),
        (select ts.blocksize from ts$ ts where lf.ts# = ts.ts#),
        lf.indfragobj#,
        (select value(i) from ku$_sublobfragindex_view i
                 where i.obj_num=lf.indfragobj#),
        lf.chunk, lf.pctversion$, lf.fragflags, lf.fragpro,
        null, null, lf.spare1, lf.spare2, to_char(lf.spare3),
  /* attributes only for lobfarg (partitioned) */
        lf.parentobj#, lf.tabfragobj#, l.obj#, lf.frag#
  from  lob$ l, lobcomppart$ lc, lobfrag$ lf
        where lc.partobj#=lf.parentobj#
          and l.lobj#=lc.lobj#
/

