create view LOGSTDBY_SUPPORT_SEQ as
  select u.name owner, o.name name, o.type#, o.obj#,
         decode(bitand(s.flags, 8), 8, 1, 0) current_sby,
         decode(bitand(s.flags, 1024), 1024, -1,
           nvl((select 2 from system.logstdby$skip_support s3
                where s3.name = u.name and s3.name2 = o.name
                  and s3.action = -2),
               nvl((select 0 from system.logstdby$skip_support s2
                    where s2.name = u.name and action = 0), 1))) gensby
  from obj$ o, user$ u, seq$ s
  where o.owner# = u.user#
  and o.obj# = s.obj#
/

