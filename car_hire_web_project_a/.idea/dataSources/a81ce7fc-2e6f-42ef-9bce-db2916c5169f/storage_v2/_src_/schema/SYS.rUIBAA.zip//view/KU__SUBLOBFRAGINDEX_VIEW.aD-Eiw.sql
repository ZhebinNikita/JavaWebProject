create view KU$_SUBLOBFRAGINDEX_VIEW as
  select i.obj#, value(o),
         ts.name, ts.blocksize,
         (select value(s) from ku$_storage_view s
          where i.file#  = s.file_num
          and   i.block# = s.block_num
          and   i.ts#    = s.ts_num),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = i.obj#),
         i.dataobj#, null,
         i.pctfree$, i.initrans, i.maxtrans, null, null, i.flags, null,
         i.blevel, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac,
         to_char(i.analyzetime,'YYYY/MM/DD HH24:MI:SS'), i.samplesize, i.rowcnt,
         null, null, null, null,
         i.spare1, i.spare2, i.spare3,
         null, null, null,   /* spare4, spare5, spare6 */
         i.pobj#,
         dbms_metadata.get_partn(6,i.pobj#,i.subpart#),
         null
   from  ku$_schemaobj_view o, indsubpart$ i, ts$ ts
   where o.obj_num = i.obj#
         AND  i.ts# = ts.ts#
/

