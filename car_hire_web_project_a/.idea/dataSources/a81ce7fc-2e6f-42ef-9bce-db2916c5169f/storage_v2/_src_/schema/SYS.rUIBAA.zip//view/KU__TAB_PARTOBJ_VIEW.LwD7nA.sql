create view KU$_TAB_PARTOBJ_VIEW as
  select po.obj_num, value(po),
         cast(multiset(select * from ku$_tab_part_col_view pc
                       where pc.obj_num = po.obj_num
                        order by pc.pos_num
                      ) as ku$_part_col_list_t
             ),
         cast(multiset(select * from ku$_tab_subpart_col_view sc
                       where sc.obj_num = po.obj_num
                        order by sc.pos_num
                      ) as ku$_part_col_list_t
             ),
         cast(multiset(select * from ku$_tab_part_view tp
                       where tp.base_obj_num = po.obj_num
                        order by tp.part_num
                      ) as ku$_tab_part_list_t
             ),
         cast(multiset(select * from ku$_tab_compart_view tcp
                       where tcp.base_obj_num = po.obj_num
                        order by tcp.part_num
                      ) as ku$_tab_compart_list_t
             ),
         cast(multiset(select * from ku$_tab_tsubpart_view ttsp
                       where ttsp.base_objnum = po.obj_num
                        order by ttsp.spart_pos
                      ) as ku$_tab_tsubpart_list_t
             )
  from ku$_partobj_view po
/

