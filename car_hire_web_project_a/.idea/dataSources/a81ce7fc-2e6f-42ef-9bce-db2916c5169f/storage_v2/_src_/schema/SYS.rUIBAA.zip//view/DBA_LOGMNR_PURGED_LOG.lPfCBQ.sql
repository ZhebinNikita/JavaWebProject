create view DBA_LOGMNR_PURGED_LOG as
  select distinct p.file_name from system.logmnr_log$ p
    where bitand(p.status, 2) = 2 and
    dbms_logmnr_internal.logmnr_krvicl(p.file_name) = 1 and
    (flags IS NULL or bitand(flags, 16) != 16)
  minus
  select distinct q.file_name from system.logmnr_log$ q
    where bitand(q.status, 2) <> 2
/

