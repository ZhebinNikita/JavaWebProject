create view KU$_SEQ_IN_DEFAULT_VIEW as
  select unique c.obj#
 from sys.obj$ o, sys.col$ c
 where bitand(trunc(c.property / power(2,32)),8) != 0
 and o.obj#=c.obj#
 and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

