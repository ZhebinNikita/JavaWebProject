create view KU$_TTS_VIEW as
  select o.owner#, t.obj#, ts.name              -- unpartitioned heap tables
  from   sys.obj$ o, sys.tab$ t, sys.ts$ ts
  where  t.ts#  = ts.ts#
  and    o.obj# = t.obj#
  and    bitand(t.property, 32+64+512) = 0
 UNION ALL
  select o.owner#, t.obj#, ts.name              -- simple partitions
  from   sys.obj$ o, sys.tab$ t, sys.tabpart$ tp, sys.ts$ ts
  where  tp.ts# = ts.ts#
  and    t.obj# = tp.bo#
  and    o.obj# = t.obj#
  and    bitand(t.property, 32+64+512) = 32
 UNION ALL
  select o.owner#, t.obj#, ts.name              -- composite partitions
  from   sys.obj$ o, sys.tab$ t,
         sys.tabcompart$ tcp, sys.tabsubpart$ tsp, sys.ts$ ts
  where  tsp.ts#  = ts.ts#
  and    tcp.obj# = tsp.pobj#
  and    t.obj#   = tcp.bo#
  and    o.obj# = t.obj#
  and    bitand(t.property, 32+64+512) = 32
 UNION ALL
  select o.owner#, t.obj#, ts.name              -- unpartitioned IOTs
  from   sys.obj$ o, sys.tab$ t, sys.ind$ i, sys.ts$ ts
  where  i.ts#    = ts.ts#
    and  i.obj#   = t.pctused$
  and    o.obj# = t.obj#
  and    bitand(t.property, 32+64+512) = 64
 UNION ALL
  select o.owner#, t.obj#, ts.name              -- PIOTs
  from   sys.obj$ o, sys.tab$ t, sys.indpart$ ip, sys.ts$ ts
  where  ip.ts#   = ts.ts#
    and  ip.bo#   = t.pctused$
  and    o.obj# = t.obj#
  and    bitand(t.property, 32+64+512) = 32 + 64
/

