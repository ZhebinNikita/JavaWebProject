create view KU$_10_1_FHTABLE_VIEW as
  select t.* from ku$_fhtable_view t
  where bitand(t.trigflag,65536+131072)=0
/

