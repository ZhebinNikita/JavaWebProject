create view KU$_IND_PART_COL_VIEW as
  select pc.obj#, pc.intcol#, value(c), pc.pos#, pc.spare1
  from ku$_simple_col_view c, ind$ i, partcol$ pc
  where   pc.obj#=i.obj#
  and     i.bo#=c.obj_num
  and     pc.intcol#=c.intcol_num
/

