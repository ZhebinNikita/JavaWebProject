create view CDB_LOGSTDBY_EDS_SUPPORTED as
  SELECT k."OWNER",k."TABLE_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_EDS_SUPPORTED") k
/

comment on table CDB_LOGSTDBY_EDS_SUPPORTED
is 'List of all tables that could have EDS-based replication for Logical Standby in all containers'
/

