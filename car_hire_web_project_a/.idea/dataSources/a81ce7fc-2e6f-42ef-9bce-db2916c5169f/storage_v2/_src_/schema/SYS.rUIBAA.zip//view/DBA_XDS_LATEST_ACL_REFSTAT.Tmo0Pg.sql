create view DBA_XDS_LATEST_ACL_REFSTAT as
  select
  a.schema_name,
  a.table_name,
  a.refresh_mode,
  a.refresh_ability,
  s.job_start_time,
  s.job_end_time,
  s.row_update_count,
  s.status,
  s.error_message
  from sys.aclmv$_base_view a, sys.aclmvrefstat$ s
where a.acl_mview_obj# = s.acl_mview_obj#
  and s.job_end_time =  (select max(r.job_end_time) as job_end_time
                         from sys.aclmvrefstat$ r
                         where r.acl_mview_obj# = s.acl_mview_obj#)
/

