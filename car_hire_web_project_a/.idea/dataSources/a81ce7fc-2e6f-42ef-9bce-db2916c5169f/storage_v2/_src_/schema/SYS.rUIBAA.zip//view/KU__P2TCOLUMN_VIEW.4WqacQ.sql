create view KU$_P2TCOLUMN_VIEW as
  select *
 from ku$_p2tpartcol_view c
UNION ALL
 select *
 from ku$_column_view c
 where not (c.type_num in (112,113,123,58)
            or (c.type_num in (1,23) and  bitand(c.property,128)!=0))

/

