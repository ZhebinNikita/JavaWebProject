create view KU$_TAB_SUBPART_VIEW as
  select tsp.obj#, value(o),
         ts.name, ts.blocksize,
         (select value(s) from ku$_storage_view s
          where tsp.file#  = s.file_num
          and   tsp.block# = s.block_num
          and   tsp.ts#    = s.ts_num),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = tsp.obj#),
         tsp.dataobj#,
         tsp.pobj#,
         dbms_metadata.get_partn(3,tsp.pobj#,tsp.subpart#),
         cast(multiset(select * from ku$_sublobfrag_view lf
                        where lf.part_obj_num=tsp.obj#
                        order by lf.intcol_num
                      ) as ku$_lobfrag_list_t
             ),
         cast( multiset(select * from ku$_ilm_policy_view p
                        where p.obj_num = tsp.obj#
                        order by p.policy_num
                        ) as ku$_ilm_policy_list_t
              ),
         tsp.flags, tsp.pctfree$, tsp.pctused$,
         tsp.initrans, tsp.maxtrans,
         to_char(tsp.analyzetime,'YYYY/MM/DD HH24:MI:SS'), tsp.samplesize,
         tsp.rowcnt, tsp.blkcnt, tsp.empcnt, tsp.avgspc, tsp.chncnt,
         tsp.avgrln, tsp.spare1, tsp.spare2, tsp.spare3, tsp.hiboundlen,
         sys.dbms_metadata_util.long2varchar(tsp.hiboundlen,
                                    'SYS.TABSUBPART$',
                                    'HIBOUNDVAL',
                                     tsp.rowid),
         tsp.bhiboundval,
         tsp.subpart#,   -- <<< be carefull! 'physical' subpartition number
         (select svcname  from imsvc$ svc
                 where svc.obj# = tsp.obj# and svc.subpart# is null),
         (select svcflags from imsvc$ svc
                 where svc.obj# = tsp.obj# and svc.subpart# is null),
         (select value(etv) from ku$_exttab_view etv
                        where etv.obj_num = tsp.obj#)
  from ku$_schemaobj_view o, tabsubpart$ tsp, ts$ ts
  where tsp.obj# = o.obj_num
        AND tsp.ts# = ts.ts#
/

