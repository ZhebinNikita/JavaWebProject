create view DBA_LOGSTDBY_PLSQL_MAP as
  select name as owner, name2 as pkg_name, name3 as proc_name,
         name4 as internal_pkg_name, name5 as internal_proc_name
  from system.logstdby$skip_support
  where action = -3
  order by owner, pkg_name, proc_name, internal_pkg_name, internal_proc_name
/

comment on table DBA_LOGSTDBY_PLSQL_MAP
is 'PLSQL mapping from user invokable procedure to supp-log pragma-ed procedure'
/

