create view KU$_STORAGE_VIEW as
  select s.file#, s.block#, s.type#, s.ts#,
         dbms_metadata.in_tsnum(1,s.ts#),
         s.blocks, s.extents,
         s.iniexts, s.minexts, s.maxexts, s.extsize, s.extpct,
         s.user#,
-- SecureFiles use groups and lists for storing other information related
-- to RETENTION.  When we have a SecureFile column, the groups and
-- lists parameters need to be passed back as is.  However, if we
-- are attempting to import into a 10g compatible or earlier RDBMS via
-- DBLinks, then we need to interpret 0 as 1 for SecureFile because
-- the SecureFile will be created as a BasicFile, and in this case, the
-- groups and lists setting needs to be consistent with the BasicFile
-- behavior.  dbms_metadata.get_version tells us what version the
-- client in the DBLink is using as its compatible setting.
-- We can tell that the LOB segment is a SecureFile segment by looking
-- at seg$.spare1 bit 0x200000 (2097152 in decimal).
         case when dbms_metadata.get_version >= '11.00.00.00.00' then
                decode(bitand(s.spare1, 2097152), 2097152, s.lists,
                       (decode(s.lists, 0, 1, s.lists)))
              else
                decode(s.lists, 0, 1, s.lists)
         end,
         case when dbms_metadata.get_version >= '11.00.00.00.00' then
                decode(bitand(s.spare1, 2097152), 2097152, s.groups,
                       (decode(s.groups, 0, 1, s.groups)))
              else
                decode(s.groups, 0, 1, s.groups)
         end,
         decode(bitand(s.spare1, 4194304), 4194304, s.bitmapranges, NULL),
         case when dbms_metadata.get_version >= '11.02.00.00.00' then
                   s.cachehint
              else
                   decode(mod(s.cachehint,4),
                          1, 1,
                          2, 2,
                          0)
         end,
         s.scanhint, s.hwmincr,
         -- Convert 'flags' to a value that the pre-11.2 xsl stylesheet
         -- can process: if archive compressed and version < 11.2,
         -- turn off compression.  The block format for archive compression
         -- is not supported pre-11.2, so the compression bits must be
         -- set to NOCOMPRESS.
         -- (names defined in ktscts.h)
         -- #define KTSSEGM_FLAG_ARCH1 0x2000000  (33554432)
         -- #define KTSSEGM_FLAG_ARCH2 0x4000000  (67108864)
         -- #define KTSSEGM_FLAG_ARCH3 0x8000000 (134217728)
         -- #define KTSSEGM_FLAG_HCC_ROW_LOCKING 0x80000000 (2147483648)
         case when bitand(s.spare1,33554432+67108864+134217728+2147483648)=0
                   then s.spare1
              when dbms_metadata.get_version >= '11.02.00.00.00' then s.spare1
              else s.spare1
                 - bitand(s.spare1,2048+33554432+67108864+134217728+2147483648)
         end,
         trunc(s.spare1 / power(2,32)),
         s.spare2
  from seg$ s
/

