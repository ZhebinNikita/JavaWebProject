create view STRADDLING_TS_OBJECTS as
  SELECT t.obj#, t.ts#, l.lobj#, l.ts#,
         'Base table and lob object not fully contained in pluggable set', 1
  FROM   tab$ t, lob$ l
  WHERE  l.ts# != t.ts# AND l.obj# = t.obj# AND BITAND(t.property, 64) = 0
UNION ALL
  -- Report dependencies between objects in different tablespaces that are
  -- enforced through constraints.
  -- Exclude disabled constraints.
  -- Handle IOTs (property 0x40) and partitioned (property 0x20) tables
  --   whose tablespace # is always 0.
  -- Ignore when the second ts number is 2147483647. Stmt from George Eadon:
  --  "local partitioned indexes and reference partitioned tables that are
  --   created without an explicit object-level default tablespace. In these
  --   cases partitions in the object co-locate with the base table partition,
  --   by default."
  --    Local partitioned indexes is already done since about day 1 (8i).  This
  --    change is for ref partitioned child tables.
  SELECT t.obj#,
         decode(BITAND(t.property, 96), 0, t.ts#,
                32, (select po.defts# from partobj$ po where po.obj# = t.obj#),
                64, (select max(i.ts#) from ind$ i where i.bo# = t.obj#)),
         c.obj#,
         decode(BITAND(t2.property, 96), 0, t2.ts#,
                32, (select po.defts# from partobj$ po where po.obj# =t2.obj#),
                64, (select max(i.ts#) from ind$ i where i.bo# = t2.obj#)),
         'Constraint between tables not contained in pluggable set', 2
  FROM   tab$ t2, cdef$ c, tab$ t
  WHERE  c.robj# = t.obj# AND c.obj# = t2.obj# AND
         decode(BITAND(t.property, 96), 0, t.ts#,
                32, (select po.defts# from partobj$ po where po.obj# = t.obj#),
                64, (select max(i.ts#) from ind$ i where i.bo# = t.obj#)) !=
         decode(BITAND(t2.property, 96), 0, t2.ts#,
                32, (select po.defts# from partobj$ po where po.obj# =t2.obj#),
                64, (select max(i.ts#) from ind$ i where i.bo# = t2.obj#)) AND
         decode(BITAND(t2.property, 96), 0, t2.ts#,
                32, (select po.defts# from partobj$ po where po.obj# =t2.obj#),
                64, (select max(i.ts#) from ind$ i where i.bo# = t2.obj#)) !=
                2147483647 AND
         c.enabled IS NOT NULL
UNION ALL
  -- Report tables whose indexes are not in the same tablespace.
  -- Exclude partitioned objects , they are checked for separately.
  -- Exclude indexes on any unsupported TSPITR objects.
  -- Exclude indexes enforcing primary key constraints and unique constraints,
  --   these are checked for separately
  -- Exclude iots
  -- Exclude domain indexes, they are done separately
  SELECT t.obj#, t.ts#, i.obj#, i.ts#,
      'Tables and associated indexes not fully contained in the pluggable set',
         3
  FROM   tab$ t, ind$ i
  WHERE  t.obj# = i.bo# AND t.ts# != i.ts# AND BITAND(t.property, 32) = 0 AND
         BITAND(i.property, 2) = 0 AND BITAND(t.property, 131072) = 0 AND
         BITAND(t.property, 64) = 0 AND i.type# != 9
  MINUS
  -- Excluding indexes enforcing primary key constraints
  -- fix bug 860417  - exclude partitioned objects */
  --     bug 1167617 - exclude indexes enforcing unique key constraints
  SELECT t.obj#, t.ts#, i.obj#, i.ts#,
      'Tables and associated indexes not fully contained in the pluggable set',
         3
  FROM   tab$ t, ind$ i , cdef$ cf
  WHERE  t.obj# = cf.obj# AND i.obj# = cf.enabled AND cf.type# in( 2,3) AND
         t.ts# != i.ts# AND i.bo#=t.obj# AND BITAND(t.property, 32) = 0
UNION ALL
  -- Report any partitioned tables where the default ts is 0
  -- Bug 11682089: exclude global partitioned index enforcing primary key/
  --               unique key constraint on non-partitioned table.
  SELECT t.obj#, t.ts#, i.obj#, i.ts#,
         'Table and Index enforcing primary key/unique key constraint not in same tablespace',
         4
  FROM   tab$ t, ind$ i , cdef$ cf
  WHERE  t.obj# = cf.obj# AND i.obj# = cf.enabled AND cf.type# in (2,3) AND
         t.ts# != i.ts# AND i.bo#=t.obj# AND BITAND(t.property, 64) = 0 AND
         BITAND(t.property, 32) = 0 AND BITAND(i.property, 2) = 0
UNION ALL
  -- Report clusters whose indexes are not in the same tablespace
  SELECT c.obj#, c.ts#, i.obj#, i.ts#,
         'Tables/Clusters and associated indexes not fully contained in the pluggable set',
         5
  FROM   clu$ c, ind$ i
  WHERE  c.obj# = i.bo# AND c.ts# != i.ts#
UNION ALL
  -- Report partitioned tables with at least two partitions in different
  -- tablespaces
  SELECT tp1.obj#, tp1.ts#, tp.obj#, tp.ts#,
         'Partitioned Objects not fully contained in the pluggable set', 6
  FROM   tabpart$ tp,
         (SELECT  bo#,
                  min(ts#) keep (dense_rank first order by part#) ts#,
                  min(file#) keep (dense_rank first order by part#) file#,
                  min(block#) keep (dense_rank first order by part#) block#,
                  min(obj#) keep (dense_rank first order by part#) obj#
          FROM    tabpart$ tp2
          WHERE   (tp2.file# != 0 and tp2.block# != 0) OR
                  EXISTS (SELECT 1 FROM sys.deferred_stg$ ds2
                          WHERE ds2.obj# = tp2.obj#)
          GROUP BY bo#) tp1
  WHERE   tp1.bo# = tp.bo# AND tp1.ts# != tp.ts# AND
          ((tp.file# !=0 AND tp.block# != 0) OR
            EXISTS (SELECT 1 FROM sys.deferred_stg$ ds
                     WHERE ds.obj# = tp.obj#))
UNION ALL
  -- Report partitioned indexes that are in different tablespaces than any
  -- partition in the table.
  -- Exclude partitioned iots - no storage (check for null header)
  SELECT tp1.obj#, tp1.ts#, ip.obj#, ip.ts#,
         'Partitioned Objects not fully contained in the pluggable set', 7
  FROM   indpart$ ip, ind$ i,
         (SELECT bo#,
                 min(ts#) keep (dense_rank first order by part#) ts#,
                 min(file#) keep (dense_rank first order by part#) file#,
                 min(block#) keep (dense_rank first order by part#) block#,
                 min(obj#) keep (dense_rank first order by part#) obj#
          FROM   tabpart$ tp2
          WHERE  (tp2.file# != 0 AND tp2.block# != 0) OR
                  EXISTS (SELECT 1 FROM sys.deferred_stg$ ds2
                          WHERE ds2.obj# = tp2.obj#)
          GROUP BY bo#) tp1
  WHERE   tp1.bo# = i.bo# AND ip.bo# = i.obj# and tp1.ts# != ip.ts#
UNION ALL
  -- Report partitioned tables and non-partitioned index in different
  -- tablespaces
  -- Exclude domain indexes, they are done separately
  SELECT tp.obj#, tp.ts#, i.obj#, i.ts#,
         'Partitioned Objects not fully contained in the pluggable set', 8
  FROM   tabpart$ tp, ind$ i
  WHERE  tp.ts#! = i.ts# AND BITAND(i.property, 2) = 0 AND tp.bo# = i.bo# AND
         i.type# != 9
union all
  -- Report partitioned index and non-partitioned table in different
  -- tablespaces
  -- Exclude domain indexes, they are done separately
  SELECT t.obj#, t.ts#, ip.obj#, ip.ts#,
         'Partitioned Objects not fully contained in the pluggable set', 9
  FROM   indpart$ ip, tab$ t, ind$ i
  WHERE  ip.ts#! = t.ts# AND t.property = 0 AND ip.bo# = i.obj# AND
         i.bo# = t.obj# AND i.type# != 9
UNION ALL
  -- Reoprt objects that are not supported
  --   tab$.property - 0x20000 = AQs
  -- Look at objects that have storage Tables, IOTs, Partitions, Subpartitions
  --
  -- 8.0 compatible AQ with multiple recipients
  SELECT t.obj#, t.ts#, -1, -1 , 'Object not allowed in Pluggable Set', 10
  FROM   sys.dba_queue_Tables q, obj$ o, user$ u, tab$ t
  WHERE  q.recipients = 'MULTIPLE' AND SUBSTR(q.compatible, 1, 3) = '8.0' AND
         q.queue_table = o.name AND q.owner = u.name AND u.user# = o.owner# AND
         o.obj# = t.obj#
UNION ALL
  -- Report any Composite partitions/Subpartitions that are not in the same
  -- tablespace.  Check the tablespace of the first subpartition of partition 1
  -- against all tablespaces of other subpartitions for the same object
  SELECT v1.obj#, v1.ts#, v2.obj#, v2.ts#,
         'Subpartitions not fully contained in Transportable Set', 15
  FROM   (SELECT MIN(tsp.obj#) keep (dense_rank first
                 order by tcp.part#, tsp.subpart#) obj#,
                 MIN(tsp.ts#) keep (dense_rank first
                 order by tcp.part#, tsp.subpart#) ts#,
                 tcp.bo# bo#
          FROM   tabcompart$ tcp, tabsubpart$ tsp
          WHERE  tsp.pobj# = tcp.obj#
          GROUP BY tcp.bo#) v1,
         (SELECT tsp.obj#, ts#, tcp.bo#
          FROM   tabcompart$ tcp, tabsubpart$ tsp
          WHERE  tsp.pobj# = tcp.obj#) v2
  WHERE   v1.bo# = v2.bo# AND v1.ts# != v2.ts#
UNION ALL
  -- Report any composite table partitions and index composite partitions that
  -- are not in the same tablespace.
  SELECT v3.obj#, v3.ts#, v4.obj#, v4.ts#,
         'Table subpartition and index subpartition not fully contained in the Transportable Set',
         16
  FROM   (SELECT MIN(tsp.obj#) keep (dense_rank first
                 order by tcp.part#, tsp.subpart#) obj#,
                 MIN(tsp.ts#) keep (dense_rank first
                 order by tcp.part#, tsp.subpart#) ts#,
                 tcp.bo# bo#
          FROM   tabcompart$ tcp, tabsubpart$ tsp
          WHERE  tsp.pobj# = tcp.obj#
          GROUP BY tcp.bo#) v3,
         (SELECT isp.obj#,ts#,icp.bo#
          FROM   indcompart$ icp, indsubpart$ isp
          WHERE  isp.pobj# = icp.obj#) v4, ind$ i
  WHERE  i.bo# = v3.bo# AND v4.bo# = i.obj# AND v4.ts# != V3.ts#
UNION ALL
  SELECT lf.fragobj#, lf.ts#, tp.obj#, tp.ts#,
         'Table partition and lob fragment not in Transportable Set', 17
  FROM   lobfrag$ lf, tabpart$ tp
  WHERE  lf.tabfragobj# = tp.obj# AND tp.ts# !=lf.ts#
UNION ALL
  -- Report Subpartitions having lob fragments
  SELECT tsp.obj#, tsp.ts#, lf.fragobj#, lf.ts#,
         'Table Subpartition and lob fragment not fully contained in pluggable set',
         18
 FROM    tabsubpart$ tsp, lobfrag$ lf
  WHERE  tsp.obj# = lf.tabfragobj# AND tsp.ts# != lf.ts#
--UNION ALL
--  -- Report all objects owned by SYS
--  -- NON-Partitioned table
--  SELECT o.obj#, t.ts#, -1, -1,
--         'Sys owned tables not allowed in Transportable Set', 19
--  FROM   tab$ t, obj$ o
--  WHERE  t.obj# = o.obj# AND BITAND(t.property, 32) = 0 AND o.owner# = 0
--UNION ALL
--  -- Partitioned tables
--  SELECT o.obj#, tp.ts#, -1, -1,
--         'Sys owned partitions not allowed in Transportable Set', 20
--  FROM   tabpart$ tp, obj$ o
--  WHERE  tp.obj# = o.obj# AND o.owner# = 0
--UNION ALL
--  -- clusters
--  SELECT o.obj#, c.ts#, -1, -1,
--         'Sys owned clusters not allowed in Transportable Set', 21
--  FROM   clu$ c, obj$ o
--  WHERE  c.obj# = o.obj# AND o.owner# = 0
--UNION ALL
--  -- subpartitions
--  SELECT o.obj#, tsp.ts#, -1, -1,
--         'Sys owned subpartitions not allowed in Transportable Set', 22
--  FROM   tabsubpart$ tsp, obj$ o
--  WHERE  tsp.obj# = o.obj# AND o.owner# = 0
--UNION ALL
--  -- non-partitioned indexes
--  SELECT o.obj#, i.ts#, -1, -1,
--         'Sys owned indexes not allowed in Transportable Set', 23
--  FROM   ind$ i, obj$ o
--  WHERE  i.obj# = o.obj# AND o.owner# = 0 AND BITAND(i.property, 2) =0
--UNION ALL
--  -- Partitioned indexes
--  SELECT o.obj#, ip.ts#, -1, -1,
--         'Sys owned partitioned indexes not allowed in Transportable Set', 24
--  FROM   indpart$ ip, obj$ o
--  WHERE  ip.obj# = o.obj# AND o.owner# = 0
--UNION ALL
--  -- subpartitioned indexes
--  SELECT o.obj#, isp.ts#, -1, -1,
--         'Sys owned subpartitioned indexes not allowed in Transportable Set',
--         25
--  FROM   indsubpart$ isp, obj$ o
--  WHERE  isp.obj# = o.obj# AND o.owner# = 0
--UNION ALL
--  -- lobs
--  SELECT l.lobj#, l.ts#, -1, -1,
--         'Sys owned lobs not allowed in Transportable Set', 26
--  FROM   lob$ l, obj$ o
--  WHERE  l.lobj# = o.obj# AND o.owner# = 0
--UNION ALL
--  -- partitioned lobs
--  SELECT lf.fragobj#, lf.ts#, -1, -1,
--         'Sys owned lob fragments not allowed in Transportable Set', 27
--  FROM   lobfrag$ lf, obj$ o
--  WHERE  lf.fragobj# = o.obj# AND o.owner# = 0
UNION ALL
  -- Report any PL/SQL Functional Indexes
  SELECT i.obj#, i.ts#, -1, -1,
         'PLSQL Functional Indexes not allowed in Transportable Set', 29
  FROM   ind$ i
  WHERE  BITAND(i.property, 2048) = 2048
UNION ALL
  -- Report any iot and overflow segment are not in same tablespace
  -- The following will capture the IOT table.
  -- Bug-6652830: take care of partitioned objects and ignore lob indexes
  SELECT t.obj#,
         decode(BITAND(t.property, 32), 0, t.ts#, 32,
               (select po.defts# from partobj$ po where po.obj# = t.obj#)),
         i.obj#,
         decode(BITAND(i.property, 2), 0, i.ts#, 2,
               (select po.defts# from partobj$ po where po.obj# = i.obj#)),
         'IOT and Overflow segment not self contained', 30
  from   tab$ t, ind$ i
  where  t.bobj# = i.bo# AND i.type# != 8 AND
         BITAND(t.property,512) != 0 AND
         decode(BITAND(t.property, 32), 0, t.ts#, 32,
               (select po.defts# from partobj$ po where po.obj# = t.obj#)) !=
         decode(BITAND(i.property, 2), 0, i.ts#, 2,
               (select po.defts# from partobj$ po where po.obj# = i.obj#))
UNION ALL
  -- Report all default storage for a partitioned object that are outside of
  -- the transportable set.  Logical partitions are being excluded since they
  -- don't occupy storage.
  -- Exclude logical partitions
  -- Ensure that the default partition tablespace for table partitions is self
  -- contained
  SELECT po.obj#, defts#, tp.obj#, tp.ts#,
         'Default tablespace and partition not selfcontained', 33
  FROM   tabpart$ tp, partobj$ po
  WHERE  po.obj# = tp.bo# AND po.defts# != tp.ts# AND
         ((tp.block# != 0 AND tp.file# !=0) OR
          EXISTS (SELECT 1 FROM sys.deferred_stg$ ds
                  WHERE ds.obj# = tp.obj#))
UNION ALL
  -- Default for partitioned object and table subpartition are self contained
  SELECT po.obj#, po.defts#, tcp.obj#, tcp.defts#,
         'Default tablespace and partition not selfcontained', 37
  FROM   tabcompart$ tcp, partobj$ po
  WHERE  tcp.bo# = po.obj# AND tcp.defts# != po.defts#
UNION ALL
  -- Report any default partition tablespace for index partitions not contained
  SELECT po.obj#, defts#, ip.obj#, ip.ts#,
         'Default tablespace and partition not selfcontained', 34
  FROM   ind$ i, indpart$ ip, partobj$ po
  WHERE  po.obj# = ip.bo# AND po.defts# != ip.ts# AND i.obj# = ip.bo# AND
         i.type# != 9
UNION ALL
  -- Report partitioned object and index subpartition default tablespace are
  -- self contained
  SELECT po.obj#, po.defts#, icp.obj#, icp.defts#,
         'Default tablespace and partition not selfcontained', 38
  FROM   indcompart$ icp, partobj$ po
  WHERE  icp.bo# = po.obj# AND icp.defts# != po.defts#
UNION ALL
  -- Report any default partition tablespace for subpartitions not contained
  -- for Tables
  SELECT tcp.obj#, defts#, tsp.obj#, tsp.ts#,
         'Default tablespace and partition not selfcontained', 35
  FROM   tabcompart$ tcp, tabsubpart$ tsp
  WHERE  tcp.obj# = tsp.pobj# AND tcp.defts# != tsp.ts#
UNION ALL
  -- Report any default partition tablespace for subpartitions not contained
  -- for Indexes
  SELECT icp.obj#, defts#, isp.obj#, isp.ts#,
         'Default tablespace and partition not selfcontained', 36
  FROM   indcompart$ icp, indsubpart$ isp
  WHERE  icp.obj# = isp.pobj# AND icp.defts# != isp.ts#
UNION ALL
  -- Report any IOTs where the index partitions are not contained
  SELECT ip1.obj#, ip1.ts#, ip2.obj#, ip2.ts#,
         'IOT partitions not self contained', 39
  FROM   (SELECT bo#,
                 MIN(ts#) keep (dense_rank first order by part#) ts#,
                 MIN(obj#) keep (dense_rank first order by part#) obj#
          FROM   indpart$
          GROUP BY bo#) ip1, indpart$ ip2, ind$ i, tab$ t
  WHERE  ip1.bo#= i.obj# AND ip1.ts# != ip2.ts# AND ip2.bo# = i.obj# AND
         i.bo# = t.obj# AND BITAND(t.property, 64) != 0
UNION ALL
  -- Report all IOTs, overflow segments and index partitions not contained. We
  -- can take the first overflow segment partition and run it against all the
  -- index partitions.  This guarantees completeness since all index partitions
  -- are checked for seperately for self containment
  SELECT tp.obj#, tp.ts#,ip.obj#,ip.ts#,
         'Overflow and index partition not self contained', 40
  FROM   indpart$ ip, ind$ i, tab$ t,
         (SELECT  bo#,
                  min(ts#) keep (dense_rank first order by part#) ts#,
                  min(obj#) keep (dense_rank first order by part#) obj#
          FROM    tabpart$
          GROUP BY bo#) tp
  WHERE   tp.bo# = t.obj# AND BITAND(t.property, 512) != 0 AND
          t.bobj# = i.bo# AND ip.bo#= i.obj# AND ip.ts# != tp.ts#
UNION ALL
  -- check iots having lobs
  -- Bug-6652830: exclude partitioned tables (property 0x20) since
  -- partitioned lob objects don't have ts# set while lob fragments do.
  SELECT t.obj#,i.ts#,l.lobj#, l.ts#,
         'Base table and lob object not fully contained in pluggable set', 41
  FROM   tab$ t, lob$ l, ind$ i
  WHERE  BITAND(t.property, 64)! = 0 AND BITAND(t.property, 32) = 0 AND
         l.ts#! = i.ts# AND l.obj# = t.obj# AND
         i.bo# = t.obj#
UNION ALL
  -- Report any join indexes that are not contained. The logging tables of join
  -- indexes are used during a transaction for updating purpose. They are not
  -- relevant for TTS since TTS are made read-only.
  -- Note that this is a one-way dependency.
  SELECT o1.obj#, t1.ts#, o2.obj#, t2.ts#,
         'Tables of the join index are not in the same tablespace', 43
  FROM   tts_obj_view o1, tts_obj_view o2, jijoin$ j, tts_tab_view t1,
         tts_tab_view t2
  WHERE  j.tab1obj# = o1.obj# AND j.tab2obj# = o2.obj# AND
         o1.obj# = t1.obj# AND o2.obj# = t2.obj# AND t1.ts# != t2.ts#
UNION ALL
  -- Report all tables having scoped REF constraints in different tablespaces.
  --   t.property  8 (0x08) -> has REF column
  --   Note that this is a one-way dependency
  SELECT t2.obj#, t2.ts#, o.obj#, t.ts#,
         'based table and its scoped REF object are in different tablespaces',
         44
  FROM   tts_obj_view o, tts_tab_view t, refcon$ c,
         tts_obj_view o2, tts_tab_view t2
  WHERE  o.obj# = t.obj# AND c.obj# = o.obj# AND c.stabid = o2.oid$ AND
         BITAND(c.reftyp, 1) != 0 AND o2.obj#=t2.obj# AND t.ts# != t2.ts# AND
         BITAND(t.property, 8) = 8
UNION ALL
  -- Disallow evolved type data that have not been upgraded.
  SELECT o.obj#, t.ts#, -1, -1,
         'Evolved type data that have not been upgraded are not allowed in a Transportable Set',
         45
  FROM   coltype$ c, obj$ o, tts_tab_view t
  WHERE  o.obj# = c.obj# AND t.obj# = o.obj# AND BITAND(c.flags, 256) != 0
UNION ALL
  -- Tables with encrypted columns not supported
  SELECT t.obj#, t.ts#, -1, -1,
         'Tables with encrypted columns not allowed in Transportable Set', 46
  FROM   tab$ t, tts_obj_view o
  WHERE  t.obj# = o.obj# AND BITAND(t.trigflag, 65536) = 65536
UNION ALL
  -- Tables with parent ref partition tables
  SELECT t1.bo#, t1.ts#, t2.bo#, t2.ts#,
         'Ref partitioned child table included but not parent table', 47
  FROM   tabpart$ t1, tabpart$ t2, cdef$ c
  WHERE  t1.bo# = c.obj# and t2.bo# = c.robj# and t1.part# = t2.part# and
         t1.ts# != t2.ts#
UNION ALL
  -- Partitioned tables in process of online move
  SELECT tp.bo#, tp.ts#, null, null,
         'Partitioned table in progcess of an online move partition', 48
 from sys.tabpart$ tp
 where bitand(tp.flags,4194304)!=0
UNION ALL
  -- Subpartitioned tables in process of online move
  SELECT tcp.bo#, tsp.ts#, null, null,
         'Subpartitioned table in progcess of an online move partition', 49
  FROM   sys.tabcompart$ tcp, sys.tabsubpart$ tsp
  WHERE tcp.obj#=tsp.pobj# and
        bitand(tsp.flags,4194304)!=0
UNION ALL
  -- Index with orphanded partition
  SELECT i.obj#, i.ts#, null, null,
         'Index has an orphaned entries', 50
  FROM   ind$ i
  WHERE  bitand(i.flags,268435456) != 0
UNION ALL
  -- Partitioned Index with orphanded partition
  SELECT unique ip.bo#, ip.ts#, null, null,
         'Partitioned index has an orphaned entries', 51
  FROM indpart$ ip
  where bitand(ip.flags,262144)!=0
/

