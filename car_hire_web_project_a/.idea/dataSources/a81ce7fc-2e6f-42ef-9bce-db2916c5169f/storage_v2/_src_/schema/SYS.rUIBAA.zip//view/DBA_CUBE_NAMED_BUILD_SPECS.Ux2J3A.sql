create view DBA_CUBE_NAMED_BUILD_SPECS as
  SELECT
  u.name OWNER,
  o.name CUBE_NAME,
  syn.syntax_clob NAMED_BUILD_SPEC
FROM
  olap_cubes$ c,
  user$ u,
  obj$ o,
  olap_syntax$ syn
WHERE
  o.obj#=c.obj#
  AND o.owner#=u.user#
  AND syn.owner_id(+)=c.obj#
  AND syn.owner_type(+)=1
  AND syn.ref_role = 18 -- named build spec
/

comment on table DBA_CUBE_NAMED_BUILD_SPECS
is 'OLAP Cube Named Build Specifications in the database'
/

