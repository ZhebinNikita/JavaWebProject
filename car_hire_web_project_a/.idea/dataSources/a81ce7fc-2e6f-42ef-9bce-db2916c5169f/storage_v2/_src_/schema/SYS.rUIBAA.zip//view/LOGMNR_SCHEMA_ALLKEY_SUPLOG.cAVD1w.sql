create view LOGMNR$SCHEMA_ALLKEY_SUPLOG as
  select name schema_name,
       (case when bitand(spare1, 64) = 64
            then 'YES' else 'NO' end) ALLKEY_SUPLOG,
       (case when bitand(spare1, 1024) = 1024
            then 'YES' else 'NO' end) ALLOW_NOVALIDATE_PK
from user$
where name in (select username from all_users)
/

