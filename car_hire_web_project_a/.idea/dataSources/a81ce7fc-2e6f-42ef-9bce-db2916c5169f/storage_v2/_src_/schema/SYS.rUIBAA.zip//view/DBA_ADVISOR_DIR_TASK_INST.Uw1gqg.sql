create view DBA_ADVISOR_DIR_TASK_INST as
  select a.dir_id as directive_id,
             a.inst_id as seq_id,
             a.name as instance_name,
             d.name as username,
             a.task_id as task_id,
             b.name as task_name,
             a.data as data
      from wri$_adv_directive_instances a,wri$_adv_tasks b, user$ d
      where a.task_id = b.id
        and d.user# = b.owner#
/

