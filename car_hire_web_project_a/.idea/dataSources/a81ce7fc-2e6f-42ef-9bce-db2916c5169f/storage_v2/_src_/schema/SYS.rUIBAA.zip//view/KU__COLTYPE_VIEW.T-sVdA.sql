create view KU$_COLTYPE_VIEW as
  select ct.obj#, ct.col#, ct.intcol#, ct.flags, ct.toid,
         ct.version#, ct.packed, ct.intcols, ct.intcol#s,
         (select sys.dbms_metadata.get_hashcode(o.owner_name,o.name)
                 from ku$_edition_schemaobj_view o, obj$ oo
                 where ct.toid = oo.oid$
                 and o.obj_num = oo.obj#),
         (select sys.dbms_metadata_util.has_tstz_elements(o.owner_name,o.name)
                 from ku$_edition_schemaobj_view o, obj$ oo
                 where ct.toid = oo.oid$
                 and o.obj_num = oo.obj#),
         ct.typidcol#, ct.synobj#,
         (select sy.name from obj$ sy where sy.obj#=ct.synobj#),
         (select u.name from user$ u, obj$ o
          where o.obj#=ct.synobj# and u.user#=o.owner#),
         /* look up stuff in subcoltype$ only if column is substitutable */
         decode(bitand(ct.flags, 512), 512,
           cast(multiset(select sct.* from ku$_subcoltype_view sct
                where ct.obj#    = sct.obj_num
                and   ct.intcol# = sct.intcol_num
                       ) as ku$_subcoltype_list_t
                ),
           null),
        (select value(o) from ku$_edition_schemaobj_view o, obj$ oo
         where ct.toid = oo.oid$
         and o.obj_num = oo.obj#),
        -- If column is opaque and has internal columns, check for unpacked
        --  anydata type
        case when ((bitand(ct.flags, 16384)=16384) and (ct.intcols>0)) then
             (select dbms_metadata_util.get_anydata_colset(ct.obj#, ct.col#,
                                             ct.intcols,ct.intcol#s) from dual)
        else null end
    from coltype$ ct
/

