create view KU$_ARGUMENT_VIEW as
  select
   obj#,
   procedure$,
   overload#,
   procedure#,
   position#,
   sequence#,
   level#,
   argument,
   type#,
   charsetid,
   charsetform,
   default#,
   in_out,
   properties,
   length,
   precision#,
   scale,
   radix,
   deflength,
   sys.dbms_metadata_util.long2varchar(deflength,
                                        'SYS.ARGUMENT$',
                                        'DEFAULT$',
                                        rowid),
   type_owner,
   type_name,
   type_subname,
   type_linkname,
   pls_type
from sys.argument$
/

