create view CDB_CREDENTIALS as
  SELECT k."OWNER",k."CREDENTIAL_NAME",k."USERNAME",k."WINDOWS_DOMAIN",k."COMMENTS",k."ENABLED",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_CREDENTIALS") k
/

comment on table CDB_CREDENTIALS
is 'All credentials in the database in all containers'
/

