create view DBA_LOGSTDBY_PARAMETERS as
  select name, value, unit, setting, dynamic
  from x$dglparam where visible=1
/

comment on table DBA_LOGSTDBY_PARAMETERS
is 'Miscellaneous options and settings for Logical Standby'
/

