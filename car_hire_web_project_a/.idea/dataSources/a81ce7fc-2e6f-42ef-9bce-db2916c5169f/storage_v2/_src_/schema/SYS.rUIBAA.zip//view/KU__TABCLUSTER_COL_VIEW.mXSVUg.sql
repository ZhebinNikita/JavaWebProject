create view KU$_TABCLUSTER_COL_VIEW as
  select c.obj#,
         c.col#,
         c.intcol#,
         c.segcol#,
         bitand(c.property, 4294967295),
         trunc(c.property / power(2,32)),
         c.name,
         (select a.name from attrcol$ a where
                        a.obj#=c.obj# and a.intcol#=c.intcol#),
         c.type#,
         c.deflength, '', '', null
  from col$ c, col$ cc, tab$ t
  where c.obj#  = t.obj#
    and cc.obj# = t.bobj#
    and cc.segcol# = c.segcol#
/

