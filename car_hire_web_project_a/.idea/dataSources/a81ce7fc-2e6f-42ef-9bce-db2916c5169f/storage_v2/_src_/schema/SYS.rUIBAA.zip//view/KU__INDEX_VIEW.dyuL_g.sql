create view KU$_INDEX_VIEW as
  select * from ku$_all_index_view
/

