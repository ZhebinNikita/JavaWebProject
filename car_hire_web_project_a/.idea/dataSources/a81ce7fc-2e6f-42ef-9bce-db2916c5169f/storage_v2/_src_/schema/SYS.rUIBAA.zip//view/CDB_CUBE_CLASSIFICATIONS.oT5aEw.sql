create view CDB_CUBE_CLASSIFICATIONS as
  SELECT k."OWNER",k."OBJECT_NAME",k."OBJECT_TYPE",k."LANGUAGE",k."CLASSIFICATION",k."ORDER_NUM",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_CUBE_CLASSIFICATIONS") k
/

comment on table CDB_CUBE_CLASSIFICATIONS
is 'OLAP Object Classifications in the database in all containers'
/

