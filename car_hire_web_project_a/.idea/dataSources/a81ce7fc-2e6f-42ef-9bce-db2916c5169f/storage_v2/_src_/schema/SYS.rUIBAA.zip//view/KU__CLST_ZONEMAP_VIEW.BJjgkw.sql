create view KU$_CLST_ZONEMAP_VIEW as
  select o.obj#, s.sowner, s.tname
  from obj$ o, user$ u, snap$ s
  where o.owner# = u.user#
    and s.mowner = u.name
    and s.master = o.name
    and bitand(s.flag3, 512) = 512                     /* snapshot = zonemap */

