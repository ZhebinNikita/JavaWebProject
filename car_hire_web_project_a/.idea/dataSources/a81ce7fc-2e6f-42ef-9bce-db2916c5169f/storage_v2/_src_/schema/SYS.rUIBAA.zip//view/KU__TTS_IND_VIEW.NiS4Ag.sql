create view KU$_TTS_IND_VIEW as
  select o.owner#, i.obj#, ts.name, ts.ts#      -- unpartitioned indexes
  from   sys.obj$ o, sys.ind$ i, sys.ts$ ts
  where  i.ts#  = ts.ts#
  and    o.obj# = i.obj#
  and    bitand(i.property, 2) = 0
 UNION ALL
  select o.owner#, i.obj#, ts.name, ts.ts#      -- partitioned indexes
  from   sys.obj$ o, sys.ind$ i, sys.indpart$ ip, sys.ts$ ts
  where  ip.ts# = ts.ts#
  and    i.obj# = ip.bo#
  and    o.obj# = i.obj#
  and    bitand(i.property, 2) = 2
 UNION ALL
  select o.owner#, i.obj#, ts.name, ts.ts#      -- composite partitioned indexes
  from   sys.obj$ o, sys.ind$ i,
         sys.indcompart$ icp, sys.indsubpart$ isp, sys.ts$ ts
  where  isp.ts#  = ts.ts#
  and    icp.obj# = isp.pobj#
  and    i.obj#   = icp.bo#
  and    o.obj#   = i.obj#
  and    bitand(i.property, 2) = 2
/

