create view KU$_JIJOIN_VIEW as
  select j.obj#, j.tab1obj#, j.tab1col#, j.tab2obj#, j.tab2col#,
            (select value(c) from sys.ku$_simple_col_view c
             where c.obj_num = j.tab1obj# and c.intcol_num = j.tab1col#),
            (select value(c) from sys.ku$_simple_col_view c
             where c.obj_num = j.tab2obj# and c.intcol_num = j.tab2col#),
            j.joinop, j.flags, j.tab1inst#, tab2inst#
  from sys.jijoin$ j
  order by j.tab1obj#, j.tab1col#
/

