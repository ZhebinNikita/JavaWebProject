create view ALL_CUBE_MAPPINGS as
  SELECT
  u.name OWNER,
  o.name CUBE_NAME,
  m.map_name MAP_NAME,
  m.map_id MAP_ID,
  s1.syntax_clob QUERY,
  s2.syntax_clob WHERE_CLAUSE,
  s3.syntax_clob FROM_CLAUSE,
  decode(i1.option_num_value, '1', 'Y', 'N') IS_SOLVED,
  i2.option_value AGGREGATION_METHOD
FROM
  olap_mappings$ m,
  user$ u,
  obj$ o,
  olap_syntax$ s1,
  olap_syntax$ s2,
  olap_syntax$ s3,
  olap_impl_options$ i1,
  olap_impl_options$ i2,
 (SELECT
    obj#,
    MIN(have_dim_access) have_all_dim_access
  FROM
    (SELECT
      c.obj# obj#,
      (CASE
        WHEN
        (do.owner# in (userenv('SCHEMAID'), 1)   -- public objects
         or do.obj# in
              ( select obj#  -- directly granted privileges
                from sys.objauth$
                where grantee# in ( select kzsrorol from x$kzsro )
              )
         or   -- user has system privileges
                ora_check_SYS_privilege (do.owner#, do.type#) = 1
        )
        THEN 1
        ELSE 0
       END) have_dim_access
    FROM
      olap_cubes$ c,
      dependency$ d,
      obj$ do
    WHERE
      do.obj# = d.p_obj#
      AND do.type# = 92 -- CUBE DIMENSION
      AND c.obj# = d.d_obj#
    )
    GROUP BY obj# ) da
WHERE
  m.map_type = 22
  AND m.mapping_owner_id = o.obj#
  AND o.obj# = da.obj#(+)
  AND o.owner# = u.user#
  AND m.map_id = s1.owner_id(+)
  AND m.map_type = s1.owner_type(+)
  AND s1.ref_role(+) = 3
  AND m.map_id = s2.owner_id(+)
  AND m.map_type = s2.owner_type(+)
  AND s2.ref_role(+) = 21
  AND m.map_id = s3.owner_id(+)
  AND m.map_type = s3.owner_type(+)
  AND s3.ref_role(+) = 22
  AND m.map_id = i1.owning_objectid(+)
  AND m.map_type = i1.object_type(+)
  AND i1.option_type(+) = 11
  AND m.map_id = i2.owning_objectid(+)
  AND m.map_type = i2.object_type(+)
  AND i2.option_type(+) = 21
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
  AND ((have_all_dim_access = 1) OR (have_all_dim_access is NULL))
/

comment on table ALL_CUBE_MAPPINGS
is 'OLAP Cube Mappings in the database accessible to the user'
/

