create view USER_CREDENTIALS as
  SELECT o.name, c.username,
  c.domain, c.comments,
  DECODE(bitand(c.flags, 4), 0, 'FALSE', 4, 'TRUE')
  FROM obj$ o, sys.scheduler$_credential c
  WHERE o.owner# = USERENV('SCHEMAID') AND c.obj# = o.obj#
/

comment on table USER_CREDENTIALS
is 'Credentials owned by the current user'
/

