create view KU$_IOTABLE_BYTES_ALLOC_VIEW as
  select t.obj#,
            (select b.bytes_alloc from ku$_bytes_alloc_view b
             where b.ts_num = i.ts#
               and b.file_num = i.file#
               and b.block_num = i.block#)
          +decode(bitand(t.property,2048+262144),0,0,   -- add lob storage
            (select sum(b.bytes_alloc) from ku$_bytes_alloc_view b, lob$ l
             where b.ts_num = l.ts#
               and b.file_num = l.file#
               and b.block_num = l.block#
               and l.obj#=t.obj#))
  from ind$ i, tab$ t
  where t.pctused$ = i.obj#          -- For IOTs, pctused has index obj#
/

