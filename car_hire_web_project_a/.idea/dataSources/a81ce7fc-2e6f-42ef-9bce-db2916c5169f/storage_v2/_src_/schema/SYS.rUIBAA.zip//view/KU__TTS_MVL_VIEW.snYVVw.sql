create view KU$_TTS_MVL_VIEW as
  select o.owner#, t.obj#, ts.name              -- unpartitioned heap tables
  from   sys.obj$ o, sys.tab$ t, sys.user$ u, sys.mlog$ m, sys.ts$ ts
  where  m.mowner = u.name
  and    m.log    = o.name
  and    o.owner# = u.user#
  and    o.type#  = 2
  and    o.obj#   = t.obj#
  and    t.ts#    = ts.ts#
  and    bitand(t.property, 32) = 0
 UNION ALL
  select o.owner#, t.obj#, ts.name              -- simple partitions
  from   sys.obj$ o, sys.tab$ t, sys.tabpart$ tp,
         sys.user$ u, sys.mlog$ m, sys.ts$ ts
  where  m.mowner = u.name
  and    m.log    = o.name
  and    o.owner# = u.user#
  and    o.type#  = 2
  and    o.obj#   = t.obj#
  and    bitand(t.property, 32) = 32
  and    t.obj#   = tp.bo#
  and    tp.ts#   = ts.ts#
 UNION ALL
  select o.owner#, t.obj#, ts.name              -- composite partitions
  from   sys.obj$ o, sys.tab$ t,
         sys.tabcompart$ tcp, sys.tabsubpart$ tsp,
         sys.user$ u, sys.mlog$ m, sys.ts$ ts
  where  m.mowner = u.name
  and    m.log    = o.name
  and    o.owner# = u.user#
  and    o.type#  = 2
  and    o.obj#   = t.obj#
  and    bitand(t.property, 32) = 32
  and    t.obj#   = tcp.bo#
  and    tcp.obj# = tsp.pobj#
  and    tsp.ts#  = ts.ts#
/

