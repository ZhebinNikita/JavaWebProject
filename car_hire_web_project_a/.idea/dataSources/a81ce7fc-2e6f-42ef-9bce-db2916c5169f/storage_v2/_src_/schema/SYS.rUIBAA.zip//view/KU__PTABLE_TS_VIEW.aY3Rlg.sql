create view KU$_PTABLE_TS_VIEW as
  select t.obj#,dbms_metadata_util.table_tsnum(t.obj#)
 from tab$ t
/

