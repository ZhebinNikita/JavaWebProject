create view KU$_ILM_POLICY_VIEW as
  select o.obj#, o.obj_typ, o.obj_typ_orig, o.policy#, o.flag,
         p.actionc,
         p.ctype, p.clevel, p.cindex, p.cprefix, p.clevlob,
         p.tier_tbs, p.action, p.type, p.condition, p.days, p.scope,
         p.custfunc, p.flag, p.flag2, p.spare1, p.spare2,
         p.spare3, p.spare4, p.spare5, p.spare6,
         p.pol_subtype, p.actionc_clob, p.tier_to
  from sys.ilmpolicy$ p, sys.ilmobj$ o
  where p.policy#=o.policy#
/

