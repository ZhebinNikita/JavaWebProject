create view KU$_TABLE_XMLSCHEMA_VIEW as
  select opq.obj# tabobj_num, opq.schemaoid schemaoid, opq.schemaoid par_oid
  from sys.opqtype$ opq
 UNION
  select opq.obj# tabobj_num, sd.dep_schema_oid schemaoid, opq.schemaoid par_oid
  from sys.opqtype$ opq, dba_xml_schema_dependency sd
  start with
    sd.schema_oid=opq.schemaoid and opq.type=1 and opq.schemaoid is not null
  connect by nocycle
    prior sd.dep_schema_oid=sd.schema_oid and
    prior opq.schemaoid=opq.schemaoid and opq.type=1
/

