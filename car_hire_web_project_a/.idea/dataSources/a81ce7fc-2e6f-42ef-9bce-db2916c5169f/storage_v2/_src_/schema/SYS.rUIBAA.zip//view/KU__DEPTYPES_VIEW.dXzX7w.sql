create view KU$_DEPTYPES_VIEW as
  select b.typeobjno, b.typename, b.typeownerno, b.typeowner, b.typeobjflags,
        b.dobjno, b.dname
 from ku$_deptypes_base_view b
 where (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (b.typeownerno, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

