create view KU$_NT_PARENT_VIEW as
  select t.obj#,
    cast(multiset(select
                nt.obj#, nt.intcol#, nt.ntab#,
                (select value(o) from ku$_schemaobj_view o
                 where o.obj_num = nt.ntab#),
                (select value(c) from ku$_simple_col_view c
                 where c.obj_num = nt.obj#
                 and   c.intcol_num = nt.intcol#),
                (select t.property from tab$ t where t.obj# = nt.ntab#),
                (select ct.flags from coltype$ ct
                        where ct.obj# = nt.obj#
                        and   ct.intcol# = nt.intcol#),
                (select value(h) from ku$_hnt_view h
                 where h.obj_num = nt.ntab#),
                (select value(i) from ku$_iont_view i
                 where i.obj_num = nt.ntab#),
                (cast(multiset(select * from ku$_column_view c
                                where c.obj_num = nt.ntab#
                                order by c.col_num, c.intcol_num
                        ) as ku$_tab_column_list_t
                        ))
          from ntab$ nt start with nt.obj#=t.obj#
                        connect by prior nt.ntab#=nt.obj#
                ) as ku$_nt_list_t
        )
  from tab$ t where bitand(t.property,4) = 4    -- has nested table columns
/

