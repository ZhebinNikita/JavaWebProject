create view DBA_LOGSTDBY_SKIP as
  select decode(error, 1, 'Y', 'N') error,
         statement_opt, schema owner, name,
         decode(use_like, 0, 'N', 'Y') use_like, esc, proc
  from system.logstdby$skip
  union all
  select 'N' error,
         'INTERNAL SCHEMA' statement_opt, u.username owner, '%' name,
         'N' use_like, null esc, null proc
  from dba_users u, system.logstdby$skip_support s
  where u.username = s.name
  and   s.action = 0
/

comment on table DBA_LOGSTDBY_SKIP
is 'List the skip settings choosen'
/

