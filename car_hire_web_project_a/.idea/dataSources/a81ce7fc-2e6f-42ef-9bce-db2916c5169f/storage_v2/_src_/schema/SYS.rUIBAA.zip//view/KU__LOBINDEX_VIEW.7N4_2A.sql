create view KU$_LOBINDEX_VIEW as
  select i.obj#, value(o),
         ts.name, ts.blocksize,
         (select value(s) from ku$_storage_view s
          where i.file#  = s.file_num
          and   i.block# = s.block_num
          and   i.ts#    = s.ts_num),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = i.obj#),
         i.dataobj#, i.cols,
         i.pctfree$, i.initrans, i.maxtrans, i.pctthres$, i.type#, i.flags, i.property,
         i.blevel, i.leafcnt, i.distkey, i.lblkkey, i.dblkkey, i.clufac,
         to_char(i.analyzetime,'YYYY/MM/DD HH24:MI:SS'),
         i.samplesize, i.rowcnt,
         i.intcols, i.degree, i.instances, i.trunccnt,
         i.spare1, i.spare2, i.spare3,
         replace(i.spare4, chr(0)), i.spare5,
         to_char(i.spare6,'YYYY/MM/DD HH24:MI:SS'),
         null, null, null
   from  ku$_schemaobj_view o, ind$ i, ts$ ts
   where o.obj_num = i.obj#
         AND  i.ts# = ts.ts#
/

