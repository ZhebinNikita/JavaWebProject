create view DBA_LOGSTDBY_EVENTS as
  select cast(event_time as date) event_time, event_time event_timestamp,
         spare1 as start_scn, current_scn, commit_scn, xidusn, xidslt, xidsqn,
         full_event event, errval status_code, error status,
         con_name src_con_name, con_id src_con_id
  from system.logstdby$events
/

comment on table DBA_LOGSTDBY_EVENTS
is 'Information on why logical standby events'
/

