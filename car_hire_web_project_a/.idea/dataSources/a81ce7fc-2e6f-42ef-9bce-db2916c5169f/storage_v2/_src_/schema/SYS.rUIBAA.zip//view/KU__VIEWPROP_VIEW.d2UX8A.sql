create view KU$_VIEWPROP_VIEW as
  select o.obj#, o.name, u.name, v.property
 from obj$ o, user$ u, view$ v
 where o.owner# = u.user#
 and   o.obj#   = v.obj#
 and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' )     OR
                EXISTS ( SELECT 1 FROM all_objects ao
                        WHERE o.obj# = ao.object_id))
/

