create view KU$_CLST_VIEW as
  select k.clstobj#, k.clstfunc, k.flags,
         cast(multiset(select c.* from ku$_clstcol_view c
              where c.obj_num=k.clstobj#
              order by c.position
                       ) as ku$_clstcol_list_t
             ),
         cast(multiset(select * from ku$_clstjoin_view j
               where j.obj_num = k.clstobj#
                        ) as ku$_clstjoin_list_t
             ),
         (select value(z) from ku$_clst_zonemap_view z
          where z.obj_num=k.clstobj#)
  from clst$ k
/

