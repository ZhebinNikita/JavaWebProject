create view KU$_DEPTYPES_BASE_VIEW as
  select o.obj#, o.name, o.owner#, bu.name, o.flags, bo.obj#, bo.name
 from
   (select
      oo.obj# as aobjnum, ot.toid as aobjoid,
      do.obj# as adobjnum, dt.toid as adobjoid
    from dependency$ d, obj$ oo, type$ ot, obj$ do, type$ dt, user$ u
    where oo.oid$ = ot.tvoid
      and bitand(ot.properties,8388608+2128)=0 /* not transient or sys-generated */
      and bitand(oo.flags,16)!=16          /* not secondary object */
      and oo.owner# != 0                   /* not owned by SYS */
      and oo.owner# = u.user#
      and oo.obj# = d.p_obj#
      and do.obj# = d.d_obj#
      and bitand(d.property,1)=1          /* only hard dependency */
      and do.type# = 13
      and do.oid$ = dt.tvoid) a, type$ at, obj$ ao,
    ku$_edition_obj_view o, type$ bt, obj$ bo, user$ bu
  where a.aobjoid = at.tvoid and at.tvoid = at.toid and at.toid = ao.oid$ and
      ao.obj# = o.obj# and
      a.adobjoid = bt.tvoid and bt.tvoid = bt.toid and bt.toid = bo.oid$ and
      o.owner# = bu.user#
union
 select o.obj#,o.name,o.owner#,u.name,o.flags,0,NULL
from ku$_edition_obj_view o, user$ u, type$ t
where o.oid$ = t.toid
  and bitand(t.properties,8388608+2128)=0 /* not transient or sys-generated */
  and bitand(o.flags,16)!=16          /* not secondary object */
  and o.owner# != 0                   /* not owned by SYS */
  and o.owner# = u.user#
  and not exists (select * from obj$ do, dependency$ d
                  where o.obj# = d.p_obj#
                  and do.obj# = d.d_obj#
                  and do.type# = 13
                  and bitand(d.property,1)=1 )
/

