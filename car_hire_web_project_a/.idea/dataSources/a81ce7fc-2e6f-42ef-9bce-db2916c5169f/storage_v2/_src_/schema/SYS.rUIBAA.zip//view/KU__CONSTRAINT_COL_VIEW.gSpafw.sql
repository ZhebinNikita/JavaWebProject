create view KU$_CONSTRAINT_COL_VIEW as
  select cc.con#, cc.obj#, cc.intcol#, cc.pos#, cc.spare1,
  decode(bitand(c.property,1024+2),0,0,2,1,1024,2,0),
  decode(bitand(c.property,2097152+1024),
         2097152,(select value(c1) from ku$_simple_pkref_col_view c1
                  where c1.obj_num    = cc.obj# and
                        c1.intcol_num = cc.intcol#),
            1024,(select value(c2) from ku$_simple_setid_col_view c2
                  where c2.obj_num    = cc.obj# and
                        c2.intcol_num = cc.intcol#),
            value(c))
  from ku$_simple_col_view c, ccol$ cc
  where c.obj_num    = cc.obj#
    and c.intcol_num = cc.intcol#
/

