create view DBA_ADVISOR_DEFINITIONS as
  select id as advisor_id,
             name as advisor_name,
             property as property
      from wri$_adv_definitions
      where id > 0
/

