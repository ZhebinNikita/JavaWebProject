create view KU$_10_2_INDEX_VIEW as
  select * from ku$_all_index_view i
        where  BITAND(i.property, 8208) != 8208      /* remove Fn Ind on MV */

