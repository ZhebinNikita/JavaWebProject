create view KU$_LOBCOMPPART_VIEW as
  select lc.partobj#, lc.tabpartobj#,
        dbms_metadata.get_partn(8,lc.lobj#, lc.part#),
        (select l.intcol# from lob$ l where l.lobj#=lc.lobj#),
        (select value(o) from ku$_schemaobj_view o
         where o.obj_num = lc.partobj#),
        (select ts.name from ts$ ts where lc.defts# = ts.ts#),
        (select ts.blocksize from ts$ ts where lc.defts# = ts.ts#),
        lc.defchunk, lc.defpctver$, lc.defflags, lc.defpro,
        lc.definiexts, lc.defextsize, lc.defminexts, lc.defmaxexts,
        lc.defextpct, lc.deflists, lc.defgroups, lc.defbufpool,
        lc.spare1, lc.spare2, lc.spare3,
        lc.defmaxsize, lc.defretention, lc.defmintime
  from lobcomppart$ lc
/

