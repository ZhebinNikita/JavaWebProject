create view KU$_SCHEMAOBJNUM_VIEW as
  select *
  from ku$_schemaobj_view ku$
  where ku$.obj_num in (select * from table(dbms_metadata.fetch_objnums))
/

