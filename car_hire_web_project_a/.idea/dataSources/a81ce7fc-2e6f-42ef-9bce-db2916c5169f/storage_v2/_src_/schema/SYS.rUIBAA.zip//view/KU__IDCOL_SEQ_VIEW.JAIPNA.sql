create view KU$_IDCOL_SEQ_VIEW as
  select '1','1',
         s.obj#, value(o),
         s.increment$, TO_CHAR(s.minvalue), TO_CHAR(s.maxvalue),
         s.cycle#, s.order$, s.cache,
         TO_CHAR(s.highwater),  replace(s.audit$,chr(0),'-'), s.flags
  from  sys.ku$_schemaobj_view o, sys.seq$ s
  where s.obj# = o.obj_num AND
        (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
         EXISTS ( SELECT * FROM sys.session_roles
         WHERE role='SELECT_CATALOG_ROLE' ))
/

