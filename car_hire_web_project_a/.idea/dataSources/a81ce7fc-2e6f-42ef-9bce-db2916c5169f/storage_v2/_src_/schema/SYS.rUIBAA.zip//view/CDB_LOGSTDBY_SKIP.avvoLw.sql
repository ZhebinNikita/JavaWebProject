create view CDB_LOGSTDBY_SKIP as
  SELECT k."ERROR",k."STATEMENT_OPT",k."OWNER",k."NAME",k."USE_LIKE",k."ESC",k."PROC",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_SKIP") k
/

comment on table CDB_LOGSTDBY_SKIP
is 'List the skip settings choosen in all containers'
/

