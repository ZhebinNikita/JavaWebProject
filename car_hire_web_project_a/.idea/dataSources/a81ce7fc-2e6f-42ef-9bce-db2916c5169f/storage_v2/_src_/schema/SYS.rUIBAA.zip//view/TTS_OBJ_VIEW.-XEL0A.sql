create view TTS_OBJ_VIEW as
  select obj#,
       dataobj#,
       owner#,
       name,
       namespace,
       subname,
       type#,
       ctime,
       mtime,
       stime,
       status,
       remoteowner,
       linkname,
       flags,
       oid$,
       spare1,
       spare2,
       spare3,
       spare4,
       spare5,
       spare6
from "_CURRENT_EDITION_OBJ" where bitand(flags, 128)=0
/

