create view CDB_LOGMNR_PURGED_LOG as
  SELECT k."FILE_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGMNR_PURGED_LOG") k
/

comment on table CDB_LOGMNR_PURGED_LOG
is ' in all containers'
/

