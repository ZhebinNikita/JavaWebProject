create view LOGSTDBY_LOG as
  select first_change#, next_change#, sequence#, thread#,
         first_time, next_time
  from system.logmnr_log$ where session# =
     (select value from system.logstdby$parameters where name = 'LMNR_SID')
    /* comment */
 union
  select first_change#, (last_change# + 1) next_change#, sequence#, thread#,
         first_time, last_time next_time
  from v$standby_log where status = 'ACTIVE'
/

