create view KU$_OPTION_VIEW_OBJNUM_VIEW as
  select oo.obj_num,oo.schema_obj.owner_name,oo.schema_obj.name,
        oo.impc_flags, oo.tag, oo.alt_name, oo.alt_schema
  from ku$_option_objnum_view oo
  where oo.tgt_type=4            /* type is 'view' */

