create view KU$_XMLSCHEMA_ELMT_VIEW as
  select
    opq.obj#,
    opq.intcol#,
    opq.schemaoid,
    extractValue(value(schm),
        '/schema/@x:schemaURL',
        'xmlns="http://www.w3.org/2001/XMLSchema"'||
          ' xmlns:x="http://xmlns.oracle.com/xdb"'),
    opq.elemnum,
    DBMS_XMLSCHEMA.GetSchemaElementName( opq.schemaoid,opq.elemnum)
  from sys.opqtype$ opq, xdb.xdb$schema schm
  where opq.schemaoid = schm.sys_nc_oid$
/

