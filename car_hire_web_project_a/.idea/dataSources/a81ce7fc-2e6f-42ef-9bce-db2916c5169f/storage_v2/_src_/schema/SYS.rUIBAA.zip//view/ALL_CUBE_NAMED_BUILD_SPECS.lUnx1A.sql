create view ALL_CUBE_NAMED_BUILD_SPECS as
  SELECT
  u.name OWNER,
  o.name CUBE_NAME,
  syn.syntax_clob NAMED_BUILD_SPEC
FROM
  olap_cubes$ c,
  user$ u,
  obj$ o,
  olap_syntax$ syn,
  (SELECT
    obj#,
    MIN(have_dim_access) have_all_dim_access
   FROM
    (SELECT
      c.obj# obj#,
      (CASE
        WHEN
        (do.owner# in (userenv('SCHEMAID'), 1)   -- public objects
         or do.obj# in
              ( select obj#  -- directly granted privileges
                from sys.objauth$
                where grantee# in ( select kzsrorol from x$kzsro )
              )
         or   -- user has system privileges
                ora_check_SYS_privilege (do.owner#, do.type#) = 1
        )
        THEN 1
        ELSE 0
       END) have_dim_access
    FROM
      olap_cubes$ c,
      olap_dimensionality$ diml,
      olap_cube_dimensions$ dim,
      obj$ do
    WHERE
      do.obj# = dim.obj#
      AND diml.dimensioned_object_type = 1 --CUBE
      AND diml.dimensioned_object_id = c.obj#
      AND diml.dimension_type = 11 --DIMENSION
      AND diml.dimension_id = do.obj#
    )
    GROUP BY obj# ) da
WHERE
  o.obj#=c.obj#
  AND o.obj#=da.obj#(+)
  AND o.owner#=u.user#
  AND syn.owner_id(+)=c.obj#
  AND syn.owner_type(+)=1
  AND syn.ref_role = 18 -- named build spec
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
  AND ((have_all_dim_access = 1) OR (have_all_dim_access is NULL))
/

comment on table ALL_CUBE_NAMED_BUILD_SPECS
is 'OLAP Cube Named Build Specifications in the database accessible by the user'
/

