create view CDB_CUBE_NAMED_BUILD_SPECS as
  SELECT k."OWNER",k."CUBE_NAME",k."NAMED_BUILD_SPEC",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_CUBE_NAMED_BUILD_SPECS") k
/

comment on table CDB_CUBE_NAMED_BUILD_SPECS
is 'OLAP Cube Named Build Specifications in the database in all containers'
/

