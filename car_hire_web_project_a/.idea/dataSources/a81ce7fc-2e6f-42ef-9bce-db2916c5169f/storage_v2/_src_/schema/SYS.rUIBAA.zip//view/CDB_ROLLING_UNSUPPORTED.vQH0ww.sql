create view CDB_ROLLING_UNSUPPORTED as
  SELECT k."OWNER",k."TABLE_NAME",k."COLUMN_NAME",k."ATTRIBUTES",k."DATA_TYPE",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_ROLLING_UNSUPPORTED") k
/

comment on table CDB_ROLLING_UNSUPPORTED
is 'List of all the columns that are not supported by DBMS_ROLLING upgrades in all containers'
/

