create view DBA_ADVISOR_USAGE as
  select a.advisor_id,
            d.name as advisor_name,
            a.last_exec_time,
            a.num_execs,
            a.num_db_reports,
            a.first_report_time,
            a.last_report_time
     from sys.wri$_adv_usage a, sys.wri$_adv_definitions d
     where a.advisor_id = d.id and a.advisor_id > 0
/

