create view CDB_LOGSTDBY_PLSQL_SUPPORT as
  SELECT k."OWNER",k."PKG_NAME",k."SUPPORT_LEVEL",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_PLSQL_SUPPORT") k
/

comment on table CDB_LOGSTDBY_PLSQL_SUPPORT
is 'PLSQL packages registered with logical standby in all containers'
/

