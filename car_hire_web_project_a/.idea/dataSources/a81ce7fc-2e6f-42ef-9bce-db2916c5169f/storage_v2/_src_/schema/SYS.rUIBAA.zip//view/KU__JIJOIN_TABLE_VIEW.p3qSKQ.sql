create view KU$_JIJOIN_TABLE_VIEW as
  select j.obj#, o.obj_num, o.owner_name, o.name
  from sys.ku$_schemaobj_view o, sys.jijoin$ j
  where o.obj_num in (j.tab1obj#, j.tab2obj#)
  group by j.obj#, o.obj_num, o.owner_name, o.name
  order by o.obj_num
/

