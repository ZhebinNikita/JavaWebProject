create view KU$_RADM_POLICY_VIEW as
  select '1','0',
         r.obj#,
         value(o),
         r.pname,
         rpe.pe_pexpr,
         r.enable_flag,
         cast( multiset(select * from ku$_radm_mc_view m
                        where m.obj_num = r.obj#
                       ) as ku$_radm_mc_list_t
             )
  from sys.radm$ r,
       ku$_schemaobj_view o,
       sys.radm_pe$ rpe
  where r.obj# = o.obj_num
    and r.obj# = rpe.pe_obj#
/

