create view DBA_ADVISOR_EXECUTION_TYPES as
  select d.name advisor_name, e.name execution_type,
            dbms_advisor.format_message(e.description) execution_description
  from wri$_adv_definitions d, wri$_adv_def_exec_types e
  where d.id = e.advisor_id
/

