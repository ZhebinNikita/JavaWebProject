create view V_$LOGSTDBY as
  select "SERIAL#","LOGSTDBY_ID","PID","TYPE","STATUS_CODE","STATUS","HIGH_SCN","CON_ID" from v$logstdby
/

