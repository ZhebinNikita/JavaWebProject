create view KU$_FBA_PERIOD_VIEW as
  select '1','0',
            fb.obj#,
            fb.periodname,
            fb.flags,
            fb.periodstart,
            fb.periodend,
            fb.spare
      from sys.sys_fba_period fb
/

