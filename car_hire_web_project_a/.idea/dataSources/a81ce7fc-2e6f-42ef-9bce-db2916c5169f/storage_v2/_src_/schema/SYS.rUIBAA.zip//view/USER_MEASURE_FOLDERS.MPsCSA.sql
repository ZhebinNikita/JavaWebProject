create view USER_MEASURE_FOLDERS as
  SELECT
  o.name MEASURE_FOLDER_NAME,
  mf.obj# MEASURE_FOLDER_ID,
  d.description_value DESCRIPTION
FROM
  olap_measure_folders$ mf,
  obj$ o,
  (select d.* from olap_descriptions$ d, nls_session_parameters n where
        n.parameter = 'NLS_LANGUAGE'
        and d.description_type = 'Description'
        and d.owning_object_type = 10 --MEASURE_FOLDER
        and (d.language = n.value
             or d.language like n.value || '\_%' escape '\')) d
WHERE
  mf.obj# = o.obj#
  AND o.owner# = USERENV('SCHEMAID')
  AND mf.obj# = d.owning_object_id(+)
/

comment on table USER_MEASURE_FOLDERS
is 'OLAP Measure Folders owned by the user in the database'
/

