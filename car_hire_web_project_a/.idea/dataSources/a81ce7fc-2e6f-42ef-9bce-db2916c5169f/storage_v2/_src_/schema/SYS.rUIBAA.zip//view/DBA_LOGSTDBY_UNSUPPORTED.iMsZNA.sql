create view DBA_LOGSTDBY_UNSUPPORTED as
  with redo_compat as
         (select nvl((select min(s.redo_compat)
                      from system.logstdby$parameters p,
                           system.logmnr_session$ s,
                           sys.v$database d
                      where p.name in ('LMNR_SID', 'FUTURE_SESSION') and
                            p.value = s.session# and
                            d.database_role = 'LOGICAL STANDBY'),
                     (select p.value
                      from sys.v$parameter p
                      where p.name = 'compatible')) compat
          from dual)
  select owner, table_name, column_name, attributes,
  substr(decode(type#, 1, decode(charsetform, 2, 'NVARCHAR2', 'VARCHAR2'),
                2, decode(scale, null, decode(precision#, null,
                          'NUMBER', 'FLOAT'), 'NUMBER'),
                8, 'LONG',
                9, decode(charsetform, 2, 'NCHAR VARYING', 'VARCHAR'),
                12, 'DATE',
                23, 'RAW',
                24, 'LONG RAW',
                58, 'OPAQUE',
                69, 'ROWID',
                96, decode(charsetform, 2, 'NCHAR', 'CHAR'),
                100, 'BINARY_FLOAT',
                101, 'BINARY_DOUBLE',
                105, 'MLSLABEL',
                106, 'MLSLABEL',
                110, 'REF',
                111, 'REF',
                112, decode(charsetform, 2, 'NCLOB', 'CLOB'),
                113, 'BLOB',
                114, 'BFILE',
                115, 'CFILE',
                121, 'OBJECT',
                122, 'NESTED TABLE',
                123, 'VARRAY',
                178, 'TIME(' ||scale|| ')',
                179, 'TIME(' ||scale|| ')' || ' WITH TIME ZONE',
                180, 'TIMESTAMP(' ||scale|| ')',
                181, 'TIMESTAMP(' ||scale|| ')' || ' WITH TIME ZONE',
                231, 'TIMESTAMP(' ||scale|| ')' || ' WITH LOCAL TIME ZONE',
                182, 'INTERVAL YEAR(' ||precision#||') TO MONTH',
                183, 'INTERVAL DAY(' ||precision#||') TO SECOND('
                                     || scale || ')',
                208, 'UROWID',
                'UNDEFINED'),1,32) data_type
  from (
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_10_1 u, redo_compat c
    where c.compat like '10.0%' or c.compat like '10.1%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_10_2 u, redo_compat c
    where c.compat like '10.2%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_11_1 u, redo_compat c
    where c.compat like '11.0%' or c.compat like '11.1%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_11_2 u, redo_compat c
    where c.compat like '11.2%' and c.compat not like '11.2.0.3%'
                                and c.compat not like '11.2.0.4%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_11_2b u, redo_compat c
    where c.compat like '11.2.0.3%' or c.compat like '11.2.0.4%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_12_1 u, redo_compat c
    where c.compat like '12.0%' or c.compat like '12.1%'
    UNION ALL
    select u.owner, u.table_name, u.column_name, u.scale, u.precision#,
           u.charsetform, u.type#, u.attributes, u.gensby
    from logstdby_unsupport_tab_12_2 u, redo_compat c
    where c.compat like '12.2%'
)
  where gensby = 0
/

comment on table DBA_LOGSTDBY_UNSUPPORTED
is 'List of all the columns that are not supported by Logical Standby'
/

