create view CDB_LOGSTDBY_HISTORY as
  SELECT k."STREAM_SEQUENCE#",k."STATUS",k."SOURCE",k."DBID",k."FIRST_CHANGE#",k."LAST_CHANGE#",k."FIRST_TIME",k."LAST_TIME",k."DGNAME",k."MERGE_CHANGE#",k."PROCESSED_CHANGE#",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_HISTORY") k
/

comment on table CDB_LOGSTDBY_HISTORY
is 'Information on processed, active, and pending log streams in all containers'
/

