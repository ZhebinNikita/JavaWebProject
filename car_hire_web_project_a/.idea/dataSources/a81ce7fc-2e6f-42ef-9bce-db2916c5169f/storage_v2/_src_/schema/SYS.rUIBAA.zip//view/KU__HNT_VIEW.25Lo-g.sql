create view KU$_HNT_VIEW as
  select t.obj#,
        (select value(po) from ku$_partobj_view po
         where po.obj_num = t.obj#),
         t.property,
        (select value(s) from ku$_storage_view s
         where     t.file#  = s.file_num
             and   t.block# = s.block_num
             and   t.ts#    = s.ts_num),
        (select value(s) from ku$_deferred_stg_view s
         where s.obj_num = t.obj#),
        (select ts.name from ts$ ts where t.ts# = ts.ts#),
        (select ts.blocksize from ts$ ts where t.ts# = ts.ts#),
        t.pctfree$, t.pctused$, t.initrans, t.maxtrans, t.flags,
         cast( multiset(select * from ku$_constraint0_view con
                        where con.obj_num = t.obj#
                        and con.contype not in (7,11)
                       ) as ku$_constraint0_list_t
             ),
         cast( multiset(select * from ku$_constraint1_view con
                        where con.obj_num = t.obj#
                       ) as ku$_constraint1_list_t
             ),
         cast( multiset(select * from ku$_constraint2_view con
                        where con.obj_num = t.obj#
                       ) as ku$_constraint2_list_t
             ),
         cast( multiset(select * from ku$_pkref_constraint_view con
                        where con.obj_num = t.obj#
                       ) as ku$_pkref_constraint_list_t
             )
  from tab$ t where bitand(t.property,64+512) = 0 -- skip IOT and overflow segs
/

