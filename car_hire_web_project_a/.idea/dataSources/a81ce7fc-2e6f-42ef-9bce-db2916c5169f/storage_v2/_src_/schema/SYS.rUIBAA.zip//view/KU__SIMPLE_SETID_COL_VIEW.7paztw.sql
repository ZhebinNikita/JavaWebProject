create view KU$_SIMPLE_SETID_COL_VIEW as
  select c.obj#,
         c.col#,
         c.intcol#,
         c.segcol#,
         (bitand(c.property,4294967295) + BITAND(c2.property,1)),
         trunc(c.property / power(2,32)),
         c2.name,
         (select a.name
          from attrcol$ a
          where a.obj# = c2.obj# and
                a.intcol# = c2.intcol#),
         c.type#,
         c.deflength,
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
                or c.deflength > 4000
           then null
           else
             sys.dbms_metadata_util.func_index_default(c.deflength,
                                                       c.rowid)
         end,
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
                or c.deflength <= 4000
           then null
           when c.deflength <= 32000
           then
             sys.dbms_metadata_util.func_index_defaultc(c.deflength,
                                                        c.rowid)
           else
             sys.dbms_metadata_util.long2clob(c.deflength,
                                              'SYS.COL$',
                                              'DEFAULT$',
                                              c.rowid)
         end,
         case
           when c.deflength is null or bitand(c.property,32+65536)=0
           then null
           else
            (select sys.dbms_metadata.parse_default(u.name,o.name,
                                                    c.deflength,c.rowid)
             from obj$ o, user$ u
             where o.obj#=c.obj# and o.owner#=u.user#)
         end
  from col$ c, col$ c2
  where BITAND(c.property, 1024) = 1024 and                  /* SETID column */
        c2.obj# = c.obj# and
        c2.col# = c.col# and
        c2.intcol# = (c.intcol# - 1) and
        c2.segcol# = 0
/

