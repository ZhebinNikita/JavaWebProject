create view KU$_10_1_OBJGRANT_VIEW as
  select g.* from ku$_objgrant_view g
  where g.privname!='READ' or g.base_obj.type_num=23
/

