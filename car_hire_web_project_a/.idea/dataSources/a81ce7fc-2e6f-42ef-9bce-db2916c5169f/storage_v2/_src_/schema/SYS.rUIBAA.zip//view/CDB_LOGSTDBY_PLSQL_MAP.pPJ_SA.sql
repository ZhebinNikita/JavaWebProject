create view CDB_LOGSTDBY_PLSQL_MAP as
  SELECT k."OWNER",k."PKG_NAME",k."PROC_NAME",k."INTERNAL_PKG_NAME",k."INTERNAL_PROC_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_PLSQL_MAP") k
/

comment on table CDB_LOGSTDBY_PLSQL_MAP
is 'PLSQL mapping from user invokable procedure to supp-log pragma-ed procedure in all containers'
/

