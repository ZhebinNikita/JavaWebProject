create view KU$_VIEW_EXISTS_VIEW as
  select o.obj#, o.name, u.name
 from obj$ o, user$ u
 where o.owner# = u.user#
 and o.type# = 4
 and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' )     OR
                EXISTS ( SELECT 1 FROM all_objects ao
                        WHERE o.obj# = ao.object_id))
/

