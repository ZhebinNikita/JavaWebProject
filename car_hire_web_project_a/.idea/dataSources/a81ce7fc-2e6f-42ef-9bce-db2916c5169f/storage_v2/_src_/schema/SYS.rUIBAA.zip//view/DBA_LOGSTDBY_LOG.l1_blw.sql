create view DBA_LOGSTDBY_LOG as
  select thread#, resetlogs_change#, reset_timestamp resetlogs_id, sequence#,
         first_change#, next_change#, first_time, next_time, file_name,
          timestamp, dict_begin, dict_end,
    (case when l.next_change# <= p.read_scn then 'YES'
          when ((bitand(l.contents, 16) = 16) and
                (bitand(l.status, 4) = 0)) then 'FETCHING'
          when ((bitand(l.contents, 16) = 16) and
                (bitand(l.status, 4) = 4)) then 'CORRUPT'
          when l.first_change# < p.applied_scn then 'CURRENT'
          else 'NO' end) applied, blocks, block_size
  from system.logmnr_log$ l, dba_logstdby_progress p
  where session# =
    (select value from system.logstdby$parameters where name = 'LMNR_SID') and
    (flags is NULL or bitand(l.flags,16) = 0)
/

comment on table DBA_LOGSTDBY_LOG
is 'List the information about received logs from the primary'
/

