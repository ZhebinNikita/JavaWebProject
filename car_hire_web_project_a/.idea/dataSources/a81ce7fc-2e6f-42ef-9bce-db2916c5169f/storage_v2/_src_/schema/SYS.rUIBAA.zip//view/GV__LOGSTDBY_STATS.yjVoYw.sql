create view GV_$LOGSTDBY_STATS as
  select "INST_ID","NAME","VALUE","CON_ID" from gv$logstdby_stats
/

