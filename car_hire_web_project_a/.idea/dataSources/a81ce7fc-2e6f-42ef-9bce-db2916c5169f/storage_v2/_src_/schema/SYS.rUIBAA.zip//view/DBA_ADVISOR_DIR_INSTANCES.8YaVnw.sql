create view DBA_ADVISOR_DIR_INSTANCES as
  select a.dir_id as directive_id,
             a.inst_id as instance_id,
             a.name as instance_name,
             a.data as data
      from wri$_adv_directive_instances a
      where a.task_id = 0
/

