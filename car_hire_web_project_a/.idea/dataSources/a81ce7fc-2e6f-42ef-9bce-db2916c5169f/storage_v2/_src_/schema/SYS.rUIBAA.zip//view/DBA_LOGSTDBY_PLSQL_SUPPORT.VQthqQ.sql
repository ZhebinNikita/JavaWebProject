create view DBA_LOGSTDBY_PLSQL_SUPPORT as
  select name as owner, name2 as pkg_name,
         case when (action = -6) then 'DBMS_ROLLING'
                                 else 'ALWAYS'
              end as support_level
  from system.logstdby$skip_support
  where action = -6 or action = -8 or action = -10
  order by owner, pkg_name
/

comment on table DBA_LOGSTDBY_PLSQL_SUPPORT
is 'PLSQL packages registered with logical standby'
/

