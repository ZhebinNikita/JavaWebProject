create view GV_$LOGSTDBY_STATE as
  select "INST_ID","PRIMARY_DBID","PRIMARY_CON_DBID","SESSION_ID","REALTIME_APPLY","STATE","CON_ID" from gv$logstdby_state
/

