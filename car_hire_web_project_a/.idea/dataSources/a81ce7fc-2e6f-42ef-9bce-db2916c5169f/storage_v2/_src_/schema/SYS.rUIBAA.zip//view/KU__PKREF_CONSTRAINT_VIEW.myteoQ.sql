create view KU$_PKREF_CONSTRAINT_VIEW as
  select rf.obj#, rf.col#, rf.intcol#, rf.reftyp, c.property, c.name,
        (select a.name from attrcol$ a
                 where a.obj#=rf.obj# and a.intcol#=rf.intcol#),
        (select value(o) from ku$_schemaobj_view o, obj$ oo
                 where rf.stabid = oo.oid$
                    and oo.obj#  = o.obj_num),
        nvl((select 1
             from coltype$ fct, ccol$ fcc, cdef$ fcd
             where fct.obj# = rf.obj# and
                   fct.intcol# = rf.intcol# and
                   fcc.obj# = rf.obj# and
                   fcc.intcol# =
                     UTL_RAW.CAST_TO_BINARY_INTEGER(
                       SUBSTRB(fct.intcol#s, 1, 2), 3) and
                   fcd.con# = fcc.con# and
                   fcd.type# = 4), 0),
        decode(bitand(rf.reftyp,4),
                       4, cast(multiset
                                (select rc.*
                                 from   ku$_simple_col_view rc, ccol$ rcc
                                 where  rcc.con# =
                                            (select con#
                                             from   obj$ ro, cdef$ rcd
                                             where  ro.oid$ = rf.stabid and
                                                    rcd.obj# = ro.obj# and
                                                    rcd.type# = 2)       and
                                          rc.obj_num = rcc.obj# and
                                          rc.intcol_num = rcc.intcol#
                                  order by rcc.pos#
                                ) as ku$_simple_col_list_t),
                       null)
 from refcon$ rf, col$ c
 where c.obj#=rf.obj# and c.intcol#=rf.intcol#
/

