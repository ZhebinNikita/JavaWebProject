create view KU$_12_1_SYSGRANT_VIEW as
  select * from ku$_sysgrant_view t
  where t.privilege >  -398
/

