create view CDB_LOGSTDBY_EVENTS as
  SELECT k."EVENT_TIME",k."EVENT_TIMESTAMP",k."START_SCN",k."CURRENT_SCN",k."COMMIT_SCN",k."XIDUSN",k."XIDSLT",k."XIDSQN",k."EVENT",k."STATUS_CODE",k."STATUS",k."SRC_CON_NAME",k."SRC_CON_ID",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_EVENTS") k
/

comment on table CDB_LOGSTDBY_EVENTS
is 'Information on why logical standby events in all containers'
/

