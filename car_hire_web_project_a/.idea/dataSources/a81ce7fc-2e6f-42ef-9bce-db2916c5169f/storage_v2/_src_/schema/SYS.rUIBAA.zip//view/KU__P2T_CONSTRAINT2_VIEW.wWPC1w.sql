create view KU$_P2T_CONSTRAINT2_VIEW as
  select c.owner#, c.name, c.con#, cd.obj#, cd.cols, cd.type#,
          cd.robj#, cd.rcon#, cd.rrules, cd.match#, cd.refact,
          NVL(cd.enabled,0),
          cd.intcols, to_char(cd.mtime,'YYYY/MM/DD HH24:MI:SS'),
          nvl((cd.defer-bitand(cd.defer,512+1024)),0), -- cd.defer becomes <FLAGS>.
          (select value(o) from ku$_schemaobj_view o
                where o.obj_num = cd.robj#),
          cast( multiset(select * from ku$_constraint_col_view col
                        where col.con_num = c.con#
                        order by col.pos_num
                        ) as ku$_constraint_col_list_t
                ),
          cast( multiset(select * from ku$_constraint_col_view col
                        where col.con_num = cd.rcon#
                        order by col.pos_num
                        ) as ku$_constraint_col_list_t
                )
   from con$ c, cdef$ cd
   where c.con# = cd.con#
     and cd.type# = 4           -- referential constraint
/

