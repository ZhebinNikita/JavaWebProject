create view KU$_RADM_FPTM_VIEW as
  select '1','0',
           numbercol, binfloatcol, bindoublecol,
           charcol, varcharcol, ncharcol, nvarcharcol,
           datecol,ts_col,tswtz_col, fpver
    from sys.radm_fptm$
    where fpver=1
/

