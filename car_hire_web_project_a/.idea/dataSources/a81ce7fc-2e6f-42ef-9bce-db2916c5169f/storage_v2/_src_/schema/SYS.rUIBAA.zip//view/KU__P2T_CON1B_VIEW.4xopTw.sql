create view KU$_P2T_CON1B_VIEW as
  select *
   from  ku$_constraint1_view cv
   where cv.contype not in (2,3)
                               -- table check (condition-no keys) (1),
                               -- supplemental log groups (w/ keys) (12),
                               -- supplemental log data (no keys) (14,15,16,17)
/

