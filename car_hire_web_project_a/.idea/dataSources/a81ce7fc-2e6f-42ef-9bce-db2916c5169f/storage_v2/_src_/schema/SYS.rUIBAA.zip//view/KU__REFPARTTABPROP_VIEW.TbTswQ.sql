create view KU$_REFPARTTABPROP_VIEW as
  select t.obj_num,t.name,t.schema,t.flags,t.property from ku$_tabprop_view t
 where bitand(t.property,32+64+128+256+512)=32
 and exists( select * from partobj$ po
             where po.obj# = t.obj_num and po.parttype = 5)
/

