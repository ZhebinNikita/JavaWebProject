create view KU$_TABCLUSTER_VIEW as
  select t.obj#,
         value(cl),
         cast(multiset(select * from ku$_tabcluster_col_view c
                       where c.obj_num = t.obj#
                        order by c.segcol_num
                      ) as ku$_simple_col_list_t
             )
  from  ku$_schemaobj_view cl, sys.tab$ t
  where bitand(t.property,1024) = 1024          -- clustered table
    and cl.obj_num = t.bobj#
/

