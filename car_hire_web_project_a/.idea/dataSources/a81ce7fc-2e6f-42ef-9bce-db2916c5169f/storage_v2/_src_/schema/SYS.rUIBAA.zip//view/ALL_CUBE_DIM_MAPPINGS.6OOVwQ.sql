create view ALL_CUBE_DIM_MAPPINGS as
  SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  null HIERARCHY_NAME,
  dl.level_name LEVEL_NAME,
  m.map_name MAP_NAME,
  m.map_id MAP_ID,
  'DIMENSION LEVEL' MAPPED_DIMENSION_TYPE,
  null MAPPED_HIERARCHY_TYPE,
  s1.syntax_clob QUERY,
  s2.syntax_clob KEY_EXPRESSION,
  s3.syntax_clob FROM_CLAUSE,
  s4.syntax_clob WHERE_CLAUSE,
  null JOIN_CONDITION,
  null LEVEL_ID_EXPRESSION,
  null PARENT_EXPRESSION,
  null PARENT_LEVEL_ID_EXPRESSION,
  null LEVEL_EXPRESSION
FROM
  olap_mappings$ m,
  user$ u,
  obj$ o,
  olap_dim_levels$ dl,
  olap_syntax$ s1,
  olap_syntax$ s2,
  olap_syntax$ s3,
  olap_syntax$ s4
WHERE
  m.map_type in (18, 19, 20, 21)
  AND m.mapping_owner_type = 12 -- dim_level
  AND m.mapping_owner_id = dl.level_id
  AND dl.dim_obj# = o.obj#
  AND o.owner#=u.user#
  AND m.map_id = s1.owner_id(+)
  AND m.map_type = s1.owner_type(+)
  AND s1.ref_role(+) = 3
  AND m.map_id = s2.owner_id(+)
  AND m.map_type = s2.owner_type(+)
  AND s2.ref_role(+) = 6
  AND m.map_id = s3.owner_id(+)
  AND m.map_type = s3.owner_type(+)
  AND s3.ref_role(+) = 22
  AND m.map_id = s4.owner_id(+)
  AND m.map_type = s4.owner_type(+)
  AND s4.ref_role(+) = 21
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  h.hierarchy_name HIERARCHY_NAME,
  dl.level_name LEVEL_NAME,
  m.map_name MAP_NAME,
  m.map_id MAP_ID,
  'HIERARCHY LEVEL' MAPPED_DIMENSION_TYPE,
  DECODE(h.hierarchy_type, 1, 'LEVEL', 2, 'VALUE') MAPPED_HIERARCHY_TYPE,
  s1.syntax_clob QUERY,
  s2.syntax_clob KEY_EXPRESSION,
  s3.syntax_clob FROM_CLAUSE,
  s4.syntax_clob WHERE_CLAUSE,
  s5.syntax_clob JOIN_CONDITION,
  null LEVEL_ID_EXPRESSION,
  null PARENT_EXPRESSION,
  null PARENT_LEVEL_ID_EXPRESSION,
  null LEVEL_EXPRESSION
FROM
  olap_mappings$ m,
  user$ u,
  obj$ o,
  olap_dim_levels$ dl,
  olap_hier_levels$ hl,
  olap_hierarchies$ h,
  olap_syntax$ s1,
  olap_syntax$ s2,
  olap_syntax$ s3,
  olap_syntax$ s4,
  olap_syntax$ s5
WHERE
  m.map_type in (18, 19, 20, 21)
  AND m.mapping_owner_type = 14 -- hier_level
  AND m.mapping_owner_id = hl.hierarchy_level_id
  AND hl.dim_level_id = dl.level_id
  AND hl.hierarchy_id = h.hierarchy_id
  AND h.dim_obj# = o.obj#
  AND o.owner#=u.user#
  AND m.map_id = s1.owner_id(+)
  AND m.map_type = s1.owner_type(+)
  AND s1.ref_role(+) = 3
  AND m.map_id = s2.owner_id(+)
  AND m.map_type = s2.owner_type(+)
  AND s2.ref_role(+) = 6
  AND m.map_id = s3.owner_id(+)
  AND m.map_type = s3.owner_type(+)
  AND s3.ref_role(+) = 22
  AND m.map_id = s4.owner_id(+)
  AND m.map_type = s4.owner_type(+)
  AND s4.ref_role(+) = 21
  AND m.map_id = s5.owner_id(+)
  AND m.map_type = s5.owner_type(+)
  AND s5.ref_role(+) = 7
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  h.hierarchy_name HIERARCHY_NAME,
  null LEVEL_NAME,
  m.map_name MAP_NAME,
  m.map_id MAP_ID,
  'HIERARCHY' MAPPED_DIMENSION_TYPE,
  DECODE(h.hierarchy_type, 1, 'LEVEL', 2, 'VALUE') MAPPED_HIERARCHY_TYPE,
  s1.syntax_clob QUERY,
  s2.syntax_clob KEY_EXPRESSION,
  s3.syntax_clob FROM_CLAUSE,
  s4.syntax_clob WHERE_CLAUSE,
  null JOIN_CONDITION,
  s5.syntax_clob LEVEL_ID_EXPRESSION,
  s6.syntax_clob PARENT_EXPRESSION,
  s7.syntax_clob PARENT_LEVEL_ID_EXPRESSION,
  s8.syntax_clob LEVEL_EXPRESSION
FROM
  olap_mappings$ m,
  user$ u,
  obj$ o,
  olap_hierarchies$ h,
  olap_syntax$ s1,
  olap_syntax$ s2,
  olap_syntax$ s3,
  olap_syntax$ s4,
  olap_syntax$ s5,
  olap_syntax$ s6,
  olap_syntax$ s7,
  olap_syntax$ s8
WHERE
  m.map_type in (18, 19, 20, 21)
  AND m.mapping_owner_type = 13 -- hierarchy
  AND m.mapping_owner_id = h.hierarchy_id
  AND h.dim_obj# = o.obj#
  AND o.owner#=u.user#
  AND m.map_id = s1.owner_id(+)
  AND m.map_type = s1.owner_type(+)
  AND s1.ref_role(+) = 3
  AND m.map_id = s2.owner_id(+)
  AND m.map_type = s2.owner_type(+)
  AND s2.ref_role(+) = 6
  AND m.map_id = s3.owner_id(+)
  AND m.map_type = s3.owner_type(+)
  AND s3.ref_role(+) = 22
  AND m.map_id = s4.owner_id(+)
  AND m.map_type = s4.owner_type(+)
  AND s4.ref_role(+) = 21
  AND m.map_id = s5.owner_id(+)
  AND m.map_type = s5.owner_type(+)
  AND s5.ref_role(+) = 8
  AND m.map_id = s6.owner_id(+)
  AND m.map_type = s6.owner_type(+)
  AND s6.ref_role(+) = 9
  AND m.map_id = s7.owner_id(+)
  AND m.map_type = s7.owner_type(+)
  AND s7.ref_role(+) = 10
  AND m.map_id = s8.owner_id(+)
  AND m.map_type = s8.owner_type(+)
  AND s8.ref_role(+) = 11
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
UNION ALL
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  null HIERARCHY_NAME,
  null LEVEL_NAME,
  m.map_name MAP_NAME,
  m.map_id MAP_ID,
  'PRIMARY DIMENSION' MAPPED_DIMENSION_TYPE,
  null MAPPED_HIERARCHY_TYPE,
  s1.syntax_clob QUERY,
  s2.syntax_clob KEY_EXPRESSION,
  s3.syntax_clob FROM_CLAUSE,
  s4.syntax_clob WHERE_CLAUSE,
  null JOIN_CONDITION,
  null LEVEL_ID_EXPRESSION,
  null PARENT_EXPRESSION,
  null PARENT_LEVEL_ID_EXPRESSION,
  null LEVEL_EXPRESSION
FROM
  olap_mappings$ m,
  user$ u,
  obj$ o,
  olap_syntax$ s1,
  olap_syntax$ s2,
  olap_syntax$ s3,
  olap_syntax$ s4
WHERE
  m.map_type in (18, 19, 20, 21)
  AND m.mapping_owner_type = 11 -- dimension
  AND m.mapping_owner_id = o.obj#
  AND o.owner#=u.user#
  AND m.map_id = s1.owner_id(+)
  AND m.map_type = s1.owner_type(+)
  AND s1.ref_role(+) = 3
  AND m.map_id = s2.owner_id(+)
  AND m.map_type = s2.owner_type(+)
  AND s2.ref_role(+) = 6
  AND m.map_id = s3.owner_id(+)
  AND m.map_type = s3.owner_type(+)
  AND s3.ref_role(+) = 22
  AND m.map_id = s4.owner_id(+)
  AND m.map_type = s4.owner_type(+)
  AND s4.ref_role(+) = 21
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
/

comment on table ALL_CUBE_DIM_MAPPINGS
is 'OLAP Cube Dimension Mappings in the database that are accessible to the user'
/

