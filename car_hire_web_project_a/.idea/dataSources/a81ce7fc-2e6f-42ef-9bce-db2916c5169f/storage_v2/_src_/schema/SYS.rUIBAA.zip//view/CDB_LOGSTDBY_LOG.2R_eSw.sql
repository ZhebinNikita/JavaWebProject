create view CDB_LOGSTDBY_LOG as
  SELECT k."THREAD#",k."RESETLOGS_CHANGE#",k."RESETLOGS_ID",k."SEQUENCE#",k."FIRST_CHANGE#",k."NEXT_CHANGE#",k."FIRST_TIME",k."NEXT_TIME",k."FILE_NAME",k."TIMESTAMP",k."DICT_BEGIN",k."DICT_END",k."APPLIED",k."BLOCKS",k."BLOCK_SIZE",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_LOG") k
/

comment on table CDB_LOGSTDBY_LOG
is 'List the information about received logs from the primary in all containers'
/

