create view DBA_LOGSTDBY_SKIP_TRANSACTION as
  select xidusn, xidslt, xidsqn, con_name
  from system.logstdby$skip_transaction
/

comment on table DBA_LOGSTDBY_SKIP_TRANSACTION
is 'List the transactions to be skipped'
/

