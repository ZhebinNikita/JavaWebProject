create view KU$_10_1_HTABLE_VIEW as
  select t.* from ku$_htable_view t
  where bitand(t.trigflag,65536+131072)=0
/

