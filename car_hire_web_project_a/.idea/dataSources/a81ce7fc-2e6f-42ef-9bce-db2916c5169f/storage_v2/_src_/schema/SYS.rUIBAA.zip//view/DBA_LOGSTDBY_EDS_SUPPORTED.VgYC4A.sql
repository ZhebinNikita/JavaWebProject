create view DBA_LOGSTDBY_EDS_SUPPORTED as
  select distinct owner, table_name from
        dba_logstdby_unsupported_table un,
        tab$ t,
        obj$ o,
        user$ u,
        cdef$ c
  where
        /* get a handle on tab$ row to eliminate uninteresting tables */
        o.name = un.table_name and
        o.type# = 2 and
        u.user# = o.owner# and
        un.owner = u.name and
        o.obj# = t.obj# and
        (bitand(t.property, 7) = 2 or   /* not an object table but has an
                                         * object column and no nested-table
                                         * columns:
                                         * 1  -- typed table
                                         * 2  -- has ADT columns
                                         * 4  -- has nested-table columns
                                         */
        bitand(t.property, 21) = 16)    /* has varray columns
                                         * 1  -- typed table
                                         * 4  -- has nested-table columns
                                         * 16 -- has a varray column
                                         */
        and c.obj# = o.obj# and c.type# = 2     /* has a primary key */
        and
        /*
         * evaluate all columns, hidden or not, to determine whether any that
         * are not system generated, including object attributes, fall outside
         * of the supported set
         */
        (un.owner, un.table_name) NOT IN
        (select distinct owner,table_name from dba_tab_cols d where
                d.owner=un.owner and d.table_name=un.table_name
                and
                ((d.data_type_owner IS NULL or
                 d.data_type_owner = 'SYS' or
                 d.data_type_owner = 'MDSYS')
                and d.qualified_col_name not like 'SYS_NC%'
                and d.qualified_col_name not like '"SYS_NC%'
                and d.data_type != 'NUMBER'
                and d.data_type != 'VARCHAR2'
                and d.data_type != 'RAW'
                and d.data_type != 'DATE'
                and d.data_type != 'FLOAT'
                and d.data_type != 'INTEGER'
                and d.data_type != 'CHAR'
                and d.data_type != 'NCHAR'
                and d.data_type != 'NVARCHAR2'
                and d.data_type != 'BINARY_FLOAT'
                and d.data_type != 'BINARY_DOUBLE'
                and not d.data_type LIKE 'TIMESTAMP(%'
                and not d.data_type LIKE 'INTERVAL %'
                and d.data_type != 'SDO_GEOMETRY'
                and d.data_type != 'SDO_ELEM_INFO_ARRAY'
                and d.data_type != 'SDO_ORDINATE_ARRAY'
                and d.data_type != 'XMLTYPE'
                and d.data_type != 'CLOB'
                and d.data_type != 'NCLOB'
                and d.data_type != 'BLOB'
                ) or
                (d.data_type = 'XMLTYPE'        -- disallow XMLTYPE attribute
                and (d.data_type_owner = 'PUBLIC' or d.data_type_owner = 'SYS')
                and d.qualified_col_name != d.column_name)
                )
/

comment on table DBA_LOGSTDBY_EDS_SUPPORTED
is 'List of all tables that could have EDS-based replication for Logical Standby'
/

