create view KU$_XMLSCHEMA_VIEW as
  select '1','0',
        u.user#, u.name, x.schema_url, x.schema_id,
        (case when x.local='YES' then 1 else 0 end
         + case when x.binary='YES' then 2 else 0 end),
        xlvl.lvl,
        value(s).getClobVal(),
        xdb.dbms_xdbutil_int.XMLSchemaStripUsername(XMLTYPE(
                                                    value(s).getClobVal()),
                                                    u.name)    -- stripped
    from sys.user$ u, sys.dba_xml_schemas x, xdb.xdb$schema s,
         sys.dba_xmlschema_level_view xlvl
    where x.owner=u.name and xlvl.schema_oid = x.schema_id and
          s.sys_nc_oid$ = x.schema_id and
          (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (u.user#, 0) OR
                EXISTS ( SELECT * FROM session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

