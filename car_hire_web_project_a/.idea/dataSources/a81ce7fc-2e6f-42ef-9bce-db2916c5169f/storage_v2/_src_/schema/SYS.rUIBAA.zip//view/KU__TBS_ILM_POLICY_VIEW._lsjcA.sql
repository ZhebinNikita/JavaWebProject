create view KU$_TBS_ILM_POLICY_VIEW as
  select t.ts#,t.name,
         cast( multiset(select * from ku$_ilm_policy_view2 p
                        where p.obj_num = t.ts#
                        order by p.policy_num
                        ) as ku$_ilm_policy_list_t
              )
 from ts$ t
 where exists (select 1 from ku$_ilm_policy_view2 p where p.obj_num = t.ts#)
   and (SYS_CONTEXT('USERENV','CURRENT_USERID') = 0
        OR EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

