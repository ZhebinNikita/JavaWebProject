create view KU$_IND_PARTOBJ_VIEW as
  select po.obj_num, value(po),
         cast(multiset(select * from ku$_ind_part_col_view pc
                       where pc.obj_num = i.obj#
                        order by pc.pos_num
                      ) as ku$_part_col_list_t
             ),
         cast(multiset(select * from ku$_ind_subpart_col_view sc
                       where sc.obj_num = i.obj#
                        order by sc.pos_num
                      ) as ku$_part_col_list_t
             ),
         cast(multiset(select * from ku$_ind_part_view ip
                       where ip.base_obj_num = po.obj_num
                        order by ip.part_num
                      ) as ku$_ind_part_list_t
             ),
         cast(multiset(select * from ku$_ind_compart_view icp
                       where icp.base_obj_num = po.obj_num
                        order by icp.part_num
                      ) as ku$_ind_compart_list_t
             )
  from ind$ i, ku$_partobj_view po
        where i.obj#=po.obj_num
/

