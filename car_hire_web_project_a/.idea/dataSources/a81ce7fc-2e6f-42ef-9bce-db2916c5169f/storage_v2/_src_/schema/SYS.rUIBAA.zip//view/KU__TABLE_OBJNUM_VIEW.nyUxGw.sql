create view KU$_TABLE_OBJNUM_VIEW as
  select t.obj#, 'T',
         bitand(t.property, 4294967295),
         trunc(t.property / power(2, 32)),
         t.ts#,
         value(o), value(o)
  from ku$_schemaobj_view o, sys.tab$ t
  where o.obj_num=t.obj#
  AND bitand(t.property,8192)=0                  /* is not a nested table */
  AND o.status != 5                  /* table is not invalid/unauthorized */
  AND bitand(t.flags,536870912)=0             /* not an IOT mapping table */
  AND bitand(trunc(t.property/power(2,32)),2)=0 /* not FBA internal table */
  AND bitand(t.property,power(2,44))=0    /* not an ACLMV container table */
  AND bitand(trunc(property / power(2, 64)),2)=0  /* Exclude token tables */
  AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0)
        OR EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

