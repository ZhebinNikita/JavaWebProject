create view KU$_NTPART_PARENT_VIEW as
  select t.obj#,dbms_metadata.get_partn(1,tp.bo#,tp.part#),
    cast(multiset(select
                      obj_num,
                      part_num,
                      intcol_num,
                      ntab_num,
                      schema_obj,
                      col,
                      property,
                      flags,
                      hnt
            from  ku$_ntpart_view  ntp
            where ntp.part_num=dbms_metadata.get_partn(1,tp.bo#,tp.part#) and
                  ntp.obj_num in (
                    select obj# from ntab$ nt
                      start with nt.obj#=t.obj#
                        connect by prior nt.ntab#=nt.obj#)
                ) as ku$_ntpart_list_t
        )
  from tab$ t, tabpart$ tp
  where tp.bo# = t.obj# and
        bitand(t.property,32+4) = 32+4 -- has nested tables, and is partitioned
/

