create view KU$_DUMMY_COMM_RULE_ALTS_V as
  select '0','0',NULL
    from dual
   where 1=0      -- return 0 rows
/

