create view KU$_TAB_TSUBPART_VIEW as
  select  dsp.bo#, dsp.spart_position, dsp.spart_name,
          (select( ts.name) from sys.ts$ ts where ts.ts# = dsp.ts#),
          dsp.ts#, dsp.flags, dsp.hiboundlen,
          sys.dbms_metadata_util.long2varchar( dsp.hiboundlen,
                                              'SYS.DEFSUBPART$',
                                              'HIBOUNDVAL',
                                              dsp.rowid),
          cast(multiset(select * from ku$_tlob_comppart_view tlcv
                        where  tlcv.base_objnum = dsp.bo#
                           and tlcv.spart_pos = dsp.spart_position
                        order by tlcv.intcol_num
                      ) as ku$_tlob_comppart_list_t),
          bhiboundval,
         (select svcname  from imsvc$ svc
               where svc.obj# = dsp.bo# and svc.subpart# = dsp.spart_position),
         (select svcflags from imsvc$ svc
               where svc.obj# = dsp.bo# and svc.subpart# = dsp.spart_position)
  from    sys.defsubpart$ dsp
/

