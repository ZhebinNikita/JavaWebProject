create view KU$_IND_PART_VIEW as
  select ip.obj#,
         (select value(so) from ku$_schemaobj_view so
          where so.obj_num = ip.obj#),
         ts.name, ts.blocksize,
         (select value(s) from ku$_storage_view s
          where ip.ts# = s.ts_num
          AND ip.file# = s.file_num
          AND ip.block# = s.block_num),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = ip.obj#),
         ip.dataobj#,
--part only
         ip.bo#, ip.part#,
         (select tpo.subname
           from obj$ tpo, tabpart$ tp, ind$ i
           where i.obj#=ip.bo# and
                 tp.bo#=i.bo# and
                 tp.part#=ip.part# and
                 tpo.obj#=tp.obj#),
         ip.hiboundlen,
         sys.dbms_metadata_util.long2varchar(ip.hiboundlen,
                                    'SYS.INDPART$',
                                    'HIBOUNDVAL',
                                     ip.rowid),
         ip.pctthres$,
         ip.inclcol,
         (select decode(bitand(ipp.flags, 1), 1, ipp.parameters, null)
            from indpart_param$ ipp
          where ipp.obj#=ip.obj#),
--subpart only
         null,null,null,
--both
         ip.flags, ip.pctfree$,
         ip.initrans, ip.maxtrans,
         to_char(ip.analyzetime,'YYYY/MM/DD HH24:MI:SS'), ip.samplesize,
         ip.rowcnt, ip.blevel, ip.leafcnt, ip.distkey, ip.lblkkey,
         ip.dblkkey, ip.clufac, ip.spare1, ip.spare2, ip.spare3
  from  indpart$ ip, ts$ ts
  where ts.ts#=ip.ts#
/

