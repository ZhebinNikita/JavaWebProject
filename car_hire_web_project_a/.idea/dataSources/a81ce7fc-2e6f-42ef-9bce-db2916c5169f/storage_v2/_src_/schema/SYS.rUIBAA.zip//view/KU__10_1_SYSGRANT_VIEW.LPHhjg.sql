create view KU$_10_1_SYSGRANT_VIEW as
  select * from ku$_sysgrant_view t
  where t.privilege != -233
    and t.privilege >  -276
/

