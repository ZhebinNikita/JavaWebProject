create view KU$_HTSPART_DATA_VIEW as
  select '1','2',
         tsp.obj#, tsp.obj#,
         o.subname,
         (select po.subname from obj$ po where po.obj#=tsp.pobj#),
         po.parttype,
         bitand(t.property, 4294967295),
         trunc(t.property / power(2, 32)),
         t.trigflag,
         dbms_metadata_util.get_xmltype_fmts(t.obj#),
         decode((select 1 from dual where
                 (exists (select q.obj# from sys.opqtype$ q
                          where q.obj#=t.obj#
                          and q.type=1                        /* xmltype col */
                          and bitand(q.flags,2+64)!=0))),       /* CSX or SB */
                1,'Y','N'),
         decode((select count(*)                      /* outofline xml table */
                    from sys.opqtype$ q
                    where q.obj# = t.obj# and
                          bitand(q.flags, 32) = 32 ),
                1,'Y','N'),
         'N',     /* partitioned table cannot have column with LONG datatype */
         decode((select count(*) from sys.type$ ty, sys.coltype$ ct
                 where ty.toid=ct.toid and ty.version#=ct.version#
                 and ct.obj#=t.obj#
                 /* 0x00008000 =   32768 = contains varray attribute */
                 /* 0x00100000 = 1048576 = has embedded non final type */
                 and bitand(ty.properties,1081344)=1081344),
                 0,'N','Y'),
         decode((select count(*) from sys.refcon$ rf, sys.col$ c
                 where c.obj#=rf.obj# and c.intcol#=rf.intcol#
                 and c.obj#=t.obj#
                 and bitand(rf.reftyp,1)=0),            /* ref is non-scoped */
                 0,'N','Y'),
         (select sys.dbms_metadata_util.has_tstz_cols(t.obj#) from dual),
         value(o),
         ts.name, ts.ts#, ts.blocksize,
         (select dbms_metadata_util.block_estimate(tsp.obj#,3) from dual),
         value(bo),
         -- if this is a secondary table, get domidx obj and ancestor obj
         decode(bitand(bo.flags, 16), 16,
           (select value(oo) from ku$_schemaobj_view oo, secobj$ s
              where bo.obj_num=s.secobj#
                and oo.obj_num=s.obj#
                and rownum < 2),
           null),
         decode(bitand(bo.flags, 16), 16,
           (select value(oo) from ku$_schemaobj_view oo, ind$ i, secobj$ s
              where bo.obj_num=s.secobj#
                and i.obj#=s.obj#
                and oo.obj_num=i.bo#
                and rownum < 2),
           null),
         um.unload_method,
         um.et_parallel,
         (select count(*) from rls$ r
          where r.obj#=t.obj# and r.enable_flag=1 and bitand(r.stmt_type,1)=1),
         sys.dbms_metadata_util.ref_par_level(bo.obj_num,t.property),
         decode(bitand(tsp.flags,67108864),0,'N','Y')   -- read-only (subpartition)
  from  ku$_schemaobj_view o, ku$_schemaobjnum_view bo,
        ku$_unload_method_view um, tab$ t, tabcompart$ tcp,
        tabsubpart$ tsp, ts$ ts, partobj$ po
  where tsp.obj# = o.obj_num
        AND bo.obj_num = po.obj#
        AND t.obj#=tcp.bo#
        AND t.obj# = um.obj_num
        AND bitand(t.property, 32+64+128+256+512+8192) = 32
                                                /* partitioned (32)       */
                                                /* but not IOT            */
                                                /* or nested table        */
        AND bitand(t.flags,536870912)=0         /* not an IOT mapping table */
        AND bitand(tsp.flags,8388608)=0       /* not hidden for online move */
        AND tsp.ts# = ts.ts#
        AND tcp.obj# = tsp.pobj#
        AND bo.obj_num=tcp.bo#
        AND bitand(trunc(t.property/power(2,32)),1)=0
                                                /* not cube organized table */
        AND (bitand(bo.flags,16)!=16
             OR sys.dbms_metadata.oktoexp_2ndary_table(bo.obj_num)=1)
        AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

