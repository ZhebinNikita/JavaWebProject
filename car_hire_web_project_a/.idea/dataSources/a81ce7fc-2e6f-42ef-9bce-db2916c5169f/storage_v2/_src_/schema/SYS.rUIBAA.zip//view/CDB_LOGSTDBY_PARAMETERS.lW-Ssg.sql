create view CDB_LOGSTDBY_PARAMETERS as
  SELECT k."NAME",k."VALUE",k."UNIT",k."SETTING",k."DYNAMIC",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_PARAMETERS") k
/

comment on table CDB_LOGSTDBY_PARAMETERS
is 'Miscellaneous options and settings for Logical Standby in all containers'
/

