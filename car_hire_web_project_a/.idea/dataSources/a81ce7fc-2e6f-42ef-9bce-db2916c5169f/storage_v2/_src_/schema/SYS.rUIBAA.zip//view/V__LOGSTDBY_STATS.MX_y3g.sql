create view V_$LOGSTDBY_STATS as
  select "NAME","VALUE","CON_ID" from v$logstdby_stats
/

