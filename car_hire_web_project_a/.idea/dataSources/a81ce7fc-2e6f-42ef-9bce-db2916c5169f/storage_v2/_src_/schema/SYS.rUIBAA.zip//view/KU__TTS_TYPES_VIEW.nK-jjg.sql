create view KU$_TTS_TYPES_VIEW as
  select tabobjno, typeobjno, typename, typeowner
    from  ku$_table_types_view
  UNION ALL
    select tabobjno, typeobjno, typename, typeowner
    from  ku$_xmlschema_types_view
/

