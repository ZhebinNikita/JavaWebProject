create view KU$_DUMMY_ISR_VIEW as
  select '0','0'
    from dual
   where 1=0      -- return 0 rows, indicating no Import Staging Realm exists
/

