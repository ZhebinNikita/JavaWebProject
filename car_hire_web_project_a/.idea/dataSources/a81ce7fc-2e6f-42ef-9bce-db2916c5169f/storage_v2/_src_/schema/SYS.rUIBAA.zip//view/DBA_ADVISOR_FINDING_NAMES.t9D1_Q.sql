create view DBA_ADVISOR_FINDING_NAMES as
  select a.id as id,
             d.name as advisor_name,
             dbms_advisor.format_message(a.finding_name) as finding_name
      from   (select rownum-1 as id, advisor_id, finding_name
              from   x$keafdgn) a,
             WRI$_ADV_DEFINITIONS d
      where  a.advisor_id = d.id
/

