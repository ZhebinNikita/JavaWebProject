create view KU$_CUBE_FACT_VIEW as
  select ot.awseq#, ot.obj#, ao1.objname, oc.col#, oc.pcol#,
            (select col1.name from sys.col$ col1
             where col1.obj#=oc.obj# and col1.col#=oc.col#) colname,
            (select col2.name from sys.col$ col2
             where col2.obj#=oc.obj# and col2.col#=oc.pcol#) pcolname,
            oc.coltype,
            (select ao2.objname qdr
             from sys.aw_obj$ ao2,
             (select max(rowid) keep (dense_rank last order by gen#) rid
              from aw_obj$ group by awseq#, oid) aor2
             where ao2.oid = oc.qdroid and ao2.awseq#=ot.awseq#
               and ao2.rowid = aor2.rid) qdr, oc.qdrval, oc.hier#,
            oc.flags
     from sys.olap_tab$ ot, sys.olap_tab_col$ oc, sys.aw_obj$ ao1,
          (select max(rowid) keep (dense_rank last order by gen#) rid
           from aw_obj$ group by awseq#, oid) aor1
     where oc.obj# = ot.obj#
       and ao1.awseq#=ot.awseq# and ao1.rowid=aor1.rid and ao1.oid=oc.oid
     order by oc.col#
/

