create view KU$_DEPTABLE_OBJNUM_VIEW as
  select exdo.d_obj#,'T',
  bitand(t.property, 4294967295),    /* low order Property of dependent table */
  trunc(t.property / power(2, 32)), /* high order Property of dependent table */
  NULL,
  value(po),  /*Parent object details as obj_num of po is used to filter obj# */
  NULL
  from expdepobj$ exdo, ku$_schemaobj_view po, ku$_schemaobj_view do, tab$ t
  where exdo.p_obj# = po.obj_num
  AND exdo.d_obj# = do.obj_num
  AND exdo.d_obj# = t.obj#
  AND ((SYS_CONTEXT('USERENV','CURRENT_USERID') IN (po.owner_num, 0) AND
        SYS_CONTEXT('USERENV','CURRENT_USERID') IN (do.owner_num, 0))
        OR EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

