create view DBA_CUBE_DIMNL_MAPPINGS as
  SELECT
  u.name OWNER,
  o.name CUBE_NAME,
  owner_map.map_name CUBE_MAP_NAME,
  m.map_name MAP_NAME,
  m.map_id MAP_ID,
  o2.name MAPPED_DIMENSION_NAME,
  CASE m.mapped_dim_type
  WHEN 14 -- hier_level
  THEN (SELECT h.hierarchy_name
        FROM olap_hier_levels$ hl, olap_hierarchies$ h
        WHERE m.mapped_dim_id = hl.hierarchy_level_id
              AND hl.hierarchy_id = h.hierarchy_id
        )
  WHEN 13 -- hierarchy
  THEN (SELECT h.hierarchy_name
        FROM olap_hierarchies$ h
        WHERE m.mapped_dim_id = h.hierarchy_id
       )
  ELSE null END AS MAPPED_HIERARCHY_NAME,
  CASE m.mapped_dim_type
  WHEN 12 -- dim_level
  THEN (SELECT dl.level_name
        FROM olap_dim_levels$ dl
        WHERE m.mapped_dim_id = dl.level_id
        )
  WHEN 14 -- hier_level
  THEN (SELECT dl.level_name
        FROM olap_dim_levels$ dl, olap_hier_levels$ hl, olap_hierarchies$ h
        WHERE m.mapped_dim_id = hl.hierarchy_level_id
              AND hl.hierarchy_id = h.hierarchy_id
              AND hl.dim_level_id = dl.level_id
        )
  ELSE null END AS MAPPED_LEVEL_NAME,
  decode(m.mapped_dim_type, '12', 'DIMENSION LEVEL',
                            '11', 'PRIMARY DIMENSION',
                            '14', 'HIERARCHY LEVEL',
                            '13', 'HIERARCHY') MAPPED_DIMENSION_TYPE,
  s1.syntax_clob JOIN_CONDITION,
  s2.syntax_clob LEVEL_ID_EXPRESSION,
  s3.syntax_clob DIMENSIONALITY_EXPRESSION
FROM
  olap_mappings$ m,
  olap_mappings$ owner_map,
  user$ u,
  olap_dimensionality$ diml,
  obj$ o,
  obj$ o2,
  olap_syntax$ s1,
  olap_syntax$ s2,
  olap_syntax$ s3
WHERE
  m.map_type = 23
  AND m.mapped_object_id = diml.dimensionality_id
  AND m.mapping_owner_id = owner_map.map_id
  AND diml.dimensioned_object_id = o.obj#
  AND o.owner# = u.user#
  AND diml.dimension_id = o2.obj#(+)
  AND m.map_id = s1.owner_id(+)
  AND m.map_type = s1.owner_type(+)
  AND s1.ref_role(+) = 7
  AND m.map_id = s2.owner_id(+)
  AND m.map_type = s2.owner_type(+)
  AND s2.ref_role(+) = 8
  AND m.map_id = s3.owner_id(+)
  AND m.map_type = s3.owner_type(+)
  AND s3.ref_role(+) = 15
/

comment on table DBA_CUBE_DIMNL_MAPPINGS
is 'OLAP Cube Dimenisonality Mappings in the database'
/

