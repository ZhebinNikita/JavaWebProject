create view KU$_RADM_MC_VIEW as
  select '1','0',
         m.obj#,
         m.intcol#,
         c.name,
         r.pname,
         m.mfunc,
         m.regexp_pattern,
         m.regexp_replace_string,
	 m.regexp_position,
         m.regexp_occurrence,
         m.regexp_match_parameter,
         m.mparams
  from sys.radm_mc$ m, sys.radm$ r, col$ c
  where r.obj# = m.obj#
    and c.obj# = r.obj#
    and c.intcol# = m.intcol#
/

