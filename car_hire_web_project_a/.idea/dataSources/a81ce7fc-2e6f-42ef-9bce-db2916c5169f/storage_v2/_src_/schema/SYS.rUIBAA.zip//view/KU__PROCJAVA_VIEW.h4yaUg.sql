create view KU$_PROCJAVA_VIEW as
  select
  obj#,
  procedure#,
  ownername,
  ownerlength,
  usersignature,
  usersiglen,
  classname,
  classlength,
  methodname,
  methodlength,
  flags,
  flagslength,
  cookiesize
  from procedurejava$
/

