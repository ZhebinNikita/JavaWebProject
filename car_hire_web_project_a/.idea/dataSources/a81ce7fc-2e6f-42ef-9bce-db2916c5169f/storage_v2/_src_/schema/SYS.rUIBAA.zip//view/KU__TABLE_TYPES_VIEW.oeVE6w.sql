create view KU$_TABLE_TYPES_VIEW as
  select unique o.obj#,o.name,o.owner#,u.name, d.p_obj#, tyo.name, ou.name
from obj$ o, obj$ tyo, type$ dt, user$ u, user$ ou, dependency$ d, type$ t,
     sys.coltype$ c
where t.toid = c.toid
  and bitand(t.properties,2128)=0     /* not system-generated type */
  and o.obj# = c.obj#
  and o.type# = 2
  and o.owner# != 0                   /* not SYS-owned table */
  and o.owner# = u.user#
  and tyo.owner# = ou.user#
  and o.obj# = d.d_obj#
  and tyo.obj# = d.p_obj#
  and tyo.type# = 13
  and tyo.owner# != 0                 /* not SYS-owned type */
  and tyo.oid$ = dt.toid
  and dt.toid = dt.tvoid    /* only the latest type */

