create view KU$_PROCPLSQL_VIEW as
  select
  obj#,
  procedure#,
  entrypoint#
  from procedureplsql$
/

