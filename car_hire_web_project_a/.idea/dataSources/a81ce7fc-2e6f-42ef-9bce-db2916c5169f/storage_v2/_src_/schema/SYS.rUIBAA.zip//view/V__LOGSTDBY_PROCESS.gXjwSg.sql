create view V_$LOGSTDBY_PROCESS as
  select "SID","SERIAL#","LOGSTDBY_ID","SPID","TYPE","STATUS_CODE","STATUS","HIGH_SCN","CON_ID" from v$logstdby_process
/

