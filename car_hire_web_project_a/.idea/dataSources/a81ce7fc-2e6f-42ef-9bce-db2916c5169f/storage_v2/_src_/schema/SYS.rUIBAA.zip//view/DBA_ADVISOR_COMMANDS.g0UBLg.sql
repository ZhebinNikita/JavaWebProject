create view DBA_ADVISOR_COMMANDS as
  select a.indx as command_id,
             a.command_name as command_name
      from x$keacmdn a
/

