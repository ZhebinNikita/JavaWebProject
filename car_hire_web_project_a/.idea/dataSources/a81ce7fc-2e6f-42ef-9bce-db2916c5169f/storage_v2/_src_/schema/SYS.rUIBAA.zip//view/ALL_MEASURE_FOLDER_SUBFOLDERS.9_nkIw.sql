create view ALL_MEASURE_FOLDER_SUBFOLDERS as
  SELECT
  u.name OWNER,
  o.name MEASURE_FOLDER_NAME,
  uchild.name MEASURE_SUBFOLDER_OWNER,
  ochild.name MEASURE_SUBFOLDER_NAME
FROM
  olap_meas_folder_contents$ mfc,
  obj$ o,
  obj$ ochild,
  user$ uchild,
  user$ u
WHERE
  mfc.MEASURE_FOLDER_OBJ# = o.obj# -- PARENT
  AND ochild.owner# = uchild.user# -- SUBFOLDER_OWNER
  AND o.owner#=u.user#
  AND mfc.object_type = 10 --MEASURE_FOLDER
  AND ochild.obj# = mfc.OBJECT_ID --CHILD
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
/

comment on table ALL_MEASURE_FOLDER_SUBFOLDERS
is 'OLAP Measure Folders contained within the OLAP Measure Folders accessible to the user'
/

