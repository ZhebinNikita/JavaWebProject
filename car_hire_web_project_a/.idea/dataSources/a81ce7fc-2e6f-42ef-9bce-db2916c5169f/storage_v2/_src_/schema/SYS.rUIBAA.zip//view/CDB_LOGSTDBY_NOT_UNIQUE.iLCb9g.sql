create view CDB_LOGSTDBY_NOT_UNIQUE as
  SELECT k."OWNER",k."TABLE_NAME",k."BAD_COLUMN",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_NOT_UNIQUE") k
/

comment on table CDB_LOGSTDBY_NOT_UNIQUE
is 'List of all the tables with out primary or unique key not null constraints in all containers'
/

