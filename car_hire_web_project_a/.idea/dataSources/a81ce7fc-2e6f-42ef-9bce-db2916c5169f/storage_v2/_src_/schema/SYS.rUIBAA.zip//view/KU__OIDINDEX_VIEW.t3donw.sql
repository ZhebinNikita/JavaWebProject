create view KU$_OIDINDEX_VIEW as
  select i.bo#, ic.intcol#, o.name,
              decode(substr(o.name,1,5),'SYS_C',8,0),     -- mimic constr defer
              ( select value(s)
                from ku$_storage_view s
                where i.file#  = s.file_num
                and   i.block# = s.block_num
                and   i.ts#    = s.ts_num),
              (select value(s) from ku$_deferred_stg_view s
               where s.obj_num = i.obj#),
              ts.name, ts.blocksize,
              i.pctfree$,i.initrans,i.maxtrans
       from   sys.obj$ o, sys.ind$ i, sys.icol$ ic, sys.ts$ ts
       where  i.type# = 1
              and i.intcols = 1
              and ic.obj# = i.obj#
              and ic.intcol# = (select c.intcol#   -- Only 1 OID col per table
                                from sys.col$ c
                                where c.obj#=i.bo#
                                and bitand(c.property,2)=2)
              and o.obj# = i.obj#
              and ts.ts# = i.ts#
/

