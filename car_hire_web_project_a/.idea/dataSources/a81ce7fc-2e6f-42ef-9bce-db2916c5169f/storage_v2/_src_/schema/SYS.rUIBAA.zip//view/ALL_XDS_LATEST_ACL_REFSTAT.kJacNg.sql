create view ALL_XDS_LATEST_ACL_REFSTAT as
  select s.schema_name,
          s.table_name,
          s.refresh_mode,
          s.refresh_ability,
          s.job_start_time,
          s.job_end_time,
          s.row_update_count,
          s.status,
          s.error_message
from dba_xds_latest_acl_refstat s, sys.obj$ o, sys.user$ u
where o.owner#     = u.user#
  and s.table_name = o.name
  and u.name       = s.schema_name
  and o.type#      = 2                     /* table */
  and ( u.user# in (userenv('SCHEMAID'), 1)
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                  )
       or /* user has system privileges */
         ora_check_sys_privilege(o.owner#, o.type#) = 1
      )
/

