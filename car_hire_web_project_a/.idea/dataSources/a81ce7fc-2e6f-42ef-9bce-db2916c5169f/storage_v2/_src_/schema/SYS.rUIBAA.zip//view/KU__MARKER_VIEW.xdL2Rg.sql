create view KU$_MARKER_VIEW as
  select '1', '0', dbms_metadata_util.get_marker
  from dual
/

