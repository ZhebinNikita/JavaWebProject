create view LOGSTDBY_SUPPORT_11LOB as
  select lb.obj#, lb.lobj#, lb.col#,
    (case
     when (bitand(lb.property, 4) = 4) /* the lob colum is partitioned */
     then
       case
       when (exists       /* composite partitioned lob */
                   (select 1
                    from sys.lobfrag$ lf1, sys.lobcomppart$ cm
                    where lb.lobj# = cm.lobj#
                    and cm.partobj# = lf1.parentobj#
                    and bitand(lf1.fragpro, 2048) = 2048)
            or
             exists       /* regular partitioned lob */
                  (select 1
                   from sys.lobfrag$ lf2
                   where lb.lobj# = lf2.parentobj#
                   and bitand(lf2.fragpro, 2048) = 2048))
       then 1 else 0 end
     else                               /* non-partitioned lob */
       case
       when bitand(lb.property, 2048) = 2048 /* this is a securefile column */
       then 1 else 0 end
     end) securefile,
    (case
     when (bitand(lb.property, 4) = 4) /* the lob colum is partitioned */
     then
       case
       when (exists       /* composite partitioned lob */
                   (select 1
                    from sys.lobfrag$ lf1, sys.lobcomppart$ cm
                    where lb.lobj# = cm.lobj#
                    and cm.partobj# = lf1.parentobj#
                    and bitand(lf1.fragflags,
                                 65536    /* 0x10000 = Sharing: LOB level */
                               + 131072   /* 0x20000 = Sharing: Object level */
                               + 262144   /* 0x40000 = Sharing: Validate */
                               ) != 0)    /* this is a dedup securefile */
            or
             exists       /* regular partitioned lob */
                  (select 1
                   from sys.lobfrag$ lf2
                   where lb.lobj# = lf2.parentobj#
                   and bitand(lf2.fragflags,
                                 65536    /* 0x10000 = Sharing: LOB level */
                              + 131072    /* 0x20000 = Sharing: Object level */
                              + 262144    /* 0x40000 = Sharing: Validate */
                              ) != 0))     /* this is a dedup securefile */
       then 1 else 0 end
     else                               /* non-partitioned lob */
       case
       when bitand(lb.property, 2048) = 2048
            and bitand(lb.flags,
                         65536    /* 0x10000 = Sharing: LOB level */
                       + 131072   /* 0x20000 = Sharing: Object level */
                       + 262144   /* 0x40000 = Sharing: Validate */
                       ) != 0     /* this is a dedup securefile */
       then 1 else 0 end
     end) dedupsecurefile
from sys.lob$ lb
/

