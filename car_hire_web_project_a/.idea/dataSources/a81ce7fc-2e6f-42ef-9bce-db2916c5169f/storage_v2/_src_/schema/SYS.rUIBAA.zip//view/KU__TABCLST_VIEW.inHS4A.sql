create view KU$_TABCLST_VIEW as
  select k.clstobj#, value(o),
     (select value(cz) from ku$_clst_view cz where cz.obj_num = k.clstobj#)
  from ku$_schemaobj_view o, clst$ k
  where o.obj_num = k.clstobj#
        AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

