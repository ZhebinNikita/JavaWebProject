create view KU$_USER_VIEW as
  select ubv.*,
        cast(multiset(select * from ku$_user_editioning_view uev
                      where uev.user_id = ubv.user_id)
                      as ku$_user_editioning_list_t)
  from sys.ku$_user_base_view ubv
/

