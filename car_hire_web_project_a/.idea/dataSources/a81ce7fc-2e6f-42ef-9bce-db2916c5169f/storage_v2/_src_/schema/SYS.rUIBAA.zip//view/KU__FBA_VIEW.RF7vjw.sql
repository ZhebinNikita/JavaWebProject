create view KU$_FBA_VIEW as
  select '1','0',
            ft.obj#,
            ft.fa#,
            fba.faname
  from sys_fba_fa fba, sys_fba_trackedtables ft
  where ft.fa#=fba.fa#
/

