create view KU$_PIOT_PART_VIEW as
  select ip.obj#,
         (select value(so) from ku$_schemaobj_view so
          where so.obj_num = ip.obj#),
         ts.name, ts.blocksize,
         (select value(s) from ku$_storage_view s
          where ip.file#  = s.file_num
          and   ip.block# = s.block_num
          and   ip.ts#    = s.ts_num),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = ip.obj#),
         ip.dataobj#, ip.bo#,
         dbms_metadata.get_partn(4,ip.bo#,ip.part#),
         ip.hiboundlen,
         sys.dbms_metadata_util.long2varchar(ip.hiboundlen,
                                    'SYS.INDPART$',
                                    'HIBOUNDVAL',
                                     ip.rowid),
         cast(multiset(select lf.* from ind$ i, ku$_piotlobfrag_view lf
                        where lf.part_num=
                                dbms_metadata.get_partn(4,ip.bo#,ip.part#)
                          and ip.bo#=i.obj# and i.bo#=lf.base_obj_num
                        order by lf.intcol_num
                      ) as ku$_lobfrag_list_t
             ),
         ip.flags,
         (select tp.flags from ind$ i, tabpart$ tp
          where ip.bo#=i.obj# and tp.bo#=i.bo# and tp.part#=ip.part#),
         ip.pctfree$, ip.pctthres$,
         ip.initrans, ip.maxtrans,
         to_char(ip.analyzetime,'YYYY/MM/DD HH24:MI:SS'), ip.samplesize,
         ip.rowcnt, ip.blevel, ip.leafcnt, ip.distkey, ip.lblkkey,
         ip.dblkkey, ip.clufac, ip.spare1, ip.spare2, ip.spare3,
         ip.inclcol
  from  indpart$ ip, ts$ ts
  where ip.ts# = ts.ts#
/

