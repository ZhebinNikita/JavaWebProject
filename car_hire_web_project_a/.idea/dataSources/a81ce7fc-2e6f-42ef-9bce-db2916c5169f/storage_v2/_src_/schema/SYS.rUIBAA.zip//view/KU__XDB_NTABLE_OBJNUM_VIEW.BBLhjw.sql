create view KU$_XDB_NTABLE_OBJNUM_VIEW as
  select nt.ntab#,'X',
   bitand(t.property, 4294967295),
   trunc(t.property / power(2, 32)),
   NULL,                        -- ts# not needed
   value(o), value(bo)
  from ku$_schemaobj_view o, ku$_schemaobj_view bo, sys.tab$ t, sys.ntab$ nt
  where bo.obj_num=dbms_metadata_util.get_anc(nt.ntab#,0)
    and  o.obj_num=nt.ntab#
    and dbms_metadata_util.isXml(nt.ntab#)=1 and nt.ntab# != 0
    and  t.obj#=nt.ntab#
    and (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0)
        OR EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
  start with nt.obj#
        in (select * from table(dbms_metadata.fetch_objnums))
  connect by prior nt.ntab#=nt.obj#
/

