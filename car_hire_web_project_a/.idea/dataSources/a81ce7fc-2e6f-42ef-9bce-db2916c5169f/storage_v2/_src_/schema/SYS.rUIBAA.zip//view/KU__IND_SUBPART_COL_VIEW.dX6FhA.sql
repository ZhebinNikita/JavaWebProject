create view KU$_IND_SUBPART_COL_VIEW as
  select sc.obj#, sc.intcol#, value(c), sc.pos#, sc.spare1
  from ku$_simple_col_view c, ind$ i, subpartcol$ sc
  where  sc.obj#=i.obj#
  and    i.bo#=c.obj_num
  and    sc.intcol#=c.intcol_num
/

