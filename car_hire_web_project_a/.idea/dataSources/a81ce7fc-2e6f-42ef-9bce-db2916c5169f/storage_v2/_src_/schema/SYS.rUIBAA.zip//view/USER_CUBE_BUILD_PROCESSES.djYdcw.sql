create view USER_CUBE_BUILD_PROCESSES as
  SELECT
  o.name BUILD_PROCESS_NAME,
  ia.obj# BUILD_PROCESS_ID,
  syn.syntax_clob BUILD_PROCESS,
  d.description_value DESCRIPTION
FROM
  olap_cube_build_processes$ ia,
  obj$ o,
  olap_syntax$ syn,
  (select d.* from olap_descriptions$ d, nls_session_parameters n where
        n.parameter = 'NLS_LANGUAGE'
        and d.description_type = 'Description'
        and d.owning_object_type = 8 --BUILD_PROCESS
        and (d.language = n.value
             or d.language like n.value || '\_%' escape '\')) d
WHERE
  ia.obj# = o.obj#
  AND o.owner# = USERENV('SCHEMAID')
  AND ia.obj# = d.owning_object_id(+)
  AND syn.owner_id(+)=ia.obj#
  AND syn.owner_type(+)=8
  AND syn.ref_role(+)=13 -- build process
/

comment on table USER_CUBE_BUILD_PROCESSES
is 'OLAP Build Processes owned by the user in the database'
/

