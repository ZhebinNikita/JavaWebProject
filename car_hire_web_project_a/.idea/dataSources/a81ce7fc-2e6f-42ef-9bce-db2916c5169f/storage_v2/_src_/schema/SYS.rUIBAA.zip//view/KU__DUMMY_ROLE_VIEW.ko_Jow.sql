create view KU$_DUMMY_ROLE_VIEW as
  select '0','0',NULL
    from dual
   where 1=0      -- return 0 rows
/

