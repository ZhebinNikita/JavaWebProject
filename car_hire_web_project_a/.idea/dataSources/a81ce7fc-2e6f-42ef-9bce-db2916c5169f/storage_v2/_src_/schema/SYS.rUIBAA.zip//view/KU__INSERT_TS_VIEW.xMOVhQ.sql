create view KU$_INSERT_TS_VIEW as
  select itl.bo#, itl.position#, itl.ts#, ts.name
  from sys.ts$ ts, sys.insert_tsn_list$ itl
  where ts.ts#=itl.ts#
/

