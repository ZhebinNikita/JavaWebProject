create view CDB_LOGSTDBY_UNSUPPORTED_TABLE as
  SELECT k."OWNER",k."TABLE_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_UNSUPPORTED_TABLE") k
/

comment on table CDB_LOGSTDBY_UNSUPPORTED_TABLE
is 'List of all the data tables that are not supported by Logical Standby in all containers'
/

