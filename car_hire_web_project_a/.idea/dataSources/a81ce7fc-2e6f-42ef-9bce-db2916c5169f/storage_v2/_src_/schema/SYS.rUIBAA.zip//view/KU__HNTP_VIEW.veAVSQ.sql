create view KU$_HNTP_VIEW as
  select tp.obj#, t.property,
        (select value(s) from ku$_storage_view s
         where     tp.file#  = s.file_num
             and   tp.block# = s.block_num
             and   tp.ts#    = s.ts_num),
        (select value(s) from ku$_deferred_stg_view s
         where s.obj_num = tp.obj#),
        (select ts.name from ts$ ts where tp.ts# = ts.ts#),
        (select ts.blocksize from ts$ ts where tp.ts# = ts.ts#),
        tp.pctfree$, tp.pctused$, tp.initrans, tp.maxtrans, tp.flags
  from tabpart$ tp, tab$ t
  where tp.bo# = t.obj# and
        bitand(t.property,64+512) = 0 -- skip IOT and overflow segs
/

