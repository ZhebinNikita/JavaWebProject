create view KU$_DUMMY_DV_AUTH_TTS_V as
  select '0','0',NULL
    from dual
   where 1=0      -- return 0 rows
/

