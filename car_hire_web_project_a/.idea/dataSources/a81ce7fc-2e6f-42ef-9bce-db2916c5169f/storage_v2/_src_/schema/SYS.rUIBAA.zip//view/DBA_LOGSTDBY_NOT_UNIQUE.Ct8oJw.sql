create view DBA_LOGSTDBY_NOT_UNIQUE as
  with redo_compat as
         (select nvl((select min(s.redo_compat)
                      from system.logstdby$parameters p,
                           system.logmnr_session$ s,
                           sys.v$database d
                      where p.name in ('LMNR_SID', 'FUTURE_SESSION') and
                            p.value = s.session# and
                            d.database_role = 'LOGICAL STANDBY'),
                     (select p.value
                      from sys.v$parameter p
                      where p.name = 'compatible')) compat
          from dual)
  select owner, name table_name,
         decode((select count(c.obj#)
                 from sys.col$ c
                 where c.obj# = l.obj#
                 and ((c.type# in (8,                             /* LONG */
                                   24,                        /* LONG RAW */
                                   58,                             /* XML */
                                   112,                           /* CLOB */
                                   113))                          /* BLOB */
                 or (c.type# = 1 and bitand(c.property, 128) = 128))),
                 /* 32k varchar */
                 0, 'N', 'Y') bad_column
  from (
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_10_1 u, redo_compat c
    where c.compat like '10.0%' or c.compat like '10.1%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_10_2 u, redo_compat c
    where c.compat like '10.2%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_11_1 u, redo_compat c
    where c.compat like '11.0%' or c.compat like '11.1%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_11_2 u, redo_compat c
    where c.compat like '11.2%' and c.compat not like '11.2.0.3%'
                                and c.compat not like '11.2.0.4%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_11_2b u, redo_compat c
    where c.compat like '11.2.0.3%' or c.compat like '11.2.0.4%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_12_1 u, redo_compat c
    where c.compat like '12.0%' or c.compat like '12.1%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_12_2 u, redo_compat c
    where c.compat like '12.2%'
  ) l, tab$ t
  where gensby = 1
    and l.type# = 2
    and l.obj# = t.obj# and
        bitand(t.property, 1) = 0                    /* rule out typed table */
    and not exists                    /* not null unique key -- condition #1 */
       (select null -- (tagA)
        from ind$ i, icol$ ic, col$ c
        where i.bo# = l.obj#
          and ic.obj# = i.obj#
          and c.col# = ic.col#
          and c.obj# = i.bo#
          and c.null$ > 0                                       /* not null */
          and i.type# = 1                                          /* Btree */
          and bitand(i.property, 1) = 1                           /* Unique */
          and i.intcols = i.cols                      /* no virtual columns */
          and not exists (select null
                          from icol$ icol2, col$ col2
                          where  icol2.obj# = i.obj# and
                                 icol2.bo#  = i.bo#  and -- redundant
                                 icol2.bo#  = col2.obj# and
                                 icol2.intcol# = col2.intcol# and
                                 bitand(col2.property, 168) != 0)) -- (tagA)
    and not exists               /* primary key constraint --  condition #2 */
       (select null                         /* defer bit 0x1: deferrable    */
        from cdef$ cd                       /*       bit 0x4: sys validated */
        where cd.obj# = l.obj#              /*       bit 0x20: rely         */
          and cd.type# = 2
          and bitand(cd.defer, 37) in (4, 32, 36)
          and not exists (select null
                          from ccol$ ccol3, col$ col3
                          where ccol3.con# = cd.con# and
                                ccol3.obj# = cd.obj# and
                                ccol3.obj# = col3.obj# and
                                ccol3.intcol# = col3.intcol# and
                                bitand(col3.property, 168) != 0)
        )
/

comment on table DBA_LOGSTDBY_NOT_UNIQUE
is 'List of all the tables with out primary or unique key not null constraints'
/

