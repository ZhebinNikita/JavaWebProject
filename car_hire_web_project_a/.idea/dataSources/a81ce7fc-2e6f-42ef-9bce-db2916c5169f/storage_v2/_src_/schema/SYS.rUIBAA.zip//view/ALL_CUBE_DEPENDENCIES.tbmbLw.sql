create view ALL_CUBE_DEPENDENCIES as
  SELECT
  u.name OWNER,
  o.name as D_TOP_OBJ_NAME,
  case md.D_OBJ_TYPE                          /* BEGIN COLUMN D_SUB_OBJ_NAME1 */
  WHEN 4 -- ASSIGNMENT
  THEN (SELECT m.model_name
	FROM olap_model_assignments$ a, olap_models$ m
	WHERE md.d_sub_obj# = a.assignment_id
	      AND m.model_id = a.model_id
	      AND m.owning_obj_type = 11
	      AND m.owning_obj_id = md.d_top_obj#
	)
  WHEN 3 -- model
  THEN (SELECT m.model_name
	FROM olap_models$ m
	WHERE md.d_sub_obj# = m.model_id
	      AND m.owning_obj_type = 11
	      AND m.owning_obj_id = md.d_top_obj#
	)
  WHEN 14 -- hier_level
  THEN (SELECT h.hierarchy_name
	FROM olap_hier_levels$ hl, olap_hierarchies$ h
	WHERE md.d_sub_obj# = hl.hierarchy_level_id
	      AND hl.hierarchy_id = h.hierarchy_id
	      AND h.dim_obj# = md.d_top_obj#
	)
  WHEN 13 -- hierarchy
  THEN (SELECT h.hierarchy_name
	FROM olap_hierarchies$ h
	WHERE md.d_sub_obj# = h.hierarchy_id
	      AND h.dim_obj# = md.d_top_obj#
       )
  WHEN 12 -- dim_level
  THEN (SELECT dl.level_name
	FROM olap_dim_levels$ dl
	WHERE md.d_sub_obj# = dl.level_id
	      AND dl.dim_obj# = md.d_top_obj#
       )
  WHEN 15 -- attribute
  THEN (SELECT a.attribute_name
	FROM olap_attributes$ a
	WHERE md.d_sub_obj# = a.attribute_id
	      AND a.dim_obj# = md.d_top_obj#
       )
  WHEN 6 -- calc_member
  THEN (SELECT c.member_name
	FROM OLAP_CALCULATED_MEMBERS$ c
	WHERE md.d_sub_obj# = c.member_id
	      AND c.dim_obj# = md.d_top_obj#
       )
  WHEN 18 -- hier_level_map
  THEN (SELECT h.hierarchy_name
	FROM olap_mappings$ m, olap_hierarchies$ h, olap_hier_levels$ hl
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = hl.hierarchy_level_id
	      AND hl.hierarchy_id = h.hierarchy_id
	      AND h.dim_obj# = md.d_top_obj#
	)
  WHEN 19 -- solved_level_hier_map
  THEN (SELECT h.hierarchy_name
	FROM olap_mappings$ m, olap_hierarchies$ h
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = h.hierarchy_id
	      AND h.dim_obj# = md.d_top_obj#
	)
  WHEN 20 -- solved_value_hier_map
  THEN (SELECT h.hierarchy_name
	FROM olap_mappings$ m, olap_hierarchies$ h
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = h.hierarchy_id
	      AND h.dim_obj# = md.d_top_obj#
	)
  WHEN 21 -- member_list_map
  THEN (SELECT
          (CASE m.mapping_owner_type
           WHEN 11 -- primary_dim
           THEN (select m.map_name
                 from olap_cube_dimensions$ d
                 where d.obj# = md.d_top_obj#
                       AND d.obj# = m.mapping_owner_id)
           WHEN 12 -- dim_level
           THEN (select dl.level_name
                 from olap_dim_levels$ dl
                 where m.mapping_owner_id = dl.level_id
                       AND dl.dim_obj# = md.d_top_obj#)
           WHEN 14 -- hier_level
           THEN (select h.hierarchy_name
                 from olap_hier_levels$ hl, olap_hierarchies$ h
                 where m.mapping_owner_id = hl.hierarchy_level_id
 	               AND hl.hierarchy_id = h.hierarchy_id
   	               AND h.dim_obj# = md.d_top_obj#)
           WHEN 13 -- hierarchy
           THEN (select h.hierarchy_name
                 from olap_hierarchies$ h
                 where m.mapping_owner_id = h.hierarchy_id
                       AND h.dim_obj# = md.d_top_obj#)
           ELSE null
           END) AS D_SUB_OBJ_NAME1
 	FROM olap_mappings$ m
 	WHERE m.map_id = md.d_sub_obj#
 	)
  WHEN 17 -- attribute_map
  THEN (SELECT
	  (CASE owner_map.mapping_owner_type
	  WHEN 14 -- hier_level
	  THEN (select h.hierarchy_name
		from olap_hier_levels$ hl, olap_hierarchies$ h
		where owner_map.mapping_owner_id = hl.hierarchy_level_id
		      AND hl.hierarchy_id = h.hierarchy_id
		      AND h.dim_obj# = md.d_top_obj#)
	  WHEN 13 -- hierarchy
	  THEN (select h.hierarchy_name
		from olap_hierarchies$ h
		where owner_map.mapping_owner_id = h.hierarchy_id
		      AND h.dim_obj# = md.d_top_obj#)
	  WHEN 12 -- dim_level
	  THEN (select dl.level_name
		from olap_dim_levels$ dl
		where owner_map.mapping_owner_id = dl.level_id
		      AND dl.dim_obj# = md.d_top_obj#)
	  WHEN 11 -- primary dimension
          THEN (select owner_map.map_name
		from olap_cube_dimensions$ d
		where d.obj# = md.d_top_obj#
		      AND owner_map.mapping_owner_id = d.obj#)
	  ELSE null
	  END) AS D_SUB_OBJ_NAME1
	FROM olap_mappings$ m, olap_mappings$ owner_map
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = owner_map.map_id
       )
  WHEN 27 -- aw_dim_org
  THEN '$AW_ORGANIZATION'
  ELSE null
  END AS D_SUB_OBJ_NAME1,                       /* END COLUMN D_SUB_OBJ_NAME1 */
  case md.D_OBJ_TYPE                          /* BEGIN COLUMN D_SUB_OBJ_NAME2 */
  WHEN 4 -- ASSIGNMENT
  THEN (SELECT a.member_name
	FROM olap_model_assignments$ a, olap_models$ m
	WHERE md.d_sub_obj# = a.assignment_id
	      AND m.model_id = a.model_id
	      AND m.owning_obj_type = 11
	      AND m.owning_obj_id = md.d_top_obj#
	)
  WHEN 14 -- hier_level
  THEN (SELECT dl.level_name
	FROM olap_hier_levels$ hl, olap_dim_levels$ dl,
	     olap_hierarchies$ h
	WHERE md.d_sub_obj# = hl.hierarchy_level_id
	      AND hl.dim_level_id = dl.level_id
	      AND hl.hierarchy_id = h.hierarchy_id
	      AND h.dim_obj# = md.d_top_obj#
	)
  WHEN 18 -- hier_level_map
  THEN (SELECT dl.level_name
	FROM olap_mappings$ m, olap_hierarchies$ h, olap_hier_levels$ hl,
	     olap_dim_levels$ dl
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = hl.hierarchy_level_id
	      AND hl.dim_level_id = dl.level_id
	      AND hl.hierarchy_id = h.hierarchy_id
	      AND h.dim_obj# = md.d_top_obj#
	)
  WHEN 19 -- solved_level_hier_map
  THEN (SELECT m.map_name
	FROM olap_mappings$ m, olap_hierarchies$ h
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = h.hierarchy_id
	      AND h.dim_obj# = md.d_top_obj#
	)
  WHEN 20 -- solved_value_hier_map
  THEN (SELECT m.map_name
	FROM olap_mappings$ m, olap_hierarchies$ h
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = h.hierarchy_id
	      AND h.dim_obj# = md.d_top_obj#
	)
  WHEN 21 -- member_list_map
  THEN (SELECT
          (CASE m.mapping_owner_type
           WHEN 12 -- dim_level
           THEN (select m.map_name
                 from olap_dim_levels$ dl
                 where m.mapping_owner_id = dl.level_id
                       AND dl.dim_obj# = md.d_top_obj#)
           WHEN 14 -- hier_level
           THEN (select dl.level_name
                 from olap_hier_levels$ hl, olap_hierarchies$ h,
                      olap_dim_levels$ dl
       	         where m.mapping_owner_id = hl.hierarchy_level_id
	               AND hl.hierarchy_id = h.hierarchy_id
                       AND hl.dim_level_id = dl.level_id
   	               AND h.dim_obj# = md.d_top_obj#)
           WHEN 13 -- hierarchy
           THEN (select m.map_name
                 from olap_hierarchies$ h
                 where m.mapping_owner_id = h.hierarchy_id
                       AND h.dim_obj# = md.d_top_obj#)
           ELSE null
           END) AS D_SUB_OBJ_NAME1
 	FROM olap_mappings$ m
 	WHERE m.map_id = md.d_sub_obj#
 	)
  WHEN 17 -- attribute_map
  THEN (SELECT
	  (CASE owner_map.mapping_owner_type
	  WHEN 14 -- hier_level
	  THEN (select dl.level_name
		from olap_hier_levels$ hl, olap_hierarchies$ h,
		     olap_dim_levels$ dl
		where owner_map.mapping_owner_id = hl.hierarchy_level_id
		      AND hl.hierarchy_id = h.hierarchy_id
		      AND hl.dim_level_id = dl.level_id
		      AND h.dim_obj# = md.d_top_obj#)
	  WHEN 13 -- hierarchy
	  THEN (select owner_map.map_name
		from olap_hierarchies$ h
		where owner_map.mapping_owner_id = h.hierarchy_id
		      AND h.dim_obj# = md.d_top_obj#)
	  WHEN 12 -- dim_level
	  THEN (select owner_map.map_name
		from olap_dim_levels$ dl
		where owner_map.mapping_owner_id = dl.level_id
		      AND dl.dim_obj# = md.d_top_obj#)
	  WHEN 11 -- primary dimension
	  THEN (select m.map_name
		from olap_cube_dimensions$ d
		where d.obj# = md.d_top_obj#
		      AND owner_map.mapping_owner_id = d.obj#)
	  ELSE null
	  END) AS D_SUB_OBJ_NAME2
	FROM olap_mappings$ m, olap_mappings$ owner_map
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = owner_map.map_id
       )
  ELSE null
  END AS D_SUB_OBJ_NAME2,                       /* END COLUMN D_SUB_OBJ_NAME2 */
  case md.D_OBJ_TYPE                          /* BEGIN COLUMN D_SUB_OBJ_NAME3 */
  WHEN 18 -- hier_level_map
  THEN (SELECT m.map_name
	FROM olap_mappings$ m, olap_hierarchies$ h, olap_hier_levels$ hl
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = hl.hierarchy_level_id
	      AND hl.hierarchy_id = h.hierarchy_id
	      AND h.dim_obj# = md.d_top_obj#
	)
  WHEN 21 -- member_list_map
  THEN (SELECT
          (CASE m.mapping_owner_type
           WHEN 14 -- hier_level
           THEN (select m.map_name
                 from olap_hier_levels$ hl, olap_hierarchies$ h,
                      olap_dim_levels$ dl
                  where m.mapping_owner_id = hl.hierarchy_level_id
	                AND hl.hierarchy_id = h.hierarchy_id
                        AND hl.dim_level_id = dl.level_id
   	                AND h.dim_obj# = md.d_top_obj#)
           ELSE null
           END) AS D_SUB_OBJ_NAME1
 	FROM olap_mappings$ m
 	WHERE m.map_id = md.d_sub_obj#
 	)
  WHEN 17 -- attribute_map
  THEN (SELECT
	  (CASE owner_map.mapping_owner_type
	  WHEN 14 -- hier_level
	  THEN (select owner_map.map_name
		from olap_hier_levels$ hl, olap_hierarchies$ h
		where owner_map.mapping_owner_id = hl.hierarchy_level_id
		      AND hl.hierarchy_id = h.hierarchy_id
		      AND h.dim_obj# = md.d_top_obj#)
	  WHEN 13 -- hierarchy
	  THEN (select m.map_name
		from olap_hierarchies$ h
		where owner_map.mapping_owner_id = h.hierarchy_id
		      AND h.dim_obj# = md.d_top_obj#)
	  WHEN 12 -- dim_level
	  THEN (select m.map_name
		from olap_dim_levels$ dl
		where owner_map.mapping_owner_id = dl.level_id
		      AND dl.dim_obj# = md.d_top_obj#)
	  ELSE null
	  END) AS D_SUB_OBJ_NAME3
	FROM olap_mappings$ m, olap_mappings$ owner_map
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = owner_map.map_id
       )
  ELSE null
  END AS D_SUB_OBJ_NAME3,                       /* END COLUMN D_SUB_OBJ_NAME3 */
  case md.D_OBJ_TYPE                          /* BEGIN COLUMN D_SUB_OBJ_NAME4 */
  WHEN 17 -- attribute_map
  THEN (SELECT
	  (CASE owner_map.mapping_owner_type
	  WHEN 14 -- hier_level
	  THEN (select m.map_name
		from olap_hier_levels$ hl, olap_hierarchies$ h
		where owner_map.mapping_owner_id = hl.hierarchy_level_id
		      AND hl.hierarchy_id = h.hierarchy_id
		      AND h.dim_obj# = md.d_top_obj#)
	  ELSE null
	  END) AS D_SUB_OBJ_NAME3
	FROM olap_mappings$ m, olap_mappings$ owner_map
	WHERE m.map_id = md.d_sub_obj#
	      AND m.mapping_owner_id = owner_map.map_id
       )
  ELSE null
  END AS D_SUB_OBJ_NAME4,                       /* END COLUMN D_SUB_OBJ_NAME4 */
  decode(md.d_obj_type, '3', 'MODEL',
			'4', 'ASSIGNMENT',
			'6', 'CALCULATION MEMBER',
                        '11', 'DIMENSION',
			'12', 'DIMENSION LEVEL',
			'13', 'HIERARCHY',
			'14', 'HIERARCHY LEVEL',
			'15', 'ATTRIBUTE',
			'17', 'ATTRIBUTE MAP',
			'18', 'HIER LEVEL MAP',
			'19', 'SOLVED LEVEL HIER MAP',
			'20', 'SOLVED VALUE HIER MAP',
			'21', 'MEMBER LIST MAP',
                        '27', 'AW DIM ORGANIZATION',
                        '29', 'AW') D_OBJ_TYPE,
  md.P_OWNER P_OBJ_OWNER,
  md.P_TOP_OBJ_NAME P_TOP_OBJ_NAME,
  md.P_SUB_OBJ_NAME1 P_SUB_OBJ_NAME1,
  md.P_SUB_OBJ_NAME2 P_SUB_OBJ_NAME2,
  md.P_SUB_OBJ_NAME3 P_SUB_OBJ_NAME3,
  md.P_SUB_OBJ_NAME4 P_SUB_OBJ_NAME4,
  case md.p_obj_type
  WHEN 25 -- TABLE OR VIEW
       THEN (SELECT decode(o.type#, '4', 'VIEW', 'TABLE')
             FROM obj$ o
             WHERE o.obj# = md.p_obj#
            )
       ELSE decode(md.p_obj_type, '1', 'CUBE',
			'2', 'MEASURE',
			'3', 'MODEL',
			'4', 'ASSIGNMENT',
			'6', 'CALCULATION MEMBER',
                        '8',  'BUILD PROCESS',
                        '10', 'MEASURE FOLDER',
			'11', 'DIMENSION',
			'12', 'DIMENSION LEVEL',
			'13', 'HIERARCHY',
			'14', 'HIERARCHY LEVEL',
			'15', 'ATTRIBUTE',
                        '16', 'DIMENSIONALITY',
			'17', 'ATTRIBUTE MAP',
			'18', 'HIER LEVEL MAP',
			'19', 'SOLVED LEVEL HIER MAP',
			'20', 'SOLVED VALUE HIER MAP',
			'21', 'MEMBER LIST MAP',
			'22', 'CUBE MAP',
			'23', 'CUBE DIMENSIONALITY MAP',
			'24', 'MEASURE MAP',
			'26', 'COLUMN',
                        '27', 'AW DIM ORGANIZATION',
                        '28', 'AW CUBE ORGANIZATION',
                        '29', 'AW') END AS P_OBJ_TYPE,
  decode(md.dep_type, '1', 'CONSISTENT SOLVE SPEC',
                      '2', 'DEFAULT BUILD SPEC',
                      '3', 'BUILD SPEC',
                      '4', 'BUILD PROCESS',
                      '6', 'MEASURE IN MEASURE DIM',
                      '7', 'CUSTOM ORDER',
                      '9', 'TARGET ATTRIBUTE',
                      '10', 'TARGET DIMENSION',
                      '11', 'MEMBER EXPRESSION',
                      '12', 'EXPLICIT DIMENSION',
                      '13', 'PRIMARY DIMENSION',
                      '15', 'MEASURE IN MEASURE FOLDER',
                      '16', 'MEASURE FOLDER SUBFOLDER',
                      '17', 'MAPPED DIMENSION',
                      '18', 'QUERY',
                      '19', 'FROM CLAUSE',
                      '20', 'WHERE CLAUSE',
                      '21', 'JOIN CONDITION',
                      '22', 'LEVEL_ID EXPRESSION',
                      '23', 'KEY EXPRESSION',
                      '24', 'VALUE MAP EXPRESSION',
                      '25', 'LEVEL EXPRESSION',
                      '26', 'PARENT KEY EXPRESSION',
                      '27', 'PARENT LEVEL_ID EXPRESSION',
                      '28', 'MEASURE EXPRESSION',
                      '29', 'NVL EXPRESSION',
                      '30', 'AW',
                      '31', 'AW TABLE',
                      '32', 'PARTITION LEVEL',
                      '33', 'SECONDARY PARTITION LEVEL',
                      '34', 'PRECOMPUTE CONDITION'
                      ) DEPENDENCY_TYPE
FROM
  olap_metadata_dependencies$ md,
  obj$ o,
  user$ u
WHERE
  o.obj# = md.d_top_obj#
  AND o.owner# = u.user#
  AND md.d_obj_type in (3, 4, 6, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 27, 29)
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
UNION ALL
SELECT
  u.name OWNER,
  o.name as D_TOP_OBJ_NAME,
  case md.D_OBJ_TYPE                          /* BEGIN COLUMN D_SUB_OBJ_NAME1 */
  WHEN 2 -- measure
  THEN (SELECT meas.measure_name
        FROM olap_measures$ meas
        WHERE md.d_sub_obj# = meas.measure_id
              AND meas.cube_obj# = md.d_top_obj#
       )
  WHEN 22 -- cube_map
  THEN (SELECT m.map_name
	FROM olap_mappings$ m
	WHERE m.mapping_owner_id = md.d_top_obj#
	      AND m.map_id = md.d_sub_obj#
       )
  WHEN 23 -- cube_dimnl_map
  THEN (SELECT owner_map.map_name
	FROM olap_mappings$ owner_map, olap_mappings$ m
	WHERE m.mapping_owner_id = owner_map.map_id
	      AND m.map_id = md.d_sub_obj#
	      AND owner_map.mapping_owner_id = md.d_top_obj#
       )
  WHEN 24 -- cube_meas_map
  THEN (SELECT owner_map.map_name
	FROM olap_mappings$ owner_map, olap_mappings$ m
	WHERE m.mapping_owner_id = owner_map.map_id
	      AND m.map_id = md.d_sub_obj#
	      AND owner_map.mapping_owner_id = md.d_top_obj#
       )
  WHEN 16 -- dimensionality
  THEN (SELECT io_diml.option_value
        FROM olap_dimensionality$ diml, olap_impl_options$ io_diml
        WHERE diml.DIMENSIONED_OBJECT_ID = md.d_top_obj#
              AND diml.DIMENSIONALITY_ID = md.d_sub_obj#
              AND io_diml.object_type = 16 -- DIMENSIONALITY
              AND io_diml.owning_objectid = diml.dimensionality_id
              AND io_diml.option_type = 33 -- DIMENSIONALITY NAME
       )
  WHEN 28 -- aw_cube_org
  THEN '$AW_ORGANIZATION'
  WHEN 30 -- secondary_partition_level
  THEN '$AW_ORGANIZATION'
  ELSE null
  END AS D_SUB_OBJ_NAME1,                       /* END COLUMN D_SUB_OBJ_NAME1 */
  case md.D_OBJ_TYPE                          /* BEGIN COLUMN D_SUB_OBJ_NAME2 */
  WHEN 23 -- cube_dimnl_map
  THEN (SELECT m.map_name
	FROM olap_mappings$ owner_map, olap_mappings$ m
	WHERE m.mapping_owner_id = owner_map.map_id
	      AND m.map_id = md.d_sub_obj#
	      AND owner_map.mapping_owner_id = md.d_top_obj#
       )
  WHEN 24 -- cube_meas_map
  THEN (SELECT m.map_name
	FROM olap_mappings$ owner_map, olap_mappings$ m
	WHERE m.mapping_owner_id = owner_map.map_id
	      AND m.map_id = md.d_sub_obj#
	      AND owner_map.mapping_owner_id = md.d_top_obj#
       )
  WHEN 30 -- secondary_partition_level
  THEN (SELECT
	  CASE
	  WHEN md.d_sub_obj# < 3
	  THEN (SELECT io.option_value
	  FROM olap_impl_options$ io
	  WHERE io.owning_objectid = md.d_top_obj#
	        AND io.object_type = 1
	        AND io.option_type =
                    (case when d_sub_obj# = 0 then 38
                          when d_sub_obj# = 1 then 41
                          else 44 end))
	  ELSE (SELECT mo.option_value
	  FROM olap_multi_options$ mo
	  WHERE mo.owning_objectid = md.d_top_obj#
	        AND mo.object_type = 1
	        AND mo.option_type = 5
	        AND mo.option_order = md.d_sub_obj#)
	  END
	FROM dual
	)
  ELSE null
  END AS D_SUB_OBJ_NAME2,                       /* END COLUMN D_SUB_OBJ_NAME2 */
  null AS D_SUB_OBJ_NAME3,
  null AS D_SUB_OBJ_NAME4,
  decode(md.d_obj_type, '1', 'CUBE',
			'2', 'MEASURE',
                        '16', 'DIMENSIONALITY',
			'22', 'CUBE MAP',
			'23', 'CUBE DIMENSIONALITY MAP',
			'24', 'MEASURE MAP',
                        '28', 'AW CUBE ORGANIZATION',
                        '30', 'SECONDARY PARTITION LEVEL',
                        '29', 'AW') D_OBJ_TYPE,
  md.P_OWNER P_OBJ_OWNER,
  md.P_TOP_OBJ_NAME P_TOP_OBJ_NAME,
  md.P_SUB_OBJ_NAME1 P_SUB_OBJ_NAME1,
  md.P_SUB_OBJ_NAME2 P_SUB_OBJ_NAME2,
  md.P_SUB_OBJ_NAME3 P_SUB_OBJ_NAME3,
  md.P_SUB_OBJ_NAME4 P_SUB_OBJ_NAME4,
  case md.p_obj_type
  WHEN 25 -- TABLE OR VIEW
       THEN (SELECT decode(o.type#, '4', 'VIEW', 'TABLE')
             FROM obj$ o
             WHERE o.obj# = md.p_obj#
            )
       ELSE decode(md.p_obj_type, '1', 'CUBE',
			'2', 'MEASURE',
			'3', 'MODEL',
			'4', 'ASSIGNMENT',
			'6', 'CALCULATION MEMBER',
                        '8',  'BUILD PROCESS',
                        '10', 'MEASURE FOLDER',
			'11', 'DIMENSION',
			'12', 'DIMENSION LEVEL',
			'13', 'HIERARCHY',
			'14', 'HIERARCHY LEVEL',
			'15', 'ATTRIBUTE',
                        '16', 'DIMENSIONALITY',
			'17', 'ATTRIBUTE MAP',
			'18', 'HIER LEVEL MAP',
			'19', 'SOLVED LEVEL HIER MAP',
			'20', 'SOLVED VALUE HIER MAP',
			'21', 'MEMBER LIST MAP',
			'22', 'CUBE MAP',
			'23', 'CUBE DIMENSIONALITY MAP',
			'24', 'MEASURE MAP',
			'26', 'COLUMN',
                        '27', 'AW DIM ORGANIZATION',
                        '28', 'AW CUBE ORGANIZATION',
                        '29', 'AW') END AS P_OBJ_TYPE,
  decode(md.dep_type, '1', 'CONSISTENT SOLVE SPEC',
                      '2', 'DEFAULT BUILD SPEC',
                      '3', 'BUILD SPEC',
                      '4', 'BUILD PROCESS',
                      '6', 'MEASURE IN MEASURE DIM',
                      '7', 'CUSTOM ORDER',
                      '9', 'TARGET ATTRIBUTE',
                      '10', 'TARGET DIMENSION',
                      '11', 'MEMBER EXPRESSION',
                      '12', 'EXPLICIT DIMENSION',
                      '13', 'PRIMARY DIMENSION',
                      '15', 'MEASURE IN MEASURE FOLDER',
                      '16', 'MEASURE FOLDER SUBFOLDER',
                      '17', 'MAPPED DIMENSION',
                      '18', 'QUERY',
                      '19', 'FROM CLAUSE',
                      '20', 'WHERE CLAUSE',
                      '21', 'JOIN CONDITION',
                      '22', 'LEVEL_ID EXPRESSION',
                      '23', 'KEY EXPRESSION',
                      '24', 'VALUE MAP EXPRESSION',
                      '25', 'LEVEL EXPRESSION',
                      '26', 'PARENT KEY EXPRESSION',
                      '27', 'PARENT LEVEL_ID EXPRESSION',
                      '28', 'MEASURE EXPRESSION',
                      '29', 'NVL EXPRESSION',
                      '30', 'AW',
                      '31', 'AW TABLE',
                      '32', 'PARTITION LEVEL',
                      '33', 'SECONDARY PARTITION LEVEL',
                      '34', 'PRECOMPUTE CONDITION'
                      ) DEPENDENCY_TYPE
FROM
  olap_metadata_dependencies$ md,
  obj$ o,
  user$ u,
  (SELECT
    obj#,
    MIN(have_dim_access) have_all_dim_access
  FROM
    (SELECT
      c.obj# obj#,
      (CASE
        WHEN
        (do.owner# in (userenv('SCHEMAID'), 1)   -- public objects
         or do.obj# in
              ( select obj#  -- directly granted privileges
                from sys.objauth$
                where grantee# in ( select kzsrorol from x$kzsro )
              )
         or   -- user has system privileges
                ora_check_SYS_privilege (do.owner#, do.type#) = 1
        )
        THEN 1
        ELSE 0
       END) have_dim_access
    FROM
      olap_cubes$ c,
      dependency$ d,
      obj$ do
    WHERE
      do.obj# = d.p_obj#
      AND do.type# = 92 -- CUBE DIMENSION
      AND c.obj# = d.d_obj#
    )
    GROUP BY obj# ) da
WHERE
  o.obj# = md.d_top_obj#
  AND o.owner# = u.user#
  AND o.obj#=da.obj#(+)
  AND md.d_obj_type in (1, 2, 16, 22, 23, 24, 28, 29, 30)
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
  AND ((have_all_dim_access = 1) OR (have_all_dim_access is NULL))
UNION ALL
SELECT
  u.name OWNER,
  o.name as D_TOP_OBJ_NAME,
  null AS D_SUB_OBJ_NAME1,
  null AS D_SUB_OBJ_NAME2,
  null AS D_SUB_OBJ_NAME3,
  null AS D_SUB_OBJ_NAME4,
  'MEASURE FOLDER' D_OBJ_TYPE,
  md.P_OWNER P_OBJ_OWNER,
  md.P_TOP_OBJ_NAME P_TOP_OBJ_NAME,
  md.P_SUB_OBJ_NAME1 P_SUB_OBJ_NAME1,
  md.P_SUB_OBJ_NAME2 P_SUB_OBJ_NAME2,
  md.P_SUB_OBJ_NAME3 P_SUB_OBJ_NAME3,
  md.P_SUB_OBJ_NAME4 P_SUB_OBJ_NAME4,
  case md.p_obj_type
  WHEN 25 -- TABLE OR VIEW
       THEN (SELECT decode(o.type#, '4', 'VIEW', 'TABLE')
             FROM obj$ o
             WHERE o.obj# = md.p_obj#
            )
       ELSE decode(md.p_obj_type, '1', 'CUBE',
			'2', 'MEASURE',
			'3', 'MODEL',
			'4', 'ASSIGNMENT',
			'6', 'CALCULATION MEMBER',
                        '8',  'BUILD PROCESS',
                        '10', 'MEASURE FOLDER',
			'11', 'DIMENSION',
			'12', 'DIMENSION LEVEL',
			'13', 'HIERARCHY',
			'14', 'HIERARCHY LEVEL',
			'15', 'ATTRIBUTE',
                        '16', 'DIMENSIONALITY',
			'17', 'ATTRIBUTE MAP',
			'18', 'HIER LEVEL MAP',
			'19', 'SOLVED LEVEL HIER MAP',
			'20', 'SOLVED VALUE HIER MAP',
			'21', 'MEMBER LIST MAP',
			'22', 'CUBE MAP',
			'23', 'CUBE DIMENSIONALITY MAP',
			'24', 'MEASURE MAP',
			'26', 'COLUMN',
                        '27', 'AW DIM ORGANIZATION',
                        '28', 'AW CUBE ORGANIZATION',
                        '29', 'AW') END AS P_OBJ_TYPE,
  decode(md.dep_type, '1', 'CONSISTENT SOLVE SPEC',
                      '2', 'DEFAULT BUILD SPEC',
                      '3', 'BUILD SPEC',
                      '4', 'BUILD PROCESS',
                      '6', 'MEASURE IN MEASURE DIM',
                      '7', 'CUSTOM ORDER',
                      '9', 'TARGET ATTRIBUTE',
                      '10', 'TARGET DIMENSION',
                      '11', 'MEMBER EXPRESSION',
                      '12', 'EXPLICIT DIMENSION',
                      '13', 'PRIMARY DIMENSION',
                      '15', 'MEASURE IN MEASURE FOLDER',
                      '16', 'MEASURE FOLDER SUBFOLDER',
                      '17', 'MAPPED DIMENSION',
                      '18', 'QUERY',
                      '19', 'FROM CLAUSE',
                      '20', 'WHERE CLAUSE',
                      '21', 'JOIN CONDITION',
                      '22', 'LEVEL_ID EXPRESSION',
                      '23', 'KEY EXPRESSION',
                      '24', 'VALUE MAP EXPRESSION',
                      '25', 'LEVEL EXPRESSION',
                      '26', 'PARENT KEY EXPRESSION',
                      '27', 'PARENT LEVEL_ID EXPRESSION',
                      '28', 'MEASURE EXPRESSION',
                      '29', 'NVL EXPRESSION',
                      '30', 'AW',
                      '31', 'AW TABLE',
                      '32', 'PARTITION LEVEL',
                      '33', 'SECONDARY PARTITION LEVEL',
                      '34', 'PRECOMPUTE CONDITION'
                      ) DEPENDENCY_TYPE
FROM
  olap_metadata_dependencies$ md,
  obj$ o,
  user$ u
WHERE
  o.obj# = md.d_top_obj#
  AND o.owner# = u.user#
  AND md.d_obj_type = 10
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
       or   -- user has access to cubes in measure folder
              ( exists (select null from olap_meas_folder_contents$ mfc,
                                         olap_measures$ m
                        where mfc.measure_folder_obj# = o.obj#
                          and m.measure_id  = mfc.object_id
                          and (
                              m.cube_obj# in
                                ( select obj#  -- directly granted authorization
                                  from sys.objauth$
                                  where grantee#
                                        in ( select kzsrorol from x$kzsro )
                                )
                              )
                       )
              )
            )
UNION ALL
SELECT
  u.name OWNER,
  o.name as D_TOP_OBJ_NAME,
  null AS D_SUB_OBJ_NAME1,
  null AS D_SUB_OBJ_NAME2,
  null AS D_SUB_OBJ_NAME3,
  null AS D_SUB_OBJ_NAME4,
  'BUILD PROCESS' AS D_OBJ_TYPE,
  md.P_OWNER P_OBJ_OWNER,
  md.P_TOP_OBJ_NAME P_TOP_OBJ_NAME,
  md.P_SUB_OBJ_NAME1 P_SUB_OBJ_NAME1,
  md.P_SUB_OBJ_NAME2 P_SUB_OBJ_NAME2,
  md.P_SUB_OBJ_NAME3 P_SUB_OBJ_NAME3,
  md.P_SUB_OBJ_NAME4 P_SUB_OBJ_NAME4,
  case md.p_obj_type
  WHEN 25 -- TABLE OR VIEW
       THEN (SELECT decode(o.type#, '4', 'VIEW', 'TABLE')
             FROM obj$ o
             WHERE o.obj# = md.p_obj#
            )
       ELSE decode(md.p_obj_type, '1', 'CUBE',
			'2', 'MEASURE',
			'3', 'MODEL',
			'4', 'ASSIGNMENT',
			'6', 'CALCULATION MEMBER',
                        '8',  'BUILD PROCESS',
                        '10', 'MEASURE FOLDER',
			'11', 'DIMENSION',
			'12', 'DIMENSION LEVEL',
			'13', 'HIERARCHY',
			'14', 'HIERARCHY LEVEL',
			'15', 'ATTRIBUTE',
                        '16', 'DIMENSIONALITY',
			'17', 'ATTRIBUTE MAP',
			'18', 'HIER LEVEL MAP',
			'19', 'SOLVED LEVEL HIER MAP',
			'20', 'SOLVED VALUE HIER MAP',
			'21', 'MEMBER LIST MAP',
			'22', 'CUBE MAP',
			'23', 'CUBE DIMENSIONALITY MAP',
			'24', 'MEASURE MAP',
			'26', 'COLUMN',
                        '27', 'AW DIM ORGANIZATION',
                        '28', 'AW CUBE ORGANIZATION',
                        '29', 'AW') END AS P_OBJ_TYPE,
  decode(md.dep_type, '1', 'CONSISTENT SOLVE SPEC',
                      '2', 'DEFAULT BUILD SPEC',
                      '3', 'BUILD SPEC',
                      '4', 'BUILD PROCESS',
                      '6', 'MEASURE IN MEASURE DIM',
                      '7', 'CUSTOM ORDER',
                      '9', 'TARGET ATTRIBUTE',
                      '10', 'TARGET DIMENSION',
                      '11', 'MEMBER EXPRESSION',
                      '12', 'EXPLICIT DIMENSION',
                      '13', 'PRIMARY DIMENSION',
                      '15', 'MEASURE IN MEASURE FOLDER',
                      '16', 'MEASURE FOLDER SUBFOLDER',
                      '17', 'MAPPED DIMENSION',
                      '18', 'QUERY',
                      '19', 'FROM CLAUSE',
                      '20', 'WHERE CLAUSE',
                      '21', 'JOIN CONDITION',
                      '22', 'LEVEL_ID EXPRESSION',
                      '23', 'KEY EXPRESSION',
                      '24', 'VALUE MAP EXPRESSION',
                      '25', 'LEVEL EXPRESSION',
                      '26', 'PARENT KEY EXPRESSION',
                      '27', 'PARENT LEVEL_ID EXPRESSION',
                      '28', 'MEASURE EXPRESSION',
                      '29', 'NVL EXPRESSION',
                      '30', 'AW',
                      '31', 'AW TABLE',
                      '32', 'PARTITION LEVEL',
                      '33', 'SECONDARY PARTITION LEVEL',
                      '34', 'PRECOMPUTE CONDITION'
                      ) DEPENDENCY_TYPE
FROM
  olap_metadata_dependencies$ md,
  obj$ o,
  user$ u
WHERE
  o.obj# = md.d_top_obj#
  AND o.owner# = u.user#
  AND md.d_obj_type = 8 -- build process
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
/

comment on table ALL_CUBE_DEPENDENCIES
is 'OLAP metadata dependencies in the database that are accessible to the current
user'
/

