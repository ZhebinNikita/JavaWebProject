create view CDB_LOGSTDBY_SKIP_TRANSACTION as
  SELECT k."XIDUSN",k."XIDSLT",k."XIDSQN",k."CON_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_SKIP_TRANSACTION") k
/

comment on table CDB_LOGSTDBY_SKIP_TRANSACTION
is 'List the transactions to be skipped in all containers'
/

