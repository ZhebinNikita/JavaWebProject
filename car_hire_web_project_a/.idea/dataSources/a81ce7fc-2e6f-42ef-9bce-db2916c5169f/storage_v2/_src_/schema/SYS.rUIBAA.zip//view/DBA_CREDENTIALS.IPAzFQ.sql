create view DBA_CREDENTIALS as
  SELECT u.name, o.name, c.username, c.domain, c.comments,
  DECODE(bitand(c.flags, 4), 0, 'FALSE', 4, 'TRUE')
  FROM obj$ o, user$ u, sys.scheduler$_credential c
  WHERE c.obj# = o.obj# AND u.user# = o.owner#
/

comment on table DBA_CREDENTIALS
is 'All credentials in the database'
/

