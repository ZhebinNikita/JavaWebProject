create view KU$_CLSTCOL_VIEW as
  select k.clstobj#, k.tabobj#, value(o),
         k.position, k.groupid, c.col#, c.intcol#, c.segcol#,
         bitand(c.property, 4294967295),
         trunc(c.property / power(2,32)),
         c.name, c.type#
    from ku$_schemaobj_view o, col$ c, clstkey$ k
    where k.tabobj#=o.obj_num
      and c.obj#=k.tabobj#
      and c.intcol#=k.intcol#
/

