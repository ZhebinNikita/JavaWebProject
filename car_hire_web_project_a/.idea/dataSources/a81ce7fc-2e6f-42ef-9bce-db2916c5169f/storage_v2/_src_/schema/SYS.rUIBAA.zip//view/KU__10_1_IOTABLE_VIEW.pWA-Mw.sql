create view KU$_10_1_IOTABLE_VIEW as
  select t.* from ku$_iotable_view t
  where bitand(t.trigflag,65536+131072)=0
/

