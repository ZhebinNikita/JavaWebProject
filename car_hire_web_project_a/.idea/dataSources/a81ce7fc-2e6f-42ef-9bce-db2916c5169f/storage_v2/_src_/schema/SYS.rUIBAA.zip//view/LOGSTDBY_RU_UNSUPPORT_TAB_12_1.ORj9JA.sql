create view LOGSTDBY_RU_UNSUPPORT_TAB_12_1 as
  select u.name owner, o.name table_name, c.name column_name,
         c.scale, c.precision#, c.charsetform, c.type#,
   (case when bitand(t.flags, 536870912) = 536870912
         then 'Mapping table for physical rowid of IOT'
         else null end) attributes,
    (case
    /* The following are tables that are system maintained */
    when bitand(o.flags,
                2                                       /* temporary object */
              + 16                                      /* secondary object */
              + 32                                  /* in-memory temp table */
              + 128                           /* dropped table (RecycleBin) */
             ) != 0
    or bitand(t.flags,
                262144     /* 0x00040000        Summary Container Table, MV */
              + 134217728  /* 0x08000000          in-memory temporary table */
              + 536870912  /* 0x20000000  Mapping Tab for Phys rowid of IOT */
             ) != 0
    or bitand(t.property,
                512        /* 0x00000200               iot OVeRflow segment */
              + 8192       /* 0x00002000                       nested table */
              + 4194304    /* 0x00400000             global temporary table */
              + 8388608    /* 0x00800000   session-specific temporary table */
              + 33554432   /* 0x02000000        Read Only Materialized View */
              + 67108864   /* 0x04000000            Materialized View table */
              + 134217728  /* 0x08000000                    Is a Sub object */
              + 2147483648 /* 0x80000000                     eXternal TaBle */
              + 4294967296 /* 0x100000000                              Cube */
              + 8589934592 /* 0x200000000                      FBA Internal */
             ) != 0
    or bitand(t.trigflag,
                536870912  /* 0x20000000                  DDLs autofiltered */
               ) != 0
    or exists                                                /* MVLOG table */
       (select 1
        from sys.mlog$ ml where ml.mowner = u.name and ml.log = o.name)
    or exists (select 1 from sys.secobj$ so           /* ODCI storage table */
               where o.obj# = so.secobj#)
    or exists (select 1 from sys.opqtype$ opq       /* XML OR storage table */
               where o.obj# = opq.obj#
                 and bitand(opq.flags, 32) = 32)
    or (bitand(t.property, 131072) != 0 and               /* AQ spill table */
        o.name like 'AQ$\_%\_P' escape '\')
    or (bitand(t.property, 131072) != 0 and            /* AQ commit q table */
        o.name like 'AQ$\_%\_C' escape '\')
  then -1
    /* The following tables are data tables in internal schemata *
     * that are not secondary objects                            */
  when (exists (select 1 from system.logstdby$skip_support s
                where s.name = u.name and action = 0))
  then -2
    /* The following tables are user visible tables that we choose to       *
     * skip because of some unsupported attribute of the table or column    */
  when (bitand(t.property, 1) = 1       /* 0x00000001            typed table */
    AND((bitand(t.property, 4096) = 4096) /* PK OID */
        OR exists
            (select 1
              from  sys.col$ c1
              where c1.obj# = t.obj# and
                    ((c1.type# = 58 and
 (exists (select 1 from opqtype$ opq
                   where opq.type=1
                   and bitand(opq.flags,512) = 512      /* hierarchy enabled */
                   and opq.obj#=c1.obj#
                   and opq.intcol#=c1.intcol#) or
  exists (select 1 from coltype$ ct
                   where ct.obj#=c1.obj#
                   and   ct.intcol# = c1.intcol#
                   and /* SYS.XMLTYPE */
                   ct.toid != '00000000000000000000000000020100'
                   and /* SYS.ANYDATA */
                   ct.toid != '00000000000000000000000000020011')))               /* Opaque */
                     or (c1.type# = 114)                            /* BFILE */
                        /* Non-hidden varray or varray stored in table in an */
                        /* ADT typed table.                                  */
                     or ((c1.type# = 123 and
  (bitand(c1.property, 4) = 4 or bitand(c1.property, 32)!=32)) and
                         (exists
                          (select 1 from sys.col$ c2
                             where c2.obj# = t.obj# and
                                   c2.name = 'SYS_NC_ROWINFO$' and
                                   c2.type# = 121)))
                     or (c1.type# in (58, 121, 123) and
 (exists
  (select 1 from obj$ o3, coltype$ ct3, user$ u3
    where u3.user# = o3.owner#
      and c1.obj# = ct3.obj#
      and c1.intcol# = ct3.intcol#
      and ct3.toid = o3.oid$
      and exists (select 1 from system.logstdby$skip_support sk
                   where sk.action=-5
                     and sk.name = u3.name   /* type owner */
                     and sk.name2 = o3.name  /* type name  */))))        /* Built-in */
                                       /* Nested table in an ADT typed table */
                     or (c1.type#=122 and
                         (exists
                          (select 1 from sys.col$ c2
                             where c2.obj# = t.obj# and
                                   c2.name = 'SYS_NC_ROWINFO$' and
                                   c2.type# = 121)))))))  or (bitand(t.property, 4611686018427387904) != 0)
  or (bitand(t.property, 32) = 32)
    and exists (select 1 from partobj$ po
                where po.obj#=o.obj#
                and  (po.parttype in (3,             /* System partitioned */
                                      5)))        /* Reference partitioned */
  or (c.type# not in (
                  2,                               /* NUMBER */
                  8,                                 /* LONG */
                  12,                                /* DATE */
                  24,                            /* LONG RAW */
                  96,                                /* CHAR */
                  100,                       /* BINARY FLOAT */
                  101,                      /* BINARY DOUBLE */
                  112,                     /* CLOB and NCLOB */
                  113,                               /* BLOB */
                  180,                     /* TIMESTAMP (..) */
                  181,       /* TIMESTAMP(..) WITH TIME ZONE */
                  182,         /* INTERVAL YEAR(..) TO MONTH */
                  183,     /* INTERVAL DAY(..) TO SECOND(..) */
                  231) /* TIMESTAMP(..) WITH LOCAL TIME ZONE */
  and (c.type# != 1
  or  (c.type# = 1 and (bitand(c.property, 128) = 128                 /* column stored in LOB */
     and c.length between 4001 and 6398
     and (exists                                  /* Unique index on vc32k */
          (select null
           from ind$ i, icol$ ic
           where i.bo# = t.obj#
             and ic.obj# = i.obj#
             and c.intcol# = ic.intcol#
             and bitand(i.property, 1) = 1                       /* Unique */
          )
         or exists                  /* Primary or unique constraint on 32k */
          (select null
           from cdef$ cd, ccol$ ccol
           where cd.obj# = t.obj#
             and cd.obj# = ccol.obj#
             and cd.con# = ccol.con#
             and cd.type# in (2,3)
             and ccol.intcol# = c.intcol#
          )))))             /* 32k varchar */
  and (c.type# != 23                      /* RAW not RAW OID */
  or  (c.type# = 23 and (bitand(c.property, 2) = 2 or (bitand(c.property, 128) = 128                 /* column stored in LOB */
     and c.length between 4001 and 6398
     and (exists                                  /* Unique index on vc32k */
          (select null
           from ind$ i, icol$ ic
           where i.bo# = t.obj#
             and ic.obj# = i.obj#
             and c.intcol# = ic.intcol#
             and bitand(i.property, 1) = 1                       /* Unique */
          )
         or exists                  /* Primary or unique constraint on 32k */
          (select null
           from cdef$ cd, ccol$ ccol
           where cd.obj# = t.obj#
             and cd.obj# = ccol.obj#
             and cd.con# = ccol.con#
             and cd.type# in (2,3)
             and ccol.intcol# = c.intcol#
          ))))))                              /* 32k varchar */
  and (c.type# != 58                                               /* Opaque */
  or  (c.type# = 58 and
 (exists (select 1 from opqtype$ opq
                   where opq.type=1
                   and bitand(opq.flags,512) = 512      /* hierarchy enabled */
                   and opq.obj#=c.obj#
                   and opq.intcol#=c.intcol#) or
  exists (select 1 from coltype$ ct
                   where ct.obj#=c.obj#
                   and   ct.intcol# = c.intcol#
                   and /* SYS.XMLTYPE */
                   ct.toid != '00000000000000000000000000020100'
                   and /* SYS.ANYDATA */
                   ct.toid != '00000000000000000000000000020011'))))
  and (c.type# != 121                                                 /* ADT */
  or  ( (c.type#=121 and
 (exists
   (select 1 from sys.col$ c2
     where bitand(c2.property, 32) = 32                          /* Hidden */
       and t.obj# = c2.obj#
       and c.col# = c2.col#
       and (c2.type# in (114, 122, 111) or       /* BFILE/Nested Table/REF */
           (c2.type# = 123 and
  (bitand(c2.property, 4) = 4 or bitand(c2.property, 32)!=32)) or                    /* Varray */
           (c2.type# = 58 and
 (exists (select 1 from opqtype$ opq
                   where opq.type=1
                   and bitand(opq.flags,512) = 512      /* hierarchy enabled */
                   and opq.obj#=c2.obj#
                   and opq.intcol#=c2.intcol#) or
  exists (select 1 from coltype$ ct
                   where ct.obj#=c2.obj#
                   and   ct.intcol# = c2.intcol#
                   and /* SYS.XMLTYPE */
                   ct.toid != '00000000000000000000000000020100'
                   and /* SYS.ANYDATA */
                   ct.toid != '00000000000000000000000000020011'))) or                    /* Opaque */
           (c2.type# in (58, 121, 123) and
 (exists
  (select 1 from obj$ o3, coltype$ ct3, user$ u3
    where u3.user# = o3.owner#
      and c2.obj# = ct3.obj#
      and c2.intcol# = ct3.intcol#
      and ct3.toid = o3.oid$
      and exists (select 1 from system.logstdby$skip_support sk
                   where sk.action=-5
                     and sk.name = u3.name   /* type owner */
                     and sk.name2 = o3.name  /* type name  */))))      /* Built-in type in Skip */
           )))) or
       (c.type#=121 and
       /* For non-typed tables, Primary keys on ADT attrs are disallowed.    */
       /* Primary keys should be supported on typed tables.                  */
       (bitand(t.property, 1) = 0
         and exists
         (select 1 from
           sys.ccol$ ccol, sys.col$ c2, sys.cdef$ cd
           where c.obj# = c2.obj#
             and c.obj# = cd.obj#
             and c.obj# = ccol.obj#
             and c.col# = c2.col#
             and ccol.con# = cd.con#
             and ccol.intcol# = c2.intcol#
             and bitand(c2.property, 32) = 32    /* Hidden */
             and cd.type# = 2)))))          /* Primary key */
  and (c.type# != 123                                              /* Varray */
  or (c.type# = 123 and
  (bitand(c.property, 4) = 4 or bitand(c.property, 32)!=32))))
  ----------------------------------------------------------
  /* table must have at least one scalar column to use as the id key */
  or ((c.type# in (8,24,58,112,113,121,123) or bitand(c.property, 128) = 128)
      and bitand(t.property, 1) = 0                  /* not a typed table or */
      and 0 = (select count(*) from sys.col$ c2
               where t.obj# = c2.obj#
               and bitand(c2.property, 32)  != 32              /* Not hidden */
	       and bitand(c2.property, 8)   != 8              /* Not virtual */
               and bitand(c2.property, 128) != 128      /* not stored in lob */
               and (c2.type# in ( 1,                             /* VARCHAR2 */
                                  2,                               /* NUMBER */
                                  12,                                /* DATE */
                                  23,                                 /* RAW */
                                  96,                                /* CHAR */
                                  100,                       /* BINARY FLOAT */
                                  101,                      /* BINARY DOUBLE */
                                  180,                     /* TIMESTAMP (..) */
                                  181,       /* TIMESTAMP(..) WITH TIME ZONE */
                                  182,         /* INTERVAL YEAR(..) TO MONTH */
                                  183,     /* INTERVAL DAY(..) TO SECOND(..) */
                                  231) /* TIMESTAMP(..) WITH LOCAL TIME ZONE */
      )))
  /* UNSUPPORTED BUILT-IN TYPE List:                                         */
  /* Check list of unsupported datatypes maintained in skip_support.  These  */
  /* could be built-in opaque, ADT or varray types that are singled out as   */
  /* being unsupported.                                                      */
  or (c.type# in (58, 121, 123) and
 (exists
  (select 1 from obj$ o3, coltype$ ct3, user$ u3
    where u3.user# = o3.owner#
      and c.obj# = ct3.obj#
      and c.intcol# = ct3.intcol#
      and ct3.toid = o3.oid$
      and exists (select 1 from system.logstdby$skip_support sk
                   where sk.action=-5
                     and sk.name = u3.name   /* type owner */
                     and sk.name2 = o3.name  /* type name  */))))
  /* Identity column + RNW (Replace null with) column */
  or bitand(c.property, 137438953472 + 274877906944 + 1099511627776) != 0
  ----------------------------------------------------------
  then 0 else 1 end) gensby
  from sys.obj$ o, sys.user$ u, sys.tab$ t, sys.col$ c
  where o.owner# = u.user#
  and o.obj# = t.obj#
  and o.obj# = c.obj#
  and t.obj# = o.obj#
  and bitand(c.property, 32) != 32                         /* Not hidden */

