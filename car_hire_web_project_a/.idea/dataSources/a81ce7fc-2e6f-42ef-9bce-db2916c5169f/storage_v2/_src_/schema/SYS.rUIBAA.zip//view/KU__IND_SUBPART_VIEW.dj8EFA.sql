create view KU$_IND_SUBPART_VIEW as
  select isp.obj#,
         (select value(so) from ku$_schemaobj_view so
          where so.obj_num = isp.obj#),
         ts.name, ts.blocksize,
         (select value(s) from ku$_storage_view s
          where isp.ts# = s.ts_num
          AND isp.file# = s.file_num
          AND isp.block# = s.block_num),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = isp.obj#),
         isp.dataobj#,
--part only
         null,null,null,null,null,null,null,null,
--subpart only
         isp.pobj#,
         isp.subpart#,
         (select /*+ ordered index_rs_asc(icp i_indcompart_bopart$)
                     push_pred(tcp) push_pred(tsp) */
              tspo.subname
            from indcompart$ icp, ind$ i, tabcompart$ tcp,
                 tabsubpart$ tsp, obj$ tspo
            where icp.obj#=opart.obj# and
                  icp.bo#=iobj.obj# and
                  i.obj#=icp.bo# and
                  tcp.bo#=i.bo# and
                  tcp.part#=icp.part# and
                  tsp.pobj#=tcp.obj# and
                  tsp.subpart#=isp.subpart# and
                  tspo.obj#=tsp.obj#),
--both
         isp.flags, isp.pctfree$, isp.initrans,
         isp.maxtrans, to_char(isp.analyzetime,'YYYY/MM/DD HH24:MI:SS'),
         isp.samplesize, isp.rowcnt,
         isp.blevel, isp.leafcnt, isp.distkey, isp.lblkkey, isp.dblkkey,
         isp.clufac, isp.spare1, isp.spare2, isp.spare3
  from indsubpart$ isp, ts$ ts, obj$ opart, obj$ iobj
  where isp.ts# = ts.ts# and
        opart.obj#=isp.pobj# and
        iobj.name=opart.name and
        iobj.type#=1 and
        iobj.owner#=opart.owner#
/

