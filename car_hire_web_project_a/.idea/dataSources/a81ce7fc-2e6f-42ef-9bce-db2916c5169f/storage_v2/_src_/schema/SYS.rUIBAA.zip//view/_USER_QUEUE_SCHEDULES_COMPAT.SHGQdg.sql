create view "_USER_QUEUE_SCHEDULES_COMPAT" as
  select q.name QNAME,
       s.destination DESTINATION,
       cast(s.start_time as timestamp(6) with time zone) START_DATE,
       substr(to_char(s.start_time,'HH24:MI:SS'),1,8) START_TIME,
       to_number(s.duration) PROPAGATION_WINDOW,
       s.next_time NEXT_TIME, to_number(s.latency) LATENCY,
       s.disabled SCHEDULE_DISABLED,
       substr(s.process_name,1,4) PROCESS_NAME,
       decode(s.sid, NULL, NULL,
         concat(to_char(s.sid), concat(', ',to_char(s.serial)))) SESSION_ID,
       s.instance INSTANCE,
       cast(s.last_run as timestamp(6) with time zone) LAST_RUN_DATE,
       substr(to_char(s.last_run,'HH24:MI:SS'),1,8) LAST_RUN_TIME,
       s.cur_start_time CURRENT_START_DATE,
       substr(to_char(s.cur_start_time,'HH24:MI:SS'),1,8) CURRENT_START_TIME,
       cast(s.next_run as timestamp(6) with time zone) NEXT_RUN_DATE,
       substr(to_char(s.next_run,'HH24:MI:SS'),1,8) NEXT_RUN_TIME,
       s.total_time TOTAL_TIME, s.total_msgs TOTAL_NUMBER,
       s.total_bytes TOTAL_BYTES,
       s.max_num_per_win MAX_NUMBER, s.max_size MAX_BYTES,
       s.total_msgs/decode(s.total_windows, 0, 1, s.total_windows) AVG_NUMBER,
       s.total_bytes/decode(s.total_msgs, 0, 1, s.total_msgs) AVG_SIZE,
       s.total_time/decode(s.total_msgs, 0, 1, s.total_msgs) AVG_TIME,
       s.failures FAILURES, s.error_time LAST_ERROR_DATE,
       substr(to_char(s.error_time,'HH24:MI:SS'),1,8) LAST_ERROR_TIME,
       s.last_error_msg LAST_ERROR_MSG,
       'PERSISTENT' MESSAGE_DELIVERY_MODE,
       null ELAPSED_DEQUEUE_TIME, null ELAPSED_PICKLE_TIME,
       s.job_name JOB_NAME
from system.aq$_queues q, system.aq$_queue_tables t,
     sys.aq$_schedules s, sys.user$ u
where u.user# = USERENV('SCHEMAID')
and   u.name  = t.schema
and   s.oid  = q.oid
and   q.table_objno = t.objno
union
select q.name QNAME,
       s.destination DESTINATION,
       cast(s.start_time as timestamp(6) with time zone) START_DATE,
       substr(to_char(s.start_time,'HH24:MI:SS'),1,8) START_TIME,
       to_number(s.duration) PROPAGATION_WINDOW,
       s.next_time NEXT_TIME, to_number(s.latency) LATENCY,
       s.disabled SCHEDULE_DISABLED,
       substr(s.process_name,1,4) PROCESS_NAME,
       decode(s.sid, NULL, NULL,
         concat(to_char(s.sid), concat(', ',to_char(s.serial)))) SESSION_ID,
       s.instance INSTANCE,
       cast(s.last_run as timestamp(6) with time zone) LAST_RUN_DATE,
       substr(to_char(s.last_run,'HH24:MI:SS'),1,8) LAST_RUN_TIME,
       s.cur_start_time CURRENT_START_DATE,
       substr(to_char(s.cur_start_time,'HH24:MI:SS'),1,8) CURRENT_START_TIME,
       cast(s.next_run as timestamp(6) with time zone) NEXT_RUN_DATE,
       substr(to_char(s.next_run,'HH24:MI:SS'),1,8) NEXT_RUN_TIME,
       p.elapsed_propagation_time/100 TOTAL_TIME, p.total_msgs TOTAL_NUMBER,
       p.total_bytes TOTAL_BYTES,
       p.max_num_per_win MAX_NUMBER, p.max_size MAX_BYTES,
       p.total_msgs/decode(s.total_windows, 0, 1, s.total_windows) AVG_NUMBER,
       p.total_bytes/decode(p.total_msgs, 0, 1, p.total_msgs) AVG_SIZE,
       s.total_time/decode(p.total_msgs, 0, 1, p.total_msgs) AVG_TIME,
       s.failures FAILURES, s.error_time LAST_ERROR_DATE,
       substr(to_char(s.error_time,'HH24:MI:SS'),1,8) LAST_ERROR_TIME,
       s.last_error_msg LAST_ERROR_MSG,
       'BUFFERED' MESSAGE_DELIVERY_MODE,
       p.elapsed_dequeue_time/100 ELAPSED_DEQUEUE_TIME,
       p.elapsed_pickle_time/100 ELAPSED_PICKLE_TIME,
       s.job_name JOB_NAME
from system.aq$_queues q, system.aq$_queue_tables t, v$propagation_sender p,
     sys.aq$_schedules s, sys.user$ u
where u.user# = USERENV('SCHEMAID')
and   u.name  = t.schema
and   s.oid  = q.oid
and   q.table_objno = t.objno
and   q.eventid = p.queue_id
and   p.dblink = s.destination
and   (p.con_id = sys_context('USERENV', 'CON_ID') or (p.con_id IS NULL and sys_context('USERENV', 'CON_ID') IS NULL))
/

