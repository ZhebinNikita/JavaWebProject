create view GV_$LOGSTDBY as
  select "INST_ID","SERIAL#","LOGSTDBY_ID","PID","TYPE","STATUS_CODE","STATUS","HIGH_SCN","CON_ID" from gv$logstdby
/

