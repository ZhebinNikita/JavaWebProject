create view KU$_INDEX_OBJNUM_VIEW as
  select i.obj#,
         value(o),
         ts.name, ts.ts#,
         i.type#, i.flags, i.property,
         --  for_pkoid
         nvl((select 1 from cdef$ c
              where c.enabled = i.obj# and
                    c.type# = 2 and
                    (select 1 from tab$ t
                     where t.obj# = c.obj# and
                     bitand(t.property, 4096) = 4096) = 1) ,0),
         --  for_refpar
         nvl((select 1 from dual where
          (exists (select 1 from cdef$ c
              where c.enabled = i.obj# and
                    c.type# in(2, 3) and
                    (bitand(c.defer,1024)!=0)))),0),
         i.bo#,
         (select value(so) from ku$_schemaobj_view so
          where so.obj_num = i.bo#)
  from  ku$_schemaobj_view o, ind$ i, ts$ ts
  where  o.obj_num = i.obj#
         AND  i.ts# = ts.ts#
         AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

