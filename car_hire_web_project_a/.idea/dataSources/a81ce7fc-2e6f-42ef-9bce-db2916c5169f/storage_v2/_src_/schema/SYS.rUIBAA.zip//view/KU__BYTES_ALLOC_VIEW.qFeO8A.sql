create view KU$_BYTES_ALLOC_VIEW as
  select s.file_num,s.block_num,ts.ts#,
       case when ts.bitmapped=0
            then ts.blocksize*s.blocks
            else dbms_metadata_util.bytes_alloc(ts.ts#,
                                                s.file_num,
                                                s.block_num,
                                                ts.blocksize)
        end
  from ku$_storage_view s, ts$ ts
  where ts.ts#     = s.ts_num
/

