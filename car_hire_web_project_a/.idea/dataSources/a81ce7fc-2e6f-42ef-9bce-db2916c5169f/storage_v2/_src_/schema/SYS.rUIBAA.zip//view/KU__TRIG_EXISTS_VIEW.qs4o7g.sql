create view KU$_TRIG_EXISTS_VIEW as
  select t.obj#,t.baseobject,u.name
 from trigger$ t, obj$ o, user$ u
 where o.obj# = t.obj#
 and o.owner#=u.user#
 and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

