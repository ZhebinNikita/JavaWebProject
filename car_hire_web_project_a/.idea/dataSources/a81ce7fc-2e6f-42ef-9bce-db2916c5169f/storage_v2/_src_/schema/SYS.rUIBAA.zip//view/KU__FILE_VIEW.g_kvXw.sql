create view KU$_FILE_VIEW as
  select  substrb(fn.fnnam, -(least(lengthb(fn.fnnam),923)), 923),
                replace(fn.fnnam, '''', ''''''),
                f.blocks, fh.fhfsz, f.maxextend, f.inc, f.ts#,null,
                sys.dbms_metadata_util.is_omf(
                  substrb(fn.fnnam, -(least(lengthb(fn.fnnam),923)), 923))
        from    sys.x$kccfn fn, sys.file$ f, x$kcvfh fh
        where   f.file# = fn.fnfno AND
                fn.fnnam IS NOT NULL AND
                fn.fnfno = fh.hxfil AND
                fn.fntyp = 4 AND                     /* For data files */
                f.spare1 is NULL
      union all
        select  substrb(fn.fnnam, -(least(lengthb(fn.fnnam),923)), 923),
                replace (fn.fnnam, '''', ''''''),
                f.blocks,
                DECODE(hc.ktfbhccval, 0, hc.ktfbhcsz, NULL),
                DECODE(hc.ktfbhccval, 0, hc.ktfbhcmaxsz, NULL),
                DECODE(hc.ktfbhccval, 0, hc.ktfbhcinc, NULL),
                ts.ts#,
                null,
                sys.dbms_metadata_util.is_omf(
                  substrb(fn.fnnam, -(least(lengthb(fn.fnnam),923)), 923))
        FROM    sys.x$kccfn fn, sys.file$ f, sys.x$ktfbhc hc, sys.ts$ ts
        WHERE   fn.fnfno = f.file# AND
                fn.fntyp = 4 AND                         /* For data files */
                fn.fnnam IS NOT NULL AND
                f.spare1 is NOT NULL AND
                fn.fnfno = hc.ktfbhcafno AND
                hc.ktfbhctsn = ts.ts#
      union all
        select                                       /*+ ordered use_nl(hc) +*/
                substrb(fn.fnnam, -(least(lengthb(fn.fnnam),923)), 923),
                replace (fn.fnnam, '''', ''''''),
                /* Bug 21747321: Temp tablespaces are writable in read only
                   database. When ever temp tablespace state gets modifed
                   then status can not be modified in ts$ and size value
                   also becomes zero. So, fetch temp tablespace status and
                   tempfile status from x$kcctf */
                DECODE(hc.ktfthccval, 0, hc.ktfthcsz, 1, tf.tfcsz, -1),
                DECODE(hc.ktfthccval, 0, hc.ktfthcsz, 1, tf.tfcsz, -1),
                DECODE(hc.ktfthccval, 0, hc.ktfthcmaxsz, NULL),
                DECODE(hc.ktfthccval, 0, hc.ktfthcinc, NULL),
                ts.ts#,
                tf.tfsta,
                sys.dbms_metadata_util.is_omf(
                  substrb(fn.fnnam, -(least(lengthb(fn.fnnam),923)), 923))
        FROM    sys.x$kccfn fn, sys.x$ktfthc hc, sys.ts$ ts, sys.x$kcctf tf
        WHERE   fn.fntyp = 7 AND
                fn.fnnam IS NOT NULL AND
                fn.fnfno = hc.ktfthctfno AND
                ts.ts# = tf.tftsn AND
                tf.tffnh=fn.fnnum AND
                hc.ktfthctsn(+) = ts.ts#
/

