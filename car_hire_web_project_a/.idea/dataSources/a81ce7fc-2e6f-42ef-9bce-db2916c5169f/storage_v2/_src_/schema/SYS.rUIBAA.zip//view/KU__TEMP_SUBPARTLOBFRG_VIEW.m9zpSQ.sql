create view KU$_TEMP_SUBPARTLOBFRG_VIEW as
  SELECT
              lf.parentobj#,
              lf.ts#,
              lf.fragobj#,
              row_number() OVER
                 (partition by lf.parentobj# order by lf.frag#) - 1,
              lf.tabfragobj#
        FROM sys.lobfrag$ lf
/

