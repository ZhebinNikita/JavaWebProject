create view DBA_ADDM_SYSTEM_DIRECTIVES as
  SELECT i.INSTANCE_ID as INSTANCE_ID,
             i.INSTANCE_NAME as INSTANCE_NAME,
             d.DIRECTIVE_NAME as DIRECTIVE_NAME,
             prvt_hdm.describe_directive(d.DIRECTIVE_NAME, i.data)
                   as DESCRIPTION
      FROM   dba_advisor_dir_instances i,
             dba_advisor_dir_definitions d
      WHERE  i.DIRECTIVE_ID = d.ID
        AND  d.ADVISOR_ID = 1
/

