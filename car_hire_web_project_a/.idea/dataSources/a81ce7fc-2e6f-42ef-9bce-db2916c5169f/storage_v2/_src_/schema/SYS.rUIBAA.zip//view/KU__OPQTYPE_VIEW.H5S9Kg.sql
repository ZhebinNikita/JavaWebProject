create view KU$_OPQTYPE_VIEW as
  select opq.obj#, opq.intcol#, opq.type, opq.flags, opq.lobcol,
         opq.objcol, opq.extracol, opq.schemaoid, opq.elemnum,
         decode(bitand(opq.flags,2),0,NULL,
           (select value (xe) from ku$_xmlschema_elmt_view xe
                where opq.schemaoid = xe.schemaoid
                  and opq.elemnum   = xe.elemnum
                  and opq.obj#      = xe.obj_num
                  and opq.intcol#   = xe.intcol_num))
  from sys.opqtype$ opq
/

