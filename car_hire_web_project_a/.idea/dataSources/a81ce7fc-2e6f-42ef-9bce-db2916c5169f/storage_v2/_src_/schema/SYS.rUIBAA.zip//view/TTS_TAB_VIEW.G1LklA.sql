create view TTS_TAB_VIEW as
  select t.obj#,t.ts#, t.property
from   tab$ t
where  BITAND(t.property, 2151678048)=0
union all
/* IOT - returns IOT index object's ts# */
select t.obj#, i.ts#, t.property
from   tab$ t, ind$ i
where  BITAND(t.property, 72)=72 AND i.bo#=t.obj#
union all
/* partitioned table - returns partitioned objects default ts#.
   Note that it is not necessary to check against all partitions and
   subpartitions because (1) there is already a check for containment
   among default tablespace and partition and subpartition tablespaces,
   (2) containment property is transitive.
*/
select t.obj#, po.defts#, t.property
from   tab$ t, partobj$ po
where  BITAND(t.property, 40)=40 and po.obj#=t.obj#
/

