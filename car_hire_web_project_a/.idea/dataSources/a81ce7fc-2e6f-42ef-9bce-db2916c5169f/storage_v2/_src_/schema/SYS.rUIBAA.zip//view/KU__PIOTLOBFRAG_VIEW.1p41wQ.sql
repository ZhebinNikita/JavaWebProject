create view KU$_PIOTLOBFRAG_VIEW as
  select lf.fragobj#, null, l.intcol#,
        (select value(o) from ku$_schemaobj_view o
         where o.obj_num = lf.fragobj#),
        (select value(s) from ku$_storage_view s
         where s.file_num  = lf.file#
         and   s.block_num = lf.block#
         and   s.ts_num    = lf.ts#),
        (select value(s) from ku$_deferred_stg_view s
         where s.obj_num = lf.fragobj#),
        (select ts.name from ts$ ts where lf.ts# = ts.ts#),
        (select ts.blocksize from ts$ ts where lf.ts# = ts.ts#),
        lf.indfragobj#,
        (select value(i) from ku$_lobfragindex_view i
                 where i.obj_num=lf.indfragobj#),
        lf.chunk, lf.pctversion$, lf.fragflags, lf.fragpro,
        null, null, lf.spare1, lf.spare2, to_char(lf.spare3),
  /* attributes only for lobfarg (partitioned) */
        lf.parentobj#, pl.tabobj#, l.obj#,
        dbms_metadata.get_partn(7,lf.parentobj#,lf.frag#)
  from  lob$ l, partlob$ pl, lobfrag$ lf
        where l.lobj#=lf.parentobj# and pl.lobj#=lf.parentobj#
/

