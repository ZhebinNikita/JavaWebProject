create view KU$_PARTLOB_VIEW as
  select l.tabobj#, l.intcol#,
        (select value(o) from ku$_schemaobj_view o
         where o.obj_num = l.lobj#),
        (select ts.name from ts$ ts where l.defts# = ts.ts#),
        NVL(
          (select ts.blocksize from ts$ ts where l.defts# = ts.ts#),
          NVL(         /* should be avail. thru lobcompart, lobfrag if null */
            (select ts.blocksize
             from   ts$ ts, lobfrag$ lf
             where  l.lobj# = lf.parentobj# and
                    lf.ts# = ts.ts# and rownum < 2),
            (select ts.blocksize
             from   ts$ ts, lobcomppart$ lcp, lobfrag$ lf
             where  l.lobj# = lcp.lobj# and
                    lcp.partobj# = lf.parentobj# and
                    lf.ts# = ts.ts# and rownum < 2))),
        l.defchunk, l.defpctver$, l.defflags, l.defpro,
        l.definiexts, l.defextsize, l.defminexts, l.defmaxexts,
        l.defextpct, l.deflists, l.defgroups, l.defbufpool,
        l.spare1, l.spare2, l.spare3,
        l.defmaxsize, l.defretention, l.defmintime
  from partlob$ l
/

