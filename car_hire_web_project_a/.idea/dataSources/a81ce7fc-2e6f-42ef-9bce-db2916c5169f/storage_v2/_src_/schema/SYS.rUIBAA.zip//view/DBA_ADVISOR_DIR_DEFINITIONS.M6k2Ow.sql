create view DBA_ADVISOR_DIR_DEFINITIONS as
  select a.id as id,
             a.advisor_id as advisor_id,
             b.name as advisor_name,
             a.name as directive_name,
             a.domain as domain_name,
             a.description as description,
             a.type# as type,
             decode(a.type#,1,'Filter',2,'Single value',3,'Multiple Values',
                            4,'Conditional',5,'Constraint','Unknown') as type_name,
             decode(bitand(a.flags,1),1,'MUTABLE','IMMUTABLE') as task_status,
             decode(bitand(a.flags,2),2,'MULTIPLE','SINGLE') as instances,
             c.data as metadata
      from wri$_adv_directive_defs a, wri$_adv_definitions b,
           wri$_adv_directive_meta c
      where a.advisor_id = b.id
        and a.metadata_id = c.id
/

