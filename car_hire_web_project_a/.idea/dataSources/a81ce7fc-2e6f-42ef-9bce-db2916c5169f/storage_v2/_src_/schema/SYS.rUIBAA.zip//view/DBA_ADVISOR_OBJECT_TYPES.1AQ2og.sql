create view DBA_ADVISOR_OBJECT_TYPES as
  select a.indx as object_type_id,
             a.object_type as object_type
      from x$keaobjt a
/

