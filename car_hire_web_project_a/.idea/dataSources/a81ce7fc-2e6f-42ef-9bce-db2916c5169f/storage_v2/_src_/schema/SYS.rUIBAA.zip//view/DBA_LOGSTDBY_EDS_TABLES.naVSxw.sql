create view DBA_LOGSTDBY_EDS_TABLES as
  select owner, table_name, ctime from system.logstdby$eds_tables
/

comment on table DBA_LOGSTDBY_EDS_TABLES
is 'List of all tables that have EDS-based replication for Logical Standby'
/

