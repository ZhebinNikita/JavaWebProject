create view DBA_MEASURE_FOLDER_SUBFOLDERS as
  SELECT
  u.name OWNER,
  o.name MEASURE_FOLDER_NAME,
  uchild.name MEASURE_SUBFOLDER_OWNER,
  ochild.name MEASURE_SUBFOLDER_NAME
FROM
  olap_meas_folder_contents$ mfc,
  obj$ o,
  obj$ ochild,
  user$ uchild,
  user$ u
WHERE
  mfc.MEASURE_FOLDER_OBJ# = o.obj# -- PARENT
  AND ochild.owner# = uchild.user# -- SUBFOLDER_OWNER
  AND o.owner#=u.user#
  AND mfc.object_type = 10 --MEASURE_FOLDER
  AND ochild.obj# = mfc.OBJECT_ID --CHILD
/

comment on table DBA_MEASURE_FOLDER_SUBFOLDERS
is 'OLAP Measure Folders contained within the database OLAP Measure Folders'
/

