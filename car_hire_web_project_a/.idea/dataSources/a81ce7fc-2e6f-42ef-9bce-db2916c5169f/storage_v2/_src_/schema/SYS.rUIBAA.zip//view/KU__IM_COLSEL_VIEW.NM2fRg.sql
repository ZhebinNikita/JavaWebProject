create view KU$_IM_COLSEL_VIEW as
  select   obj_num, inst_id, column_name, inmemory_compression, con_id
   from sys.v$im_column_level
   where inmemory_compression != 'DEFAULT'
     and inmemory_compression != 'UNSPECIFIED'
/

