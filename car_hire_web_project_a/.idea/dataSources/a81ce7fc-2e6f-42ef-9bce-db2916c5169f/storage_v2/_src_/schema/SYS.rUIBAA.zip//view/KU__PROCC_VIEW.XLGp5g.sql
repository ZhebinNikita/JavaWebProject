create view KU$_PROCC_VIEW as
  select
  obj#,
  procedure#,
  entrypoint#
  from procedurec$
/

