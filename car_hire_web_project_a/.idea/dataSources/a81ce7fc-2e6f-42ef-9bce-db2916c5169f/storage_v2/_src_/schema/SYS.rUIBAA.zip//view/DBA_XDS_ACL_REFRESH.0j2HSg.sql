create view DBA_XDS_ACL_REFRESH as
  select
  b.schema_name,
  b.table_name,
  b.acl_mview_name,
  b.refresh_mode,
  b.refresh_ability,
  b.acl_status,
  b.user_supplied_mv,
  s.start_date,
  s.repeat_interval,
  s.run_count as refresh_count,
  s.comments
from sys.aclmv$_base_view b, dba_scheduler_jobs s
  where b.schema_name = s.owner(+)
  and b.job_name = s.job_name(+)
/

