create view KU$_NTPART_VIEW as
  select
                nt.obj#,
                dbms_metadata.get_partn(1,ntp.bo#,ntp.part#),
                nt.intcol#, nt.ntab#,
                (select value(o) from ku$_schemaobj_view o
                 where o.obj_num = ntp.obj#),
                (select value(c) from ku$_simple_col_view c
                 where c.obj_num = nt.obj#
                 and   c.intcol_num = nt.intcol#),
                (select t.property from tab$ t where t.obj# = nt.ntab#),
                (select ct.flags from coltype$ ct
                        where ct.obj# = nt.obj#
                        and   ct.intcol# = nt.intcol#),
                (select value(hntp) from ku$_hntp_view hntp
                 where hntp.obj_num = ntp.obj#)
            from ntab$ nt,
               tabpart$ ntp
            where ntp.bo#=nt.ntab#
/

