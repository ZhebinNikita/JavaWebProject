create view KU$_SP2T_CONSTRAINT1_VIEW as
  select * from  ku$_sp2t_con1a_view
  UNION ALL
    select * from  ku$_p2t_con1b_view
/

