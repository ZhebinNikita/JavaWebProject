create view GV_$LOGSTDBY_PROCESS as
  select "INST_ID","SID","SERIAL#","LOGSTDBY_ID","SPID","TYPE","STATUS_CODE","STATUS","HIGH_SCN","CON_ID" from gv$logstdby_process
/

