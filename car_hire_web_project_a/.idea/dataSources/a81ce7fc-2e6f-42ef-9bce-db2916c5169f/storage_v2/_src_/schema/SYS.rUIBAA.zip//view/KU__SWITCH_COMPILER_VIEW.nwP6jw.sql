create view KU$_SWITCH_COMPILER_VIEW as
  select /*+ no_merge */
         b.obj#, to_char(dbms_metadata.get_plsql_optimize_level(b.value)),
         c.value, d.value, e.value, f.value, g.value
         FROM    sys.settings$ b, sys.settings$ c,  sys.settings$ d,
                 sys.settings$ e, sys.settings$ f,  sys.settings$ g,
                 sys.ku$_schemaobj_view o
         WHERE   o.obj_num  = b.obj# AND
                b.obj#  = c.obj# AND
                c.obj#  = d.obj# AND
                d.obj#  = e.obj# AND
                e.obj#  = f.obj# AND
                f.obj#  = g.obj# AND
                b.param = 'plsql_optimize_level'         AND
                c.param = 'plsql_code_type'              AND
                d.param = 'plsql_debug'                  AND
                e.param = 'plsql_ccflags'                AND
                f.param = 'plscope_settings'             AND
                g.param = 'nls_length_semantics'         AND
                (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/

