create view KU$_CONSTRAINT1_VIEW as
  select c.owner#, c.name, c.con#, cd.obj#,
          nvl((select bitand(t.property, 4294967295)
               from tab$ t where t.obj# = cd.obj#),0),
          nvl((select trunc(t.property / power(2, 32))
               from tab$ t where t.obj# = cd.obj#),0),
          cd.cols, cd.type#,
          nvl(cd.enabled,0),
          cd.condlength,
          sys.dbms_metadata_util.long2clob(cd.condlength,
                                        'SYS.CDEF$',
                                        'CONDITION',
                                        cd.rowid),
          case when cd.type#=1 then
            (select sys.dbms_metadata.parse_condition(u.name,o.name,
                                                      cd.condlength,cd.rowid)
             from obj$ o, user$ u
             where o.obj#=cd.obj# and o.owner#=u.user#)
          else null end,
          cd.intcols, to_char(cd.mtime,'YYYY/MM/DD HH24:MI:SS'), nvl(cd.defer,0),
          nvl((select cc.oid_or_setid
               from ku$_constraint_col_view cc
                 where cd.type#=3
                 and cd.intcols=1
                 and cc.con_num=cd.con#),0),
          cast( multiset(select * from ku$_constraint_col_view col
                        where col.con_num = c.con#
                        order by col.pos_num
                        ) as ku$_constraint_col_list_t
                ),
          ( select value(i) from ku$_all_index_view i
                where i.obj_num=cd.enabled )
--              where i.schema_obj.owner_num=c.owner#
--                and i.schema_obj.name=c.name )
   from  con$ c, cdef$ cd
   where c.con# = cd.con#
     and cd.type# in (1,2,3,12,14,15,16,17)
                               -- table check (condition-no keys) (1),
                               -- primary key (2),
                               -- unique key (3),
                               -- supplemental log groups (w/ keys) (12),
                               -- supplemental log data (no keys) (14,15,16,17)
/

