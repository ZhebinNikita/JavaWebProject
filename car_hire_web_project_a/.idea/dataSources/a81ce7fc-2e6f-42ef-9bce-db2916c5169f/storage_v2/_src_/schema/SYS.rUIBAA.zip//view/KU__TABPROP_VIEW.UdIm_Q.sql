create view KU$_TABPROP_VIEW as
  select o.obj#, o.name, u.name, o.flags, t.property
 from obj$ o, user$ u, tab$ t
 where o.owner# = u.user#
 and   o.obj#   = t.obj#
 and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' )     OR
                EXISTS ( SELECT 1 FROM all_objects ao
                        WHERE o.obj# = ao.object_id))
/

