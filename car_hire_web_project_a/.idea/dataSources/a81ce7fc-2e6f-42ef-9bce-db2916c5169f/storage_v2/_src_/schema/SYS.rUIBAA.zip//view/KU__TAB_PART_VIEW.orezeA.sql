create view KU$_TAB_PART_VIEW as
  select tp.obj#, value(o),
         ts.name, ts.blocksize,
         (select value(s) from ku$_storage_view s
          where tp.file#  = s.file_num
          and   tp.block# = s.block_num
          and   tp.ts#    = s.ts_num),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = tp.obj#),
         tp.dataobj#, tp.bo#,
         dbms_metadata.get_partn(1,tp.bo#,tp.part#),
         tp.hiboundlen,
         sys.dbms_metadata_util.long2varchar(tp.hiboundlen,
                                        'SYS.TABPART$',
                                        'HIBOUNDVAL',
                                        tp.rowid),
         cast(multiset(select * from ku$_lobfrag_view lf
                        where lf.part_obj_num=tp.obj#
                        order by lf.intcol_num
                      ) as ku$_lobfrag_list_t
             ),
         (select value(ntp) from ku$_ntpart_parent_view ntp
          where ntp.obj_num = tp.bo# and
                ntp.part_num=(dbms_metadata.get_partn(1,tp.bo#,tp.part#))),
         cast( multiset(select * from ku$_ilm_policy_view p
                        where p.obj_num = tp.obj#
                        order by p.policy_num
                        ) as ku$_ilm_policy_list_t
              ),
         tp.pctfree$, tp.pctused$, tp.initrans,
         tp.maxtrans, tp.flags,
         to_char(tp.analyzetime,'YYYY/MM/DD HH24:MI:SS'),
         tp.samplesize, tp.rowcnt,
         tp.blkcnt, tp.empcnt, tp.avgspc, tp.chncnt, tp.avgrln, tp.spare1,
         tp.spare2, tp.spare3,
         bhiboundval,
         tp.part#,   -- <<< be carefull! this is 'physical' partition number
         (select value(etv) from ku$_exttab_view etv
                        where etv.obj_num = tp.obj#),
         (select svcname  from imsvc$ svc
                 where svc.obj# = tp.obj# and svc.subpart# is null),
         (select svcflags from imsvc$ svc
                 where svc.obj# = tp.obj# and svc.subpart# is null)
  from ku$_schemaobj_view o, tabpart$ tp, ts$ ts
  where tp.obj# = o.obj_num
        AND tp.ts# = ts.ts#
/

