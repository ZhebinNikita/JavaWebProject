create view KU$_ACPTABLE_VIEW as
  select '2','8',
         t.obj#,
         value(o),
         -- if this is a secondary table, get base obj and ancestor obj
         decode(bitand(o.flags, 16), 16,
           (select value(oo) from ku$_schemaobj_view oo, secobj$ s
              where o.obj_num=s.secobj#
                and oo.obj_num=s.obj#
                and rownum < 2),
           null),
         decode(bitand(o.flags, 16), 16,
           (select value(oo) from ku$_schemaobj_view oo, ind$ i, secobj$ s
              where o.obj_num=s.secobj#
                and i.obj#=s.obj#
                and oo.obj_num=i.bo#
                and rownum < 2),
           null),
        /* -- */
         t.bobj#, t.tab#, t.cols,
         t.clucols,
         (select value(cl) from ku$_tabcluster_view cl
          where cl.obj_num = t.obj#),
        /* fba  - flashback archive, table clustering, ILM */
         (select value(fb) from ku$_fba_view fb where fb.obj_num = t.obj#),
         cast( multiset(select * from ku$_fba_period_view fb
                        where fb.obj_num = t.obj#
                        order by fb.periodname
                        ) as ku$_fba_period_list_t
             ),
         (select value(cz) from ku$_clst_view cz where cz.obj_num = t.obj#),
         cast( multiset(select * from ku$_ilm_policy_view p
                        where p.obj_num = t.obj#
                        order by p.policy_num
                        ) as ku$_ilm_policy_list_t
              ),
         t.flags,
         replace(t.audit$,chr(0),'-'), t.rowcnt, t.blkcnt, t.empcnt,
         t.avgspc, t.chncnt, t.avgrln, t.avgspc_flb, t.flbcnt,
         to_char(t.analyzetime,'YYYY/MM/DD HH24:MI:SS'),
         t.samplesize, t.degree, t.instances, t.intcols, t.kernelcols,
         (select sys.dbms_metadata_util.has_tstz_cols(t.obj#) from dual),
         t.trigflag,
         t.spare1, t.spare2, t.spare3, t.spare4, t.spare5,
         to_char(t.spare6,'YYYY/MM/DD HH24:MI:SS'),  t.spare7,t.spare8,t.spare9,t.spare10,
         decode(bitand(t.trigflag, 65536), 65536,
           (select e.encalg from sys.enc$ e where e.obj#=t.obj#),
           null),
         decode(bitand(t.trigflag, 65536), 65536,
           (select e.intalg from sys.enc$ e where e.obj#=t.obj#),
           null),
         cast( multiset(select * from ku$_im_colsel_view imc
                        where imc.obj_num = t.obj#
                       ) as ku$_im_colsel_list_t
             ),
         cast( multiset(select * from ku$_constraint0_view con
                        where con.obj_num = t.obj#
                        and con.contype not in (7,11)
                       ) as ku$_constraint0_list_t
             ),
         cast( multiset(select * from ku$_constraint2_view con
                        where con.obj_num = t.obj#
                       ) as ku$_constraint2_list_t
             ),
         (select value(etv) from ku$_exttab_view etv
                        where etv.obj_num = o.obj_num),
         (select value(otv) from ku$_cube_tab_view otv
                        where otv.obj_num = o.obj_num),
         (select svcname  from imsvc$ where obj# = t.obj# and subpart# is null),
         (select svcflags from imsvc$ where obj# = t.obj# and subpart# is null),
      /* storage and deferred storage (at most one will be found), tablespace name/blocksize */
         bitand(t.property, (power(2, 32)-1)),
         bitand(trunc(t.property / power(2, 32)), (power(2, 32)-1)),
         trunc(t.property / power(2, 64)),
         (select value(s) from ku$_storage_view s
          where t.file# = s.file_num
          and t.block#  = s.block_num
          and t.ts#     = s.ts_num),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = t.obj#),
         ts.name, ts.blocksize,
         t.dataobj#,
         t.pctfree$, t.pctused$, t.initrans, t.maxtrans,
         cast( multiset(select * from ku$_constraint1_view con
                        where con.obj_num = t.obj#
                       ) as ku$_constraint1_list_t
             ),
         cast( multiset(select * from ku$_pcolumn_view c
                        where c.obj_num = t.obj#
                        order by c.col_num, c.intcol_num
                        ) as ku$_tab_column_list_t
              ),         (select value(nt) from ku$_nt_parent_view nt
          where nt.obj_num = t.obj#),
         cast( multiset(select * from ku$_pkref_constraint_view con
                        where con.obj_num = t.obj#
                       ) as ku$_pkref_constraint_list_t
             ),
        /* xmltype metadata - only with non-primitive columns */
         decode((select 1 from dual where
                 (exists (select q.obj# from sys.opqtype$ q
                          where q.obj#=t.obj#
                          and q.type=1                        /* xmltype col */
                          and bitand(q.flags,2+64)!=0))),       /* CSX or SB */
                1,'Y','N'),
         case when (exists (select q.obj# from sys.opqtype$ q
                          where q.obj#=t.obj#
                          and q.type=1))                      /* xmltype col */
              then dbms_metadata_util.get_xmlcolset(o.obj_num)
              else NULL end,
         case when (exists (select q.obj# from sys.opqtype$ q
                          where q.obj#=t.obj#
                          and q.type=1))                      /* xmltype col */
              then dbms_metadata_util.get_xmlhierarchy(o.owner_name,o.name)
              else NULL end,
         (select value(po) from ku$_schemaobj_view po
           where
            po.obj_num=sys.dbms_metadata_util.ref_par_parent(t.obj#)),
         sys.dbms_metadata_util.ref_par_level(t.obj#),
         cast(multiset(select value(og) from  ku$_objgrant_view og, ku$_schemaobj_view po
                 where og.base_obj.obj_num = sys.dbms_metadata_util.ref_par_parent(t.obj#) and
                       po.obj_num = og.base_obj.obj_num and
                       og.privname = 'REFERENCES' and
                       og.base_obj.name = po.name
                 order by og.wgo desc)
                 as ku$_objgrant_list_t),null,null,null,null,null,
         (select value(po) from ku$_tab_partobj_view po
          where t.obj# = po.obj_num)
  from ku$_schemaobj_view o, tab$ t, ts$ ts
  where t.obj# = o.obj_num
        AND t.ts# = ts.ts#
        AND bitand(t.property, 32+64+128+256+512) = 32
                                                /* partitioned (32)       */
                                                /* but not IOT            */
        /* mutually exclusive with ku$_phtable and ku$_pfhtable */
        AND exists( select * from partobj$ po
                    where po.obj# = t.obj# and po.parttype = 5)
        AND     (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

