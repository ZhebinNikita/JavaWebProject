create view KU$_LOB_VIEW as
  select l.obj#, l.col#, l.intcol#,
        (select value(o) from ku$_schemaobj_view o
         where o.obj_num = l.lobj#),
        (select value(s) from ku$_storage_view s
         where s.file_num  = l.file#
         and   s.block_num = l.block#
         and   s.ts_num    = l.ts#),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = l.lobj#),
        (select ts.name from ts$ ts where l.ts# = ts.ts#),
        (select ts.blocksize from ts$ ts where l.ts# = ts.ts#),
        l.ind#,
        (select value(i) from ku$_lobindex_view i where i.obj_num=l.ind#),
        l.chunk, l.pctversion$, l.flags, l.property,
        l.retention, l.freepools, l.spare1, l.spare2, l.spare3,
  /* attributes only for lobfarg (partitioned) */
        null, null, null, null
  from lob$ l
/

