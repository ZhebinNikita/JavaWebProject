create view KU$_PARTOBJ_VIEW as
  select po.obj#, po.parttype, po.partcnt,
         po.partkeycols,
         po.flags,
         -- hoist the next 2 queries up here because po.defts# may be null
         -- and this avoids an outer join which is slooooow
         (select ts.name from ts$ ts where po.defts# = ts.ts#),
         (select ts.blocksize from ts$ ts where po.defts# = ts.ts#),
         po.defpctfree, po.defpctused, po.defpctthres,
         po.definitrans, po.defmaxtrans, po.deftiniexts, po.defextsize,
         po.defminexts, po.defmaxexts, po.defextpct, po.deflists,
         po.defgroups, po.deflogging, po.spare1,
         -- Convert 'spare2' to a value that the pre-11.2 xsl stylesheet
         -- can process: if archive compressed and version < 11.2,
         -- turn off compression.  The block format for archive compression
         -- is not supported pre-11.2, so the compression bits must be
         -- set to NOCOMPRESS.
         -- also, exclude inmemory flags from exported 'spare2', as the flags
         -- value would excede the range xsl div/mod can handle. IMC flags
         -- are bytes 5 and above.
         case when (bitand(floor(po.spare2/power(2, 32)),8+16+32+64)=0) or
                   (dbms_metadata.get_version >= '11.02.00.00.00')
                then bitand(po.spare2, power(2, 40)-1)
              else bitand(po.spare2, power(2, 32)-1) + 2*power(2, 32)
         end,
         trunc(po.spare2 / power(2, 40)),
         po.spare3,
         po.definclcol, po.parameters,
         po.interval_str, po.interval_bival,
         -- Get list of tablespaces for STORE IN of interval and autolist part.
         case when (po.interval_str is not null) or
                   (po.parttype = 4 and bitand(po.flags,64) > 0) then
          cast( multiset( select * from ku$_insert_ts_view it
                          where it.base_obj_num=po.obj#
                          order by it.base_obj_num,it.position_num
                        ) as ku$_insert_ts_list_t
              )
         else null end,
         po.defmaxsize,
         po.subptn_interval_str, po.subptn_interval_bival,
         (select svcname  from imsvc$ svc
                 where svc.obj# = po.obj# and svc.subpart# is null),
         (select svcflags from imsvc$ svc
                 where svc.obj# = po.obj# and svc.subpart# is null)
  from partobj$ po
/

