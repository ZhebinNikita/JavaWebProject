create view CDB_CUBE_MEAS_MAPPINGS as
  SELECT k."OWNER",k."CUBE_NAME",k."CUBE_MAP_NAME",k."MAP_NAME",k."MAP_ID",k."MEASURE_NAME",k."MEASURE_EXPRESSION",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_CUBE_MEAS_MAPPINGS") k
/

comment on table CDB_CUBE_MEAS_MAPPINGS
is 'OLAP Cube Measure Mappings in the database in all containers'
/

