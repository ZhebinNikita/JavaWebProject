create view KU$_CLSTJOIN_VIEW as
  select j.clstobj#, j.tab1obj#, j.int1col#, j.tab2obj#, j.int2col#,
            (select value(o) from sys.ku$_schemaobj_view o
             where o.obj_num = j.tab1obj#),
            (select value(o) from sys.ku$_schemaobj_view o
             where o.obj_num = j.tab2obj#),
            (select value(c) from sys.ku$_simple_col_view c
             where c.obj_num = j.tab1obj# and c.intcol_num = j.int1col#),
            (select value(c) from sys.ku$_simple_col_view c
             where c.obj_num = j.tab2obj# and c.intcol_num = j.int2col#)
  from sys.clstjoin$ j
  order by j.tab1obj#, j.int1col#
/

