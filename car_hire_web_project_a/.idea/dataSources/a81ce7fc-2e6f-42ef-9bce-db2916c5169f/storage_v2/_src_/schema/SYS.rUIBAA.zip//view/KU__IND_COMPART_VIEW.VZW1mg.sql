create view KU$_IND_COMPART_VIEW as
  select icp.obj#, value(o), icp.dataobj#, icp.bo#,
         icp.part#,
         icp.hiboundlen,
         sys.dbms_metadata_util.long2varchar(icp.hiboundlen,
                                    'SYS.INDCOMPART$',
                                    'HIBOUNDVAL',
                                    icp.rowid),
         icp.subpartcnt,
         cast(multiset(select * from ku$_ind_subpart_view isp
                       where isp.pobj_num = icp.obj#
                        order by isp.subpart_num
                      ) as ku$_ind_part_list_t
             ),
          icp.flags,
          -- hoist the next 2 queries up here because icp.defts# may be null
          -- and this avoids an outer join which is slooooow
          (select ts.name from ts$ ts where icp.defts# = ts.ts#),
          (select ts.blocksize from ts$ ts where icp.defts# = ts.ts#),
          icp.defpctfree, icp.definitrans,
          icp.defmaxtrans, icp.definiexts, icp.defextsize, icp.defminexts,
          icp.defmaxexts, icp.defextpct, icp.deflists, icp.defgroups,
          icp.deflogging, icp.defbufpool, to_char(icp.analyzetime,'YYYY/MM/DD HH24:MI:SS'), icp.samplesize,
          icp.rowcnt, icp.blevel, icp.leafcnt, icp.distkey, icp.lblkkey,
          icp.dblkkey, icp.clufac, icp.spare1, icp.spare2, icp.spare3,
          icp.defmaxsize
  from ku$_schemaobj_view o, indcompart$ icp
  where icp.obj# = o.obj_num
/

