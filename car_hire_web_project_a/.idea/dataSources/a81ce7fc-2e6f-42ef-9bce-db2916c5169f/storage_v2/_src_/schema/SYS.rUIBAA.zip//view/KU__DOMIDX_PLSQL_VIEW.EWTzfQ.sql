create view KU$_DOMIDX_PLSQL_VIEW as
  select i.obj#,
        sys.dbms_metadata.get_domidx_metadata(o.name, u.name,
                o2.name, u2.name,
                case when i.ts#!=0 then i.ts#
                     when bitand((select t.property from tab$ t
                                  where t.obj#=i.bo#),32) = 0
                      then (select t.ts# from tab$ t where t.obj#=i.bo#)
                     else dbms_metadata_util.table_tsnum(i.bo#)
                end,
                it.interface_version#, 0)
   from obj$ o, obj$ o2, ind$ i, user$ u, user$ u2, indtypes$ it
   where i.type# = 9
         AND o.obj# = i.obj#
         AND o.owner# = u.user#
         AND i.indmethod# = it.obj#
         AND o2.obj# = it.implobj#
         AND o2.owner# = u2.user#
         AND bitand(i.property, 2) != 2         /* non-partitioned */
   UNION ALL
  select i.obj#,
        sys.dbms_metadata.get_domidx_metadata(o.name, u.name,
              o2.name, u2.name,
              case when i.ts#!=0 then i.ts#
                   when bitand((select t.property from tab$ t
                                where t.obj#=i.bo#),32) = 0
                    then (select t.ts# from tab$ t where t.obj#=i.bo#)
                   else dbms_metadata_util.table_tsnum(i.bo#)
              end,
              it.interface_version#,
              DECODE(BITAND (i.property, 512), 512, 64,0)+   /*0x200=iot di*/
              DECODE(BITAND(po.flags, 1), 1, 1, 0) +          /* 1 = local */
              DECODE(po.parttype, 1, 2, 2, 4, 0)    /* 1 = range, 2 = hash */
              )
   from obj$ o, obj$ o2, ind$ i, user$ u, user$ u2, partobj$ po,
        indtypes$ it
   where i.type# = 9
         AND o.obj# = i.obj#
         AND o.owner# = u.user#
         AND i.indmethod# = it.obj#
         AND o2.obj# = it.implobj#
         AND o2.owner# = u2.user#
         AND bitand(po.flags, 8) = 8            /* domain index */
         AND po.obj# = i.obj#
         AND bitand(i.property, 2) = 2          /* partitioned */

