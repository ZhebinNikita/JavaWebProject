create view V_$LOGSTDBY_STATE as
  select "PRIMARY_DBID","PRIMARY_CON_DBID","SESSION_ID","REALTIME_APPLY","STATE","CON_ID" from v$logstdby_state
/

