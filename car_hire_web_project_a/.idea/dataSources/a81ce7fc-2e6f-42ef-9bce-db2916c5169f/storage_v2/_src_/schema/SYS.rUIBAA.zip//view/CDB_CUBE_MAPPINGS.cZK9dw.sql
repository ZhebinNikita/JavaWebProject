create view CDB_CUBE_MAPPINGS as
  SELECT k."OWNER",k."CUBE_NAME",k."MAP_NAME",k."MAP_ID",k."QUERY",k."WHERE_CLAUSE",k."FROM_CLAUSE",k."IS_SOLVED",k."AGGREGATION_METHOD",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_CUBE_MAPPINGS") k
/

comment on table CDB_CUBE_MAPPINGS
is 'OLAP Cube Mappings in the database in all containers'
/

