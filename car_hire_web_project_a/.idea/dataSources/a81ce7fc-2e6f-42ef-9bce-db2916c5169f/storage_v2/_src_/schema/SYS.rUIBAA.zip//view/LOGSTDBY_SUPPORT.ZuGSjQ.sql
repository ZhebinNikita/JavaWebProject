create view LOGSTDBY_SUPPORT as
  with redo_compat as
         (select nvl((select min(s.redo_compat)
                      from system.logstdby$parameters p,
                           system.logmnr_session$ s,
                           sys.v$database d
                      where p.name in ('LMNR_SID', 'FUTURE_SESSION') and
                            p.value = s.session# and
                            d.database_role = 'LOGICAL STANDBY'),
                     (select p.value
                      from sys.v$parameter p
                      where p.name = 'compatible')) compat
          from dual)
  select owner, name, type#, obj#, gensby full_sby, current_sby,
   (case when decode(gensby, 1, 1, 0) = 1
       and not exists
      (select 1 from system.logstdby$skip s
       where statement_opt = 'DML'
       and error is null
       and 1 = case use_like
         when 0 then
           case when l.owner = s.schema and l.name = s.name then
             1 else 0
           end
         when 1 then
           case when l.owner like s.schema and l.name like s.name then
             1 else 0
           end
         when 2 then
           case when l.owner like s.schema escape esc and
                     l.name like s.name escape esc then
             1 else 0
           end
         else 0
       end)
    then 1 else 0 end) generated_sby
  from
    (select owner, name, type#, obj#, current_sby,
            case gensby when 2 then 1 else gensby end gensby
       from logstdby_support_seq
     union all
    select * from (
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_10_1 u, redo_compat c
    where c.compat like '10.0%' or c.compat like '10.1%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_10_2 u, redo_compat c
    where c.compat like '10.2%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_11_1 u, redo_compat c
    where c.compat like '11.0%' or c.compat like '11.1%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_11_2 u, redo_compat c
    where c.compat like '11.2%' and c.compat not like '11.2.0.3%'
                                and c.compat not like '11.2.0.4%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_11_2b u, redo_compat c
    where c.compat like '11.2.0.3%' or c.compat like '11.2.0.4%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_12_1 u, redo_compat c
    where c.compat like '12.0%' or c.compat like '12.1%'
    UNION ALL
    select u.owner, u.name, u.type#, u.obj#, u.current_sby, u.gensby
    from logstdby_support_tab_12_2 u, redo_compat c
    where c.compat like '12.2%')
) l
/

