create view CDB_LOGSTDBY_EDS_TABLES as
  SELECT k."OWNER",k."TABLE_NAME",k."CTIME",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("SYS"."DBA_LOGSTDBY_EDS_TABLES") k
/

comment on table CDB_LOGSTDBY_EDS_TABLES
is 'List of all tables that have EDS-based replication for Logical Standby in all containers'
/

