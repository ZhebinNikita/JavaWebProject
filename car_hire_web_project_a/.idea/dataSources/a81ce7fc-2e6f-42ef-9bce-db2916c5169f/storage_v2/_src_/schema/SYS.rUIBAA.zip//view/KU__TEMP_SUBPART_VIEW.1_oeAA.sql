create view KU$_TEMP_SUBPART_VIEW as
  SELECT
            tsp.obj#,
            tsp.ts#,
            tsp.pobj#,
            dbms_metadata.get_partn(3,tsp.pobj#,tsp.subpart#)-1,
            tsp.bhiboundval
        FROM tabsubpart$ tsp
/

