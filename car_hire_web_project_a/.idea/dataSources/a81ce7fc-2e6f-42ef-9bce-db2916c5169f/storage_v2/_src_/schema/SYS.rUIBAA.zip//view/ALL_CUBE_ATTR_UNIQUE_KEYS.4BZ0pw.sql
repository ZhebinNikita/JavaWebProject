create view ALL_CUBE_ATTR_UNIQUE_KEYS as
  SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  a.attribute_name ATTRIBUTE_NAME,
  dl.level_name UNIQUE_KEY_LEVEL_NAME
FROM
  olap_attributes$ a,
  obj$ o,
  user$ u,
  olap_dim_levels$ dl,
  olap_attribute_visibility$ av
WHERE
  o.obj#=a.dim_obj#
  AND o.owner#=u.user#
  AND a.attribute_id = av.attribute_id
  AND av.is_unique_key = 1
  AND av.owning_dim_id = dl.level_id
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ora_check_SYS_privilege (o.owner#, o.type#) = 1
            )
/

comment on table ALL_CUBE_ATTR_UNIQUE_KEYS
is 'OLAP Unique Key Attributes in the database that are accessible to the current user'
/

