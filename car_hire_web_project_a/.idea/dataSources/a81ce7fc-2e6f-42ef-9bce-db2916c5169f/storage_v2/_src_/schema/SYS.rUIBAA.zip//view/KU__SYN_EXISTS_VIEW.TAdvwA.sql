create view KU$_SYN_EXISTS_VIEW as
  select o.obj#,u.name
 from obj$ o, user$ u, syn$ s
 where o.owner#=u.user#
 and o.obj#=s.obj#
 and  (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner#,0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

