create view DBA_LOGSTDBY_HISTORY as
  select stream_sequence#, decode(status, 1, 'Past', 2, 'Immediate Past', 3,
         'Current', 4, 'Immediate Future', 5, 'Future', 6, 'Canceled', 7,
         'Invalid') status, decode(source, 1, 'Rfs', 2, 'User', 3, 'Synch', 4,
         'Redo') source, dbid, first_change#, last_change#, first_time,
         last_time, dgname, spare1 merge_change#, spare2 processed_change#
  from system.logstdby$history
/

comment on table DBA_LOGSTDBY_HISTORY
is 'Information on processed, active, and pending log streams'
/

