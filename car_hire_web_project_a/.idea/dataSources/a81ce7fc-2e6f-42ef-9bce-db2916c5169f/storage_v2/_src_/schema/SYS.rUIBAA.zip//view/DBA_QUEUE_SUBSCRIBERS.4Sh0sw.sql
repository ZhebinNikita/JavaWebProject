create view DBA_QUEUE_SUBSCRIBERS as
  select su.owner OWNER, su.queue_name QUEUE_NAME, su.queue_table QUEUE_TABLE,
       su.consumer_name CONSUMER_NAME, su.address ADDRESS,
       su.protocol PROTOCOL, su.transformation TRANSFORMATION,
       r.rule_condition RULE,
       decode(bitand(su.sub_type, 192), 64, 'PERSISTENT',
                                       128, 'BUFFERED',
                                       192, 'PERSISTENT_OR_BUFFERED',
                                       'NONE') DELIVERY_MODE,
       decode(bitand(su.sub_type, 32960), 32960, 'YES',
                                       'NO') IF_NONDURABLE_SUBSCRIBER,
       decode(bitand(su.sub_type, 512), 512, 'TRUE', 'FALSE') QUEUE_TO_QUEUE,
       su.subscriber_id SUBSCRIBER_ID,
       su.pos_bitmap POS_BITMAP
FROM   ( select t.schema OWNER, q.name QUEUE_NAME, t.name QUEUE_TABLE,
                s.name CONSUMER_NAME, s.address ADDRESS, s.protocol PROTOCOL,
                s.trans_name TRANSFORMATION, s.rule_name RULE_NAME,
                s.sub_type SUB_TYPE, s.subscriber_id SUBSCRIBER_ID,
                s.pos_bitmap POS_BITMAP
         FROM   system.aq$_queues q, system.aq$_queue_tables t,
         TABLE(aq$_get_subscribers(t.schema, q.name, t.name,
                                   NULL, q.eventid, t.flags)) s
         where q.table_objno = t.objno
         and   bitand(t.flags, 1) = 1 and q.usage!=1
         ) su, dba_rules r
where  su.rule_name = r.rule_name(+)
and    su.owner = r.rule_owner(+)
/

comment on table DBA_QUEUE_SUBSCRIBERS
is 'queue subscribers in the database'
/

