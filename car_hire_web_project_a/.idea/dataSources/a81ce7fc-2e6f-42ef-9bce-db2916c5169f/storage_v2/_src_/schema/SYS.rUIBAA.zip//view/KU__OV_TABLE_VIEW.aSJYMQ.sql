create view KU$_OV_TABLE_VIEW as
  select t.obj#, t.dataobj#, t.bobj#,
         (select value(s) from ku$_storage_view s
          where t.file# = s.file_num
          and t.block#  = s.block_num
          and t.ts#     = s.ts_num),
         (select value(s) from ku$_deferred_stg_view s
          where s.obj_num = t.obj#),
         ts.name, ts.blocksize,
         t.pctfree$, t.pctused$, t.initrans, t.maxtrans, t.flags
  from  tab$ t, ts$ ts
  where bitand(t.property,512) = 512
        and t.ts# = ts.ts#
/

