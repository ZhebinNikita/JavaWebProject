create view PTC_APPLY_PROGRESS as
  select xidusn, xidslt, xidsqn, commit_scn, commit_time,
         spare1, spare2, spare3
  from system.logstdby$apply_progress
/

