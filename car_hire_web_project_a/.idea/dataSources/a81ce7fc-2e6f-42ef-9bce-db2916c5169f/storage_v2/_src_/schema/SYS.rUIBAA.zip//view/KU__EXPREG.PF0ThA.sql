create view KU$_EXPREG as
  select "PACKAGE","SCHEMA","TAG","CLASS","LEVEL#","FLAGS","TGT_SCHEMA","TGT_OBJECT","TGT_TYPE","CMNT","BEGINNING_TGT_VERSION","ENDING_TGT_VERSION","ALT_NAME","ALT_SCHEMA"
  from impcalloutreg$ i
  where i.class=3
    AND (bitand(i.flags,16)=0 or dbms_metadata.is_xdb_trans=0)
    AND sys.dbms_metadata.is_active_registration(
                i.beginning_tgt_version, i.ending_tgt_version)=1
/

