create view WM$WORKSPACE_SAVEPOINTS_TABLE as
  select wt.workspace,
       wst.savepoint,
       wst.version,
       (select count(*)+1
        from wmsys.wm$workspace_savepoints_table$ wst2
        where wst2.workspace# = wst.workspace# and
              (wst2.version < wst.version or (wst2.version = wst.version and wst2.createtime < wst.createtime))) position,
       decode(bitand(wst.wm$flag, 1), 0, 0, 1, 1) is_implicit,
       wst.owner,
       wst.createtime,
       wst.description
from wmsys.wm$workspace_savepoints_table$ wst, wmsys.wm$workspaces_table$i wt
where wst.workspace# = wt.workspace_lock_id
/

