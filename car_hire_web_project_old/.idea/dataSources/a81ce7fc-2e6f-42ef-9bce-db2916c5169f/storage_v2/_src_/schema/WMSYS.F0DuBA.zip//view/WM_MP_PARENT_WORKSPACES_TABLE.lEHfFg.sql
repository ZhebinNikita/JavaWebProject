create view WM$MP_PARENT_WORKSPACES_TABLE as
  select wt1.workspace,
       wt2.workspace parent_workspace,
       mpwt.parent_version,
       mpwt.creator,
       mpwt.createtime,
       mpwt.workspace# workspace_lock_id,
       mpwt.parent_workspace#,
       decode(bitand(mpwt.wm$flag, 1), 0, 0, 1, 1) isrefreshed,
       decode(bitand(mpwt.wm$flag, 2), 0, 'DP', 2, 'MP') parent_flag
from wmsys.wm$mp_parent_workspaces_table$ mpwt, wmsys.wm$workspaces_table$i wt1, wmsys.wm$workspaces_table$i wt2
where mpwt.workspace# = wt1.workspace_lock_id and
      mpwt.parent_workspace# = wt2.workspace_lock_id
/

