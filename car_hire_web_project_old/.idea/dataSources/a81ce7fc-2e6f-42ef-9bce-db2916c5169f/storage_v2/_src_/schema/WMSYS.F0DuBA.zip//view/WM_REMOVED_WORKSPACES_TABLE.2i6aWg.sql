create view WM$REMOVED_WORKSPACES_TABLE as
  select wt1.owner,
       wt1.workspace workspace_name,
       wt1.workspace_lock_id workspace_id,
       wt1.parent_workspace parent_workspace_name,
       wt1.parent_workspace# parent_workspace_id,
       wt1.createtime,
       wt1.last_change retiretime,
       wt1.description,
       to_number(wt1.mp_root) mp_root_id,
       wt1.isrefreshed
from wmsys.wm$workspaces_table$d wt1
where wt1.freeze_mode = 'REMOVED' or
      (wt1.freeze_mode = 'DEFERRED_REMOVAL' and keep=1)
/

