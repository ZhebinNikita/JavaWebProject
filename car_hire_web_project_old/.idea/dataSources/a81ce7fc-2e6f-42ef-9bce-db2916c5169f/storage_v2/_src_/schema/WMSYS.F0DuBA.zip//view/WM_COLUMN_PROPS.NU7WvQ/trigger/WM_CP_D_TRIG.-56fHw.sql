create trigger WM$CP_D_TRIG
  instead of delete
  on WM$COLUMN_PROPS
  for each row
  declare
  vtid integer := wmsys.ltUtil.getVtid(:old.owner, :old.table_name) ;
begin
  update wmsys.wm$versioned_tables$
  set wm$flag = wmsys.ltUtil.bitclear(wm$flag, 98304)
  where vtid# = vtid ;
end;
/

