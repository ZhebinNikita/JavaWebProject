create view WM$CURCONFLICT_NEXTVERS_VIEW as
  select nt.version, nt.next_vers, nt.split, cpv.vtid
from wmsys.wm$nextver_table$ nt, wmsys.wm$curConflict_parvers_view cpv
where nt.version = cpv.parent_vers
WITH READ ONLY
/

