create type       wm$ident_tab_type as table of varchar2(128)
/

