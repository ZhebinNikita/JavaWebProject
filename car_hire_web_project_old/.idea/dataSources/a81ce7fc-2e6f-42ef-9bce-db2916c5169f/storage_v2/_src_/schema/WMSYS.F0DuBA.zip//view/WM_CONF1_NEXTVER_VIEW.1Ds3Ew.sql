create view WM$CONF1_NEXTVER_VIEW as
  select next_vers
from wmsys.wm$nextver_table
where version in (select version from wmsys.wm$conf1_hierarchy_view)
WITH READ ONLY
/

