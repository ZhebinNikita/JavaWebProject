create trigger WM$MPWT_I_TRIG
  instead of insert
  on WM$MP_PARENT_WORKSPACES_TABLE
  for each row
  declare
  flag_v integer := 0;
  ws#1   integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
  ws#2   integer := wmsys.ltUtil.getWorkspaceLockId(:new.parent_workspace) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$mp_parent_workspaces_t$f(:new.isrefreshed, :new.parent_flag) ;

  insert into wmsys.wm$mp_parent_workspaces_table$(workspace#, parent_workspace#, parent_version, creator, createtime, wm$flag)
  values (ws#1, ws#2, :new.parent_version, :new.creator, :new.createtime, flag_v) ;
end;
/

