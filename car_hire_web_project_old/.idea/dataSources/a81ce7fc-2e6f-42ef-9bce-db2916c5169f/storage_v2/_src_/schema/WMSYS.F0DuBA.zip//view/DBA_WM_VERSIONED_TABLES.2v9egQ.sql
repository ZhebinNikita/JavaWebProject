create view DBA_WM_VERSIONED_TABLES as
  select /*+ LEADING(t) */ t.table_name, t.owner,
       disabling_ver state,
       t.hist history,
       decode(t.notification, 0, 'NO', 1, 'YES') notification,
       substr(notifyWorkspaces,2,length(notifyworkspaces)-2) notifyworkspaces,
       wmsys.ltadm.AreThereConflicts(t.owner, t.table_name, t.vtid) conflict,
       wmsys.ltadm.AreThereDiffs(t.owner, t.table_name, t.vtid) diff,
       decode(t.validtime, 0, 'NO', 1, 'YES') validtime
from wmsys.wm$versioned_tables t, dba_views u
where t.table_name = u.view_name and t.owner = u.owner
WITH READ ONLY
/

