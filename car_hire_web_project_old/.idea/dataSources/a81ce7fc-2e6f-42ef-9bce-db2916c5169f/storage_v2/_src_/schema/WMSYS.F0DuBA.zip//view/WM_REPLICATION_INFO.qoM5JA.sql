create view WM_REPLICATION_INFO as
  select cast(null as varchar2(128)) groupName, cast(null as varchar2(128)) writerSite
from dual
where 1 = 2
WITH READ ONLY
/

