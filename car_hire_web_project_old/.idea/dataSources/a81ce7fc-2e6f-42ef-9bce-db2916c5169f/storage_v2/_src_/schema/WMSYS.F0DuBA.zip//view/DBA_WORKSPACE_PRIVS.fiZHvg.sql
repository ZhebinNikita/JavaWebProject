create view DBA_WORKSPACE_PRIVS as
  select spt.grantee,
       spt.workspace,
       decode(spt.priv,'A',  'ACCESS_WORKSPACE',
                       'C',  'CREATE_WORKSPACE',
                       'D',  'REMOVE_WORKSPACE',
                       'F',  'FREEZE_WORKSPACE',
                       'G',  'GRANTPRIV_WORKSPACE',
                       'M',  'MERGE_WORKSPACE',
                       'R',  'ROLLBACK_WORKSPACE',
                       'AA', 'ACCESS_ANY_WORKSPACE',
                       'CA', 'CREATE_ANY_WORKSPACE',
                       'DA', 'REMOVE_ANY_WORKSPACE',
                       'FA', 'FREEZE_ANY_WORKSPACE',
                       'GA', 'GRANTPRIV_ANY_WORKSPACE',
                       'MA', 'MERGE_ANY_WORKSPACE',
                       'RA', 'ROLLBACK_ANY_WORKSPACE',
                       'W',  'WM_ADMIN',
                             'UNKNOWN_PRIV') privilege,
       spt.grantor,
       decode(spt.admin, 0, 'NO', 1, 'YES') grantable
from wmsys.wm$workspaces_table$i alt, wmsys.wm$workspace_priv_table spt
where alt.workspace = spt.workspace
WITH READ ONLY
/

