create view WM$MW_TABLE as
  select wt.workspace
from wmsys.wm$mw_table$ mt, wmsys.wm$workspaces_table$i wt
where mt.workspace# = wt.workspace_lock_id
/

