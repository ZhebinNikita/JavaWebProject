create view WM$VERSION_HIERARCHY_TABLE as
  select vht.version, vht.parent_version, wt.workspace, wt.wm_lockmode
from wmsys.wm$version_hierarchy_table$ vht, wmsys.wm$workspaces_table$i wt
where vht.workspace# = wt.workspace_lock_id
/

