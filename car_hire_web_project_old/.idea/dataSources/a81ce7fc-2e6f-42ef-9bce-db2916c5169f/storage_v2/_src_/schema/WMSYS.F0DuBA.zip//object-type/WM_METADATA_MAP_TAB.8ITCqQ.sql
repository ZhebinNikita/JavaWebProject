create type       wm$metadata_map_tab as table of wmsys.wm$metadata_map_type
/

