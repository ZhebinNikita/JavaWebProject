create trigger WM$MGWT_I_TRIG
  instead of insert
  on WM$MP_GRAPH_WORKSPACES_TABLE
  for each row
  declare
  flag_v integer := 0;
  ws#1   integer := wmsys.ltUtil.getWorkspaceLockId(:new.mp_leaf_workspace) ;
  ws#2   integer := wmsys.ltUtil.getWorkspaceLockId(:new.mp_graph_workspace) ;
begin
  flag_v := wmsys.owm_dml_pkg.wm$mp_graph_workspaces_table$f(:new.mp_graph_flag) ;

  insert into wmsys.wm$mp_graph_workspaces_table$(mp_leaf_workspace#, mp_graph_workspace#, anc_version, wm$flag)
  values (ws#1, ws#2, :new.anc_version, flag_v) ;
end;
/

