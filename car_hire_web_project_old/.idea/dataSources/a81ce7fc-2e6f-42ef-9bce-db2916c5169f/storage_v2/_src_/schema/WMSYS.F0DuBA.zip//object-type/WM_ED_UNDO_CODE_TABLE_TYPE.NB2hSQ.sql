create type       wm$ed_undo_code_table_type                                                                       
         as table of wmsys.wm$ed_undo_code_node_type
/

