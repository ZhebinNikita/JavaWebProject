create type       wm$exp_map_tab as table of wmsys.wm$exp_map_type
/

