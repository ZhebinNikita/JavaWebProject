create type       wm$oper_lockvalues_array_type as varray(50) of wmsys.wm$oper_lockvalues_type
/

