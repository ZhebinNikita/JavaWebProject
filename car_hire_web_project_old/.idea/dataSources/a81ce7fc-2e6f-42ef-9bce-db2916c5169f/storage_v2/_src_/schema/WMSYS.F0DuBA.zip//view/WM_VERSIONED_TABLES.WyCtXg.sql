create view WM$VERSIONED_TABLES as
  select vtid, table_name, owner, notification, notifyworkspaces, disabling_ver, ricweight, isfastlive, isworkflow,
       hist, pkey_cols, undo_code, bl_workspace, bl_version, bl_savepoint,
       bl_check_for_duplicates, bl_single_transaction, validtime, identity_type
from wmsys.wm$versioned_tables$h
where disabling_ver<>'HIDDEN'
/

