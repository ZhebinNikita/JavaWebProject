create view ALL_MP_GRAPH_WORKSPACES as
  select mpg.mp_leaf_workspace, mpg.mp_graph_workspace GRAPH_WORKSPACE,
       decode(mpg.mp_graph_flag,'R','ROOT_WORKSPACE','I','INTERMEDIATE_WORKSPACE','L','LEAF_WORKSPACE') GRAPH_FLAG
from wmsys.wm$mp_graph_workspaces_table mpg, wmsys.all_workspaces uw
where mpg.mp_leaf_workspace = uw.workspace
WITH READ ONLY
/

