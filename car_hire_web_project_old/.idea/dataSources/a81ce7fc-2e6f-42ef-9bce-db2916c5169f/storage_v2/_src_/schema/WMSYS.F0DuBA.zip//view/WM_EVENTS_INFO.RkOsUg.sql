create view WM$EVENTS_INFO as
  select ei.event_name, decode(bitand(ei.wm$flag, 1), 0, 'OFF', 1, 'ON') capture
from wmsys.wm$events_info$ ei
/

