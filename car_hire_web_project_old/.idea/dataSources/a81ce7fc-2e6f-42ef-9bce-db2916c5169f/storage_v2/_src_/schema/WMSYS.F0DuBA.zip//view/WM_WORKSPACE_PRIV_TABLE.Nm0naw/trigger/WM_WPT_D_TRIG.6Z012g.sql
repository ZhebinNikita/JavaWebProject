create trigger WM$WPT_D_TRIG
  instead of delete
  on WM$WORKSPACE_PRIV_TABLE
  for each row
  declare
  ws#     integer := wmsys.ltUtil.getWorkspaceLockId(:old.workspace) ;
  flag_v  integer := wmsys.owm_dml_pkg.wm$workspace_priv_table$f(:old.priv, null) ;
begin
  if (ws# is not null) then
    delete wmsys.wm$workspace_priv_table$ where grantee=:old.grantee and workspace#=ws# and bitand(wm$flag, 31) = flag_v ;
  else
    delete wmsys.wm$workspace_priv_table$ where grantee=:old.grantee and workspace# is null and bitand(wm$flag, 31) = flag_v ;
  end if ;
end;
/

