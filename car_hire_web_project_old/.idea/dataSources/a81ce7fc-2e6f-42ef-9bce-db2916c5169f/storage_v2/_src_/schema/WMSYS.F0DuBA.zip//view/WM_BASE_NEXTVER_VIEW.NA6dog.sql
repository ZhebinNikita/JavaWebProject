create view WM$BASE_NEXTVER_VIEW as
  select next_vers
from wmsys.wm$nextver_table$
where version in (select version from wmsys.wm$base_hierarchy_view)
WITH READ ONLY
/

