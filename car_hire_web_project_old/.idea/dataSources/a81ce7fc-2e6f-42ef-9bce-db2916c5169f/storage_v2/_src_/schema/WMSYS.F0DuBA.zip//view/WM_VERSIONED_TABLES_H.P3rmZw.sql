create view WM$VERSIONED_TABLES$H as
  select vt.vtid# vtid,
       vt.table_name,
       vt.owner,
       0 notification,
       null notifyworkspaces,
       decode(bitand(vt.wm$flag, 31), 0, 'UNDEFINED', 1, 'VERSIONED', 2, 'HIDDEN', 3, 'EV', 4, 'LWEV', 5, 'DV', 6, 'LWDV', 7, 'LW_DISABLED', 8, 'DDL',
                                      9, 'BDDL', 10, 'CDDL', 11, 'ODDL', 12, 'TDDL', 13, 'AVTDDL', 14, 'BL_F_BEGIN', 15, 'BL_P_BEGIN', 16, 'BL_P_END',
                                     17, 'BL_R_BEGIN', 18, 'ADD_VT', 19, 'SYNCVTV1', 20, 'SYNCVTV2', 21, 'RB_IND', 22, 'RN_CONS', 23, 'RN_IND',
                                     24, 'D_HIST_COLS', 25, 'U_HIST_COLS', 26, 'IDDL') disabling_ver,
       vt.ricweight,
       0 isfastlive,
       0 isworkflow,
       decode(bitand(vt.wm$flag, 224), 0, 'NONE', 32, 'VIEW_W_OVERWRITE', 64, 'VIEW_W_OVERWRITE_PERF',
                                      96, 'VIEW_WO_OVERWRITE', 128, 'VIEW_WO_OVERWRITE_PERF') hist,
       vt.pkey_cols,
       vt.undo_code,
       null bl_workspace,
       vt.bl_version,
       decode(bitand(vt.wm$flag, 1536), 0, null, 512, 'ROOT_VERSION', 1024, 'LATEST') bl_savepoint,
       decode(bitand(vt.wm$flag, 6144), 0, null, 2048, 'NO', 4096, 'YES') bl_check_for_duplicates,
       decode(bitand(vt.wm$flag, 24576), 0, null, 8192, 'NO', 16384, 'YES') bl_single_transaction,
       decode(bitand(vt.wm$flag, 256), 0, 0, 256, 1) validtime,
       decode(bitand(vt.wm$flag, 98304), 0, null, 32768, 'IA', 65536, 'IN', null) identity_type
from wmsys.wm$versioned_tables$ vt
/

