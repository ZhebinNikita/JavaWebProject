create view WM$VT_ERRORS_TABLE as
  select vt.owner,
       vt.table_name,
       vet.index_type,
       vet.index_field,
       decode(bitand(vet.wm$flag, 31), 0,  'EV STEP BEING EXECUTED',
                                       1,  'EV STEP EXECUTED WITH ERRORS',
                                       2,  'DV STEP BEING EXECUTED',
                                       3,  'DV STEP EXECUTED WITH ERRORS',
                                       4,  'CDDL STEP BEING EXECUTED',
                                       5,  'CDDL STEP EXECUTED WITH ERRORS',
                                       6,  'UNDO EV STEP BEING EXECUTED',
                                       7,  'UNDO EV STEP EXECUTED WITH ERRORS',
                                       8,  'STATEMENT BEING EXECUTED',
                                       9,  'STATEMENT EXECUTED WITH ERRORS',
                                       10, 'ADD VALID TIME STEP BEING EXECUTED',
                                       11, 'ADD VALID TIME STEP EXECUTED WITH ERRORS',
                                       12, 'ALTERVERSIONEDTABLE DDL STEP BEING EXECUTED',
                                       13, 'ALTERVERSIONEDTABLE DDL STEP EXECUTED WITH ERRORS',
                                       14, 'REBUILD INDEX STEP BEING EXECUTED',
                                       15, 'REBUILD INDEX STEP EXECUTED WITH ERRORS',
                                       16, 'RENAME CONSTRAINT STEP BEING EXECUTED',
                                       17, 'RENAME CONSTRAINT STEP EXECUTED WITH ERRORS',
                                       18, 'RENAME INDEX STEP BEING EXECUTED',
                                       19, 'RENAME INDEX STEP EXECUTED WITH ERRORS',
                                       20, 'SYNCRONIZE VT VIEWS STEP BEING EXECUTED',
                                       21, 'SYNCRONIZE VT VIEWS STEP EXECUTED WITH ERRORS') status,
       vet.error_msg
from wmsys.wm$vt_errors_table$ vet, wmsys.wm$versioned_tables$ vt
where vet.vtid# = vt.vtid#
/

