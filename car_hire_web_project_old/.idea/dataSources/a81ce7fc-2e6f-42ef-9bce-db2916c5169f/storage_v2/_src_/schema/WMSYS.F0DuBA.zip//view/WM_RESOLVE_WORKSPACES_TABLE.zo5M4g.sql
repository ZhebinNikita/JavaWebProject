create view WM$RESOLVE_WORKSPACES_TABLE as
  select wt.workspace, rwt.resolve_user, rwt.undo_sp# undo_sp_ver,
       decode(bitand(rwt.wm$flag, 7), 0, null, 1, '1WRITER', 2, '1WRITER_SESSION', 3, 'NO_ACCESS', 4, 'READ_ONLY', 5, 'WM_ONLY') oldfreezemode,
       rwt.oldfreezewriter
from wmsys.wm$resolve_workspaces_table$ rwt, wmsys.wm$workspaces_table$i wt
where rwt.workspace# = wt.workspace_lock_id
/

