create trigger WM$CP_U_TRIG
  instead of update
  on WM$COLUMN_PROPS
  for each row
  declare
  sqlstr  varchar2(32000) ;
  flag_v integer := 0;
  vtid   integer := wmsys.ltUtil.getVtid(:new.owner, :new.table_name) ;
begin
  if (updating('IDENTITY_TYPE')) then
    flag_v := wmsys.owm_dml_pkg.wm$column_props$f(:new.identity_type) ;
    sqlstr := sqlstr || ' wm$flag=wmsys.ltUtil.bitor(wmsys.ltUtil.bitclear(wm$flag, 98304), :1)' ;
  end if ;

  if (sqlstr is not null) then
    execute immediate
      'begin
         if (1=2 and (:1 is null or :2 is null)) then
           null ;
         end if;

         update wmsys.wm$versioned_tables$
         set ' || substr(sqlstr, 2) || '
         where vtid#=:2 ;
       end;' using flag_v, vtid ;
  end if ;
end;
/

