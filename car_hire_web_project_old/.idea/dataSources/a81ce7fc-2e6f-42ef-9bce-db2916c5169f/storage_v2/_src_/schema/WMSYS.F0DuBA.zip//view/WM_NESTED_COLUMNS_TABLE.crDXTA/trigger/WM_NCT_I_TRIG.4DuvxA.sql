create trigger WM$NCT_I_TRIG
  instead of insert
  on WM$NESTED_COLUMNS_TABLE
  for each row
  declare
  flag_v integer := 0;
  vtid   integer := wmsys.ltUtil.getVtid(:new.owner, :new.table_name) ;
begin
  insert into wmsys.wm$nested_columns_table$(vtid#, column_name, position, type_owner, type_name, nt_owner, nt_name, nt_store)
  values (vtid, :new.column_name, :new.position, :new.type_owner, :new.type_name, :new.nt_owner, :new.nt_name, :new.nt_store) ;
end;
/

