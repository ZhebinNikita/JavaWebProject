create trigger WM$VTH_NT_U_TRIG
  instead of update
  on WM$VERSIONED_TABLES$H
  for each row
  begin
  update table (select undo_code from wmsys.wm$versioned_tables$ where owner=:parent.owner and table_name=:parent.table_name)
  set sql_str = :new.sql_str
  where index_type  = index_type and
        index_field = index_field ;
end;
/

