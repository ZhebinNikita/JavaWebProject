create view WM$WORKSPACE_SESSIONS_VIEW as
  select st.username, wt.workspace, st.sid, st.serial#, st.saddr, st.inst_id, decode(dl.lmode, 2, 'SS', 4, 'S', 'U') lockMode, 0 isImplicit
  from gv$lock dl, wmsys.wm$workspaces_table$i wt, gv$session st
  where dl.type = 'UL' and
        dl.id1 - 1 = wt.workspace_lock_id and
        dl.sid = st.sid and
        dl.inst_id = st.inst_id
 union all
  select st.username, cast(wmsys.ltadm.GetSystemParameter('DEFAULT_WORKSPACE') as varchar2(128)), st.sid, st.serial#, st.saddr, st.inst_id, 'S', 1
  from gv$session st
  where st.username is not null and
        not exists(select 1
                   from gv$lock dl, wmsys.wm$workspaces_table$i wt
                   where dl.type = 'UL' and
                         dl.lmode = 4 and
                         dl.id1 - 1 = wt.workspace_lock_id and
                         dl.sid = st.sid and
                         dl.inst_id = st.inst_id)
WITH READ ONLY
/

