create type       wm$nextver_exp_tab_type as table of wmsys.wm$nextver_exp_type
/

