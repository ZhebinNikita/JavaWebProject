create view WM$ENV_VARS as
  select ev.name,
       ev.value,
       decode(bitand(ev.wm$flag, 1), 0, 0, 1, 1) hidden
from wmsys.wm$env_vars$ ev
/

