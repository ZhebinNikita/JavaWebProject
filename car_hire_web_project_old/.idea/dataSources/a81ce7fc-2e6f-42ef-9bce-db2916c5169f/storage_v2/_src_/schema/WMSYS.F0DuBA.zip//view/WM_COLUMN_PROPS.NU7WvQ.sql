create view WM$COLUMN_PROPS as
  select vt.owner,
       vt.table_name,
       (select column_name
        from sys.dba_tab_cols dtc
        where dtc.owner = vt.owner and
              dtc.table_name = vt.table_name and
              dtc.user_generated = 'YES' and
              dtc.identity_column = 'YES') column_name,
       vt.identity_type
from wmsys.wm$versioned_tables vt
where vt.identity_type is not null
/

