create view ALL_WORKSPACES_INTERNAL as
  select s.workspace, s.parent_workspace, s.current_version, s.parent_version, s.post_version, s.verlist, s.owner, s.createTime,
        s.description, s.workspace_lock_id, s.freeze_status, s.freeze_mode, s.freeze_writer, s.oper_status, s.wm_lockmode, s.isRefreshed,
        s.freeze_owner, s.session_duration, s.mp_root
 from wmsys.wm$workspaces_table$i s
 where exists (select 1 from wmsys.user_wm_privs where privilege = 'WM_ADMIN' or privilege like '%ANY%')
 union
 select s.workspace, s.parent_workspace, s.current_version, s.parent_version, s.post_version, s.verlist, s.owner, s.createTime,
        s.description, s.workspace_lock_id, s.freeze_status, s.freeze_mode, s.freeze_writer, s.oper_status, s.wm_lockmode, s.isRefreshed,
        s.freeze_owner, s.session_duration, s.mp_root
 from wmsys.wm$workspaces_table$i s,
      (select distinct workspace from wmsys.user_wm_privs) u
 where u.workspace = s.workspace
union
 select s.workspace, s.parent_workspace, s.current_version, s.parent_version, s.post_version, s.verlist, s.owner, s.createTime,
        s.description, s.workspace_lock_id, s.freeze_status, s.freeze_mode, s.freeze_writer, s.oper_status, s.wm_lockmode, s.isRefreshed,
        s.freeze_owner, s.session_duration, s.mp_root
from wmsys.wm$workspaces_table$i s where owner = sys_context('userenv', 'current_user')
WITH READ ONLY
/

