create trigger WM$EI_I_TRIG
  instead of insert
  on WM$EVENTS_INFO
  for each row
  declare
  flag_v integer := 0;
begin
  flag_v := wmsys.owm_dml_pkg.wm$events_info$f(:new.capture) ;

  insert into wmsys.wm$events_info$(event_name, wm$flag)
  values (:new.event_name, flag_v) ;
end;
/

