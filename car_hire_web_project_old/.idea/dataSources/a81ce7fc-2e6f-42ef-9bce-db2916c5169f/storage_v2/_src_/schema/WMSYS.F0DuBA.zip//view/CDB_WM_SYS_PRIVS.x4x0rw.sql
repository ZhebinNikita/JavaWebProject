create view CDB_WM_SYS_PRIVS as
  SELECT k."GRANTEE",k."PRIVILEGE",k."GRANTOR",k."GRANTABLE",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("WMSYS"."DBA_WM_SYS_PRIVS") k
/

comment on table CDB_WM_SYS_PRIVS
is ' in all containers'
/

