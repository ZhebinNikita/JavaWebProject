create trigger WM$LI_I_TRIG
  instead of insert
  on WM$LOCKROWS_INFO
  for each row
  declare
  flag_v integer := 0;
  ws#    integer := wmsys.ltUtil.getWorkspaceLockId(:new.workspace) ;
  vtid   integer := wmsys.ltUtil.getVtid(:new.owner, :new.table_name) ;
begin
  insert into wmsys.wm$lockrows_info$(workspace#, vtid#, where_clause)
  values (ws#, vtid, :new.where_clause) ;
end;
/

