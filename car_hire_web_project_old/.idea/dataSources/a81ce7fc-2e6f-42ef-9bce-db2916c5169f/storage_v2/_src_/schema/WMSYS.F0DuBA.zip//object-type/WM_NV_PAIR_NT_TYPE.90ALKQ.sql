create type       wm$nv_pair_nt_type                                                                       
        as table of WMSYS.WM$NV_PAIR_TYPE
/

