create view WM$CONS_COLUMNS as
  select vt.owner, cc.constraint_name, vt.table_name, cc.column_name, cc.position
from wmsys.wm$cons_columns$ cc, wmsys.wm$versioned_tables$ vt
where cc.vtid# = vt.vtid#
/

