create view WM$CURRENT_WORKSPACE_VIEW as
  select workspace, parent_workspace, current_version, post_version, verlist, owner, createtime, description,
       workspace_lock_id, freeze_status, freeze_mode, freeze_writer, oper_status, wm_lockmode, isrefreshed, freeze_owner,
       session_duration, implicit_sp_cnt, cr_status, sync_parver, last_change
from wmsys.wm$workspaces_table
where workspace = coalesce(sys_context('lt_ctx','state'), wmsys.ltUtil.getDefaultWorkspaceName)
WITH READ ONLY
/

