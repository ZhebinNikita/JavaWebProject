create view WM$EXP_MAP as
  select "CODE","NFIELD1","NFIELD2","NFIELD3","VFIELD1","VFIELD2","VFIELD3"
from table(wmsys.lt_export_pkg.export_mapping_view_func())
WITH READ ONLY
/

