create view WM$HASH_TABLE as
  select hash
from wmsys.wm$hash_table$ ht
/

