create trigger WM$VTH_I_TRIG
  instead of insert
  on WM$VERSIONED_TABLES$H
  for each row
  declare
  flag_v integer := 0;
begin
  flag_v := wmsys.owm_dml_pkg.wm$versioned_tables$f(:new.disabling_ver, :new.hist, :new.validtime, :new.bl_savepoint,
                                                    :new.bl_check_for_duplicates, :new.bl_single_transaction, null) ;

  insert into wmsys.wm$versioned_tables$(vtid#, table_name, owner, ricweight, pkey_cols, undo_code, bl_version, wm$flag)
  values (:new.vtid, :new.table_name, :new.owner, :new.ricweight, :new.pkey_cols, :new.undo_code, :new.bl_version, flag_v) ;
end;
/

