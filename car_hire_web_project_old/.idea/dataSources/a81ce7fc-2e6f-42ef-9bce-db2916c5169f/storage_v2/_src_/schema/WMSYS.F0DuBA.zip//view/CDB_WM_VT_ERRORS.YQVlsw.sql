create view CDB_WM_VT_ERRORS as
  SELECT k."OWNER",k."TABLE_NAME",k."STATE",k."SQL_STR",k."STATUS",k."ERROR_MSG",k."CON_ID", k.CON$NAME, k.CDB$NAME FROM CONTAINERS("WMSYS"."DBA_WM_VT_ERRORS") k
/

comment on table CDB_WM_VT_ERRORS
is ' in all containers'
/

