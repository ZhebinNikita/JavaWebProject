create trigger WM$UD_U_TRIG
  instead of update
  on WM$UDTRIG_INFO
  for each row
  declare
  sqlstr  varchar2(32000) ;
  flag_v  integer := 0;
  vtid    integer := wmsys.ltUtil.getVtid(:new.table_owner_name, :new.table_name) ;
  trig_t  integer ;
  u_flag  boolean ;
begin
  if (updating('TRIG_FLAG') or updating('EVENT_FLAG')) then
    flag_v := wmsys.owm_dml_pkg.wm$udtrig_info$f(:new.trig_flag, :new.status, :new.internal_type, :new.event_flag) ;
    sqlstr := sqlstr || ' wm$flag=:1' ;
  end if ;

  if (updating('TRIG_PROCEDURE')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' proc#=:2' ;
  end if;

  if (updating('DESCRIPTION')) then
    sqlstr := sqlstr || (case when sqlstr is not null then ',' else null end) || ' description=:3' ;
  end if;

  if (sqlstr is not null) then
    execute immediate
      'begin
         if (1=2 and (:1 is null or :2 is null or :3 is null or :4 is null or :5 is null)) then
           null ;
         end if;

         update wmsys.wm$udtrig_info$
         set ' || substr(sqlstr, 2) || '
         where trig_owner_name=:4 and trig_name=:5;
       end;' using flag_v, regexp_substr(:new.trig_procedure, '[[:digit:]]+$'), :new.description, :old.trig_owner_name, :old.trig_name ;
  end if ;
end;
/

