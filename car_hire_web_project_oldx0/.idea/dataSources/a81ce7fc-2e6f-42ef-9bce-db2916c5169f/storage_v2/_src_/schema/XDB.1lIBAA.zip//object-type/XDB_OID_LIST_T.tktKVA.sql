create type     XDB$OID_LIST_T                                        AS varray(65535) of raw(16);
/

