create type     xdb$annotation_list_t                                        as
   varray(65535) of xdb.xdb$annotation_t;
/

