create type     xdb$appinfo_list_t                                        as varray(1000) of xdb.xdb$appinfo_t;
/

