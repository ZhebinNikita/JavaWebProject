create trigger "XDB$RESCONFIG$xd"
  after update or delete
  on XDB$RESCONFIG
  for each row
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, 'C62AB77875504497859780929F66DBFC' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, 'C62AB77875504497859780929F66DBFC', user ); END IF; END;
/

