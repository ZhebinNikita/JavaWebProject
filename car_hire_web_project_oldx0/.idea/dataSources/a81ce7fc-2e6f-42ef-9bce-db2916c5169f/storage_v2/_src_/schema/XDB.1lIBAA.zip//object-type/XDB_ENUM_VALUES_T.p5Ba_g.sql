create type     xdb$enum_values_t                                       
as VARRAY(1000) of varchar2(1024);
/

