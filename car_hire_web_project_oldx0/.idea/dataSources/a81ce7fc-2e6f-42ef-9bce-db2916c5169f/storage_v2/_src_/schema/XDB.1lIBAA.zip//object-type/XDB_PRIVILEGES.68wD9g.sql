create type     xdb_privileges                                       
as varray(1000) of VARCHAR2(200)
/

