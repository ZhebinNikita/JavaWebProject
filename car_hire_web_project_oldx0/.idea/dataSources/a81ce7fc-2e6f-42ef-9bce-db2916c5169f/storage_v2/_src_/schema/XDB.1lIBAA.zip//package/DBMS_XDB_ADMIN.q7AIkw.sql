create PACKAGE     dbms_xdb_admin AUTHID CURRENT_USER IS

--------
PRAGMA SUPPLEMENTAL_LOG_DATA(default, UNSUPPORTED_WITH_COMMIT);

---------------------------------------------
-- PROCEDURE - CreateNonceKey
--     Insert the randomly generated nonce key into XDB$NONCEKEY table
-- NOTE: Should be called by DBA only, thus in this package
---------------------------------------------
procedure CreateNonceKey;

---------------------------------------------
-- PROCEDURE - movexdb_tablespace
--     Moves xdb in the specified tablespace. The move waits for all
--     concurrent XDB sessions to exit.
-- PARAMETERS - name of the tablespace where xdb is to be moved.
--            - trace: if TRUE, use set serveroutput on to display
--                     progress status information; default FALSE
--
---------------------------------------------
PROCEDURE movexdb_tablespace(new_tablespace IN VARCHAR2,
                             trace IN BOOLEAN := FALSE);

---------------------------------------------
-- PROCEDURE - RebuildHierarchicalIndex
--     Rebuilds the hierarchical Index; Used after
--     imp/exp since we do cannot export data from
--     xdb$h_index table since it contains rowids
-- PARAMETERS -
--
---------------------------------------------
PROCEDURE RebuildHierarchicalIndex;

-------------------------------------------------------------------------------
-- FUNCTION - installDefaultWallet
--    Install a certificate in the default xdb the wallet stored in
--    the default XDB wallet directory.
--    Directory name where the XDB wallet is stored is prefixed either
--    by ORACLE_BASE when it is defined else ORACLE_HOME.
--    Then it is followed by "/admin/<db_name>/xdb_wallet" where <db_name>
--    is the unique database name.
--    This function can be called if the xdb self-sign on and auto-login wallet
--    installed in the default location or if the existing one expired.
--
-- PARAMETERS
--    None
--
-- NOTE
--    - Only sys can intall/replace the default wallet
--    - This function replaces the wallet if one exists in the default
--      xdb wallet location.
--    - Two files are expected to be created in the default location:
--        - cwallet.sso
--        - ewallet.p12
-------------------------------------------------------------------------------
procedure installDefaultWallet;

end dbms_xdb_admin;
/

