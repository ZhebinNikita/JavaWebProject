create trigger "XDB$ACL$xd"
  after update or delete
  on XDB$ACL
  for each row
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$ACL', :old.sys_nc_oid$, 'B395078B20C14CA6BE401DF9EDF18ABE' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$ACL', :old.sys_nc_oid$, 'B395078B20C14CA6BE401DF9EDF18ABE', user ); END IF; END;
/

