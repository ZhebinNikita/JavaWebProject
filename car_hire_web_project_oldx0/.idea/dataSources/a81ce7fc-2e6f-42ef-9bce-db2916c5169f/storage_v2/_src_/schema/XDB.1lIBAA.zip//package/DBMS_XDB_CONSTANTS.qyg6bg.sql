create PACKAGE     DBMS_XDB_CONSTANTS authid CURRENT_USER AS

  C_UTF8_ENCODING              constant VARCHAR2(32)
                  := 'AL32UTF8';
  C_WIN1252_ENCODING           constant VARCHAR2(32)
                  := 'WE8MSWIN1252';
  C_ISOLATIN1_ENCODING         constant VARCHAR2(32)
                  := 'WE8ISO8859P1';
  C_DEFAULT_ENCODING           constant VARCHAR2(32)
                  := C_UTF8_ENCODING;
  C_ORACLE_NAMESPACE           constant VARCHAR2(128)
                  := 'http://xmlns.oracle.com';
  C_ORACLE_XDB_NAMESPACE       constant VARCHAR2(128)
                  := C_ORACLE_NAMESPACE || '/xdb';
  C_XDBSCHEMA_NAMESPACE        constant VARCHAR2(128)
                  := C_ORACLE_XDB_NAMESPACE || '/XDBSchema.xsd';
  C_RESOURCE_NAMESPACE         constant VARCHAR2(128)
                  := C_ORACLE_XDB_NAMESPACE || '/XDBResource.xsd';
  C_ACL_NAMESPACE              constant VARCHAR2(128)
                  := C_ORACLE_XDB_NAMESPACE || '/acl.xsd';
  C_XMLSCHEMA_NAMESPACE        constant VARCHAR2(128)
                  := 'http://www.w3.org/2001/XMLSchema';
  C_XMLINSTANCE_NAMESPACE      constant VARCHAR2(128)
                  := 'http://www.w3.org/2001/XMLSchema-instance';
  C_RESOURCE_PREFIX_R          constant VARCHAR2(128)
                  := 'xmlns:r="'   || C_RESOURCE_NAMESPACE    || '"';
  C_ACL_PREFIX_ACL             constant VARCHAR2(128)
                  := 'xmlns:acl="' || C_ACL_NAMESPACE         || '"';
  C_XDBSCHEMA_PREFIX_XDB       constant VARCHAR2(128)
                  := 'xmlns:xdb="' || C_ORACLE_XDB_NAMESPACE  || '"';
  C_XMLSCHEMA_PREFIX_XSD       constant VARCHAR2(128)
                  := 'xmlns:xsd="' || C_XMLSCHEMA_NAMESPACE   || '"';
  C_XMLINSTANCE_PREFIX_XSI     constant VARCHAR2(128)
                  := 'xmlns:xsi="' || C_XMLINSTANCE_NAMESPACE || '"';
  C_XDBSCHEMA_LOCATION         constant VARCHAR2(128)
                  := C_ORACLE_XDB_NAMESPACE || '/XDBSchema.xsd';
  C_XDBCONFIG_LOCATION         constant VARCHAR2(128)
                  := C_ORACLE_XDB_NAMESPACE ||  '/xdbconfig.xsd';
  C_ACL_LOCATION               constant VARCHAR2(128)
                  := C_ORACLE_XDB_NAMESPACE || '/acl.xsd';
  C_RESOURCE_LOCATION          constant VARCHAR2(128)
                  := C_ORACLE_XDB_NAMESPACE || '/XDBResource.xsd';
  C_BINARY_CONTENT             constant VARCHAR2(128)
                  := C_XDBSCHEMA_LOCATION  || '#binary';
  C_TEXT_CONTENT               constant VARCHAR2(128)
                  := C_XDBSCHEMA_LOCATION  || '#text';
  C_ACL_CONTENT                constant VARCHAR2(128)
                  := C_ACL_LOCATION     || '#acl';
  C_XDBSCHEMA_PREFIXES         constant VARCHAR2(256)
                  := C_XMLSCHEMA_PREFIX_XSD || ' ' || C_XDBSCHEMA_PREFIX_XDB;
  C_EXIF_NAMESPACE             constant VARCHAR2(128)
                  := C_ORACLE_NAMESPACE || '/ord/meta/exif';
  C_IPTC_NAMESPACE             constant VARCHAR2(128)
                  := C_ORACLE_NAMESPACE || '/ord/meta/iptc';
  C_DICOM_NAMESPACE            constant VARCHAR2(128)
                  := C_ORACLE_NAMESPACE || '/ord/meta/dicomImage';
  C_ORDIMAGE_NAMESPACE         constant VARCHAR2(128)
                  := C_ORACLE_NAMESPACE || '/ord/meta/ordimage';
  C_XMP_NAMESPACE              constant VARCHAR2(128)
                  := C_ORACLE_NAMESPACE || '/ord/meta/xmp';
  C_XDBCONFIG_NAMESPACE        constant VARCHAR2(128)
                  := C_ORACLE_XDB_NAMESPACE ||  '/xdbconfig.xsd';
  C_EXIF_PREFIX_EXIF           constant VARCHAR2(128)
                  := 'xmlns:exif="'  || C_EXIF_NAMESPACE     || '"';
  C_IPTC_PREFIX_IPTC           constant VARCHAR2(128)
                  := 'xmlns:iptc="'  || C_IPTC_NAMESPACE     || '"';
  C_DICOM_PREFIX_DICOM         constant VARCHAR2(128)
                  := 'xmlns:dicom="' || C_DICOM_NAMESPACE    || '"';
  C_ORDIMAGE_PREFIX_ORD        constant VARCHAR2(128)
                  := 'xmlns:ord="'   || C_ORDIMAGE_NAMESPACE || '"';
  C_XMP_PREFIX_XMP             constant VARCHAR2(128)
                  := 'xmlns:xmp="'   || C_XMP_NAMESPACE      || '"';
  C_RESOURCE_CONFIG_NAMESPACE  constant VARCHAR2(128)
                  := C_ORACLE_XDB_NAMESPACE || '/XDBResConfig.xsd';
  C_XMLDIFF_NAMESPACE          constant VARCHAR2(128)
                  := C_ORACLE_XDB_NAMESPACE || '/xdiff.xsd';
  C_RESOURCE_CONFIG_PREFIX_RC  constant VARCHAR2(128)
                  := 'xmlns:rc="' || C_RESOURCE_CONFIG_NAMESPACE || '"';
  C_XMLDIFF_PREFIX_XD          constant VARCHAR2(128)
                  := 'xmlns:xd="' || C_XMLDIFF_NAMESPACE        || '"';
  C_NSPREFIX_XDBCONFIG_CFG     constant VARCHAR2(128)
                  := 'xmlns:cfg="' || C_XDBCONFIG_NAMESPACE        || '"';

  C_GROUP        constant VARCHAR2(32) := 'group';
  C_ELEMENT      constant VARCHAR2(32) := 'element';
  C_ATTRIBUTE    constant VARCHAR2(32) := 'attribute';
  C_COMPLEX_TYPE constant VARCHAR2(32) := 'complexType';

function ENCODING_UTF8        return varchar2 deterministic;
--        returns 'AL32UTF8'

function ENCODING_ISOLATIN1        return varchar2 deterministic;
--        returns 'WE8ISO8859P1'

function ENCODING_WIN1252     return varchar2 deterministic;
--        returns 'WE8MSWIN1252'

function ENCODING_DEFAULT     return varchar2 deterministic;
--        returns 'AL32UTF8'

function NAMESPACE_ORACLE_XDB        return varchar2 deterministic;
--        returns 'http://xmlns.oracle.com/xdb'

function NAMESPACE_RESOURCE          return varchar2 deterministic;
--        returns ' http://xmlns.oracle.com/xdb/XDBResource.xsd

function NAMESPACE_XDBSCHEMA          return varchar2 deterministic;
--        returns ' http://xmlns.oracle.com/xdb/XDBSchema.xsd

function NAMESPACE_ACL               return varchar2 deterministic;
--          returns ' http://xmlns.oracle.com/xdb/acl.xsd'

function NAMESPACE_ORACLE         return varchar2 deterministic;
--        returns 'http://xmlns.oracle.com'

function NAMESPACE_XMLSCHEMA         return varchar2 deterministic;
--        returns 'http://www.w3.org/2001/XMLSchema'

function NAMESPACE_XMLINSTANCE       return varchar2 deterministic;
--        returns 'http://www.w3.org/2001/XMLSchema-instance'

function NAMESPACE_RESOURCE_CONFIG   return varchar2 deterministic;
--           returns 'http://xmlns.oracle.com/xdb/XDBResConfig.xsd'

function NAMESPACE_XMLDIFF           return varchar2 deterministic;
--        returns 'http://xmlns.oracle.com/xdb/xdiff.xsd'

function NAMESPACE_XDBCONFIG          return varchar2 deterministic;
--        returns 'http://xmlns.oracle.com/xdb/xdbconfig.xsd'

function SCHEMAURL_XDBCONFIG          return varchar2 deterministic;
--        returns 'http://xmlns.oracle.com/xdb/xdbconfig.xsd'

function NSPREFIX_RESOURCE_R         return varchar2 deterministic;
--        returns 'xmlns:r="http://xmlns.oracle.com/XDBResource.xsd"'

function NSPREFIX_ACL_ACL              return varchar2 deterministic;
--        returns 'xmlns:acl= 'http://xmlns.oracle.com/acl.xsd"'

function NSPREFIX_XDB_XDB        return varchar2 deterministic;
--        returns 'xmlns:xdb= $B!H(Bhttp://xmlns.oracle.com/xdb" '

function NSPREFIX_XMLSCHEMA_XSD        return varchar2 deterministic;
--        returns 'xmlns:xsd="http://www.w3.org/2001/XMLSchema"'

function NSPREFIX_XMLINSTANCE_XSI      return varchar2 deterministic;
--        returns 'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '

function NSPREFIX_RESCONFIG_RC   return varchar2 deterministic;
--        returns 'xmlns:rc="' || NAMESPACE_RESOURCE_CONFIG

function NSPREFIX_XMLDIFF_XD           return varchar2 deterministic;
--        returns  xmlns:xd="' || NAMESPACE_XMLDIFF

function NSPREFIX_XDBCONFIG_CFG        return varchar2 deterministic;
--        returns xmlns:cfg="http://xmlns.oracle.com/xdb/xdbconfig.xsd"

function SCHEMAURL_XDBSCHEMA          return varchar2 deterministic;
--        returns 'http://xmlns.oracle.com/xdb/XDBSchema.xsd';

function SCHEMAURL_ACL                return varchar2 deterministic;
--        returns 'http://xmlns.oracle.com/xdb/acl.xsd';

function SCHEMAURL_RESOURCE           return varchar2 deterministic;
--        returns 'http://xmlns.oracle.com/xdb/XDBResource.xsd';

function SCHEMAELEM_RESCONTENT_BINARY              return varchar2 deterministic;
--        returns SCHEMAURL_XDBSCHEMA || '#binary'

function SCHEMAELEM_RESCONTENT_TEXT                return varchar2 deterministic;
--        returns SCHEMAURL_XDBSCHEMA || '#text'

function SCHEMAELEM_RES_ACL                 return varchar2 deterministic;
--        returns SCHEMAURL_XDBSCHEMA || '#acl'

function XSD_GROUP             return VARCHAR2 deterministic;
--        returns 'group'

function XSD_ELEMENT           return VARCHAR2 deterministic;
--        returns 'element'

function XSD_ATTRIBUTE         return VARCHAR2 deterministic;
--        returns 'attribute'

function XSD_COMPLEX_TYPE      return VARCHAR2 deterministic;
--        returns 'complexType'

function XDBSCHEMA_PREFIXES  return VARCHAR2 deterministic;
--        returns  DBMS_XDB_CONSTANTS.PREFIX_DEF_XDB || ' ' ||
--                 DBMS_XDB_CONSTANTS.PREFIX_DEF_XMLSCHEMA

END DBMS_XDB_CONSTANTS;
/

