create type     path_array                                       
as varray(32000) of xdb.path_linkinfo
/

