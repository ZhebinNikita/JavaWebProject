create trigger "XDB$STATS$xd"
  after update or delete
  on XDB$STATS
  for each row
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$STATS', :old.sys_nc_oid$, 'AA4B936ED0914BFC891CD3171BAE218F' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$STATS', :old.sys_nc_oid$, 'AA4B936ED0914BFC891CD3171BAE218F', user ); END IF; END;
/

