create package body     XMLIndex_FUNCIMPL as
  function xmlindex_noop(res sys.xmltype,
                         pathstr varchar2,
                         ia sys.odciindexctx,
                         sctx IN OUT XDB.XMLIndexMethods,
                         sflg number)
  return number is
  begin
   return 0;
  end;
end;
/

