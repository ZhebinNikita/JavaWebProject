create TYPE vers_list IS VARRAY(5) OF NUMBER;
/

