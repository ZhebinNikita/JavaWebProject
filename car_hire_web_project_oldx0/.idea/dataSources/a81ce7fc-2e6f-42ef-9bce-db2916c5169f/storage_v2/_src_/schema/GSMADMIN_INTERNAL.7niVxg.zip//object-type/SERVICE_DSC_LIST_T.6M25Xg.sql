create TYPE service_dsc_list_t IS TABLE OF service_dsc_t;
/

