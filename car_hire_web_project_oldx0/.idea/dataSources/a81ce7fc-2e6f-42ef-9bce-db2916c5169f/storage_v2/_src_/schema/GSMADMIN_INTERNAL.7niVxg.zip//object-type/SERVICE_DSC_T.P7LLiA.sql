create type service_dsc_t force as object(
  service_name              varchar2(100),
  network_name              varchar2(512),
  rlb_goal                  number,
  clb_goal                  number,
  distr_trans               number,
  aq_notifications          number,
  lag_property              number,
  max_lag_value             number,
  failover_method           varchar2(64),
  failover_type             varchar2(64),
  failover_retries          number,
  failover_delay            number,
  edition                   varchar2(128),
  pdb                       varchar2(128),
  commit_outcome            number,
  retention_timeout         number,
  replay_initiation_timeout number,
  session_state_consistency varchar2(128),
  sql_translation_profile   varchar2(261),
  locality                  number,
  region_failover           number,
  role                      number,
  network_number            number,
  server_pool               varchar2(128),
  cardinality               number,

  proxy_db                  number,
  to_be_started             number,
  do_modify_local           number,
  instances                 varchar2(4000),
  -- This parameter specifies the proxy service.
  is_public                 number,
  aq_ha_notifications       number,
  drain_timeout             number,
  stop_option               varchar2(13),
  CONSTRUCTOR FUNCTION service_dsc_t (SELF IN OUT NOCOPY service_dsc_t,
                                      name VARCHAR2)
                                     RETURN SELF AS RESULT
);
/

