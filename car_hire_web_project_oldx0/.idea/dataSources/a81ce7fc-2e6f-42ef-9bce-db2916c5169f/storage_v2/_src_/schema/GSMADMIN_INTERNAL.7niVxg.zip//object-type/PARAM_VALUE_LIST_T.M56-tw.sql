create TYPE param_value_list_t IS TABLE OF param_value_t;
/

