create view LOCAL_CHUNK_TYPES as
  select
  TF.FAMILY_ID, GT.TABLE_NAME, GT.SCHEMA_NAME,
  decode(TF.PARTITION_SET_TYPE, 1, 'RANGE', 2, 'HASH', 4, 'LIST', 'NONE'),
  (select count(1) from SHARDKEY_COLUMNS PK where PK.FAMILY_ID = TF.FAMILY_ID and PK.KEY_LEVEL = 0),
  decode(TF.SHARD_TYPE, 1, 'RANGE', 2, 'HASH', 4, 'LIST', 'NONE'),
  (select count(1) from SHARDKEY_COLUMNS PK where PK.FAMILY_ID = TF.FAMILY_ID and PK.KEY_LEVEL = 1),
  D.ddlid, dbms_gsm_common.getDBParameterStr('_shardgroup_name', 1)
from
  GLOBAL_TABLE GT, TABLE_FAMILY TF, DDLID$ D
where GT.REF_TABLE_FLAG = 'R' AND
  TF.FAMILY_ID = GT.FAMILY_ID
with read only
/

