create TYPE name_list IS TABLE OF VARCHAR2(128)
/

