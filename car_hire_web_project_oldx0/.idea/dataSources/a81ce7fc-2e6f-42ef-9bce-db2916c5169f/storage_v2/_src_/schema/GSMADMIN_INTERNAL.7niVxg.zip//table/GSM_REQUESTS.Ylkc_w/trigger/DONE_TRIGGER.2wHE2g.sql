create trigger DONE_TRIGGER
  after update of STATUS
  on GSM_REQUESTS
  for each row
  when (new.status = 'D')
  dbms_gsm_pooladmin.requestDone(:old.request, :new.status);
/

