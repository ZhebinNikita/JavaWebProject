create TYPE vers_lookup_t IS TABLE OF vers_lookup_rec;
/

