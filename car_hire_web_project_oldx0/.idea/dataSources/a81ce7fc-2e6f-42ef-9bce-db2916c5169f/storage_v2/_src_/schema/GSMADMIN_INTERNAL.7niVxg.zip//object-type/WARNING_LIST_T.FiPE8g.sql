create TYPE warning_list_t IS TABLE OF warning_t;
/

