create TYPE shard_list_t IS TABLE OF shard_t;
/

