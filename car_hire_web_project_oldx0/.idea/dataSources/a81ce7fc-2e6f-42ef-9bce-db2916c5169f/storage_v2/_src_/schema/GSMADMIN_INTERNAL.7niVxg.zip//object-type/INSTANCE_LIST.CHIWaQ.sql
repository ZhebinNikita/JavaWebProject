create TYPE instance_list IS TABLE OF rac_instance_t
/

