create TYPE service_list_t IS TABLE OF service_t;
/

