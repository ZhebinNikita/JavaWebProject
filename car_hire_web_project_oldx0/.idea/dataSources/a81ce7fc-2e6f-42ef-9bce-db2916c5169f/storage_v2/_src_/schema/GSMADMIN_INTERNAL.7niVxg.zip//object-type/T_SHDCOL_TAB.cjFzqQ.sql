create TYPE t_shdcol_tab IS TABLE OF t_shdcol_row
/

