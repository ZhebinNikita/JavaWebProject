create TYPE message_param is OBJECT (param_string varchar2(400));
/

