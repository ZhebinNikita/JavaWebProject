create TYPE region_list_t IS TABLE OF region_t;
/

