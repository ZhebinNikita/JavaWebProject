create TYPE gsm_list_t IS TABLE OF gsm_t;
/

