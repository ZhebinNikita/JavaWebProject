create TYPE number_list IS TABLE OF number
/

