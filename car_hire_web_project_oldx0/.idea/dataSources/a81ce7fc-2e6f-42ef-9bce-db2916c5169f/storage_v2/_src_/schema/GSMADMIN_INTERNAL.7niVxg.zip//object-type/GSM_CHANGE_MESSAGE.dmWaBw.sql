create TYPE gsm_change_message AS OBJECT (
   admin_id             NUMBER,
   change_id            NUMBER,
   seq#                 NUMBER,
   command              VARCHAR2(30),
   target               VARCHAR2(64),
   pool_name            VARCHAR2(30),     -- Only for pool admin actions
   additional_params    VARCHAR2(1024)    -- Additional parameters for the command
                                          -- Depends on the command and is not used
                                          -- for all commands.  Uses the same syntax
                                          -- as in the gsmctl command.  For example
                                          -- for START SERVICE may contain the
                                          -- database name:
                                          --        "-database db_name"
)
 ALTER TYPE gsm_change_message
   MODIFY ATTRIBUTE additional_params VARCHAR(4000) CASCADE
 ALTER TYPE gsm_change_message
   MODIFY ATTRIBUTE command           VARCHAR2(128) CASCADE
 ALTER TYPE gsm_change_message
   MODIFY ATTRIBUTE target            VARCHAR2(128) CASCADE
 ALTER TYPE gsm_change_message
   MODIFY ATTRIBUTE pool_name         VARCHAR2(128) CASCADE
/

