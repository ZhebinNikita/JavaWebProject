create TYPE rac_instance_t AS OBJECT (
    instance_name  VARCHAR2(30),
    pref_or_avail  CHAR(1)          -- 'P' (preferred)
                                    -- 'A' (available)
)
 ALTER TYPE rac_instance_t
   MODIFY ATTRIBUTE instance_name     VARCHAR2(128) CASCADE
/

