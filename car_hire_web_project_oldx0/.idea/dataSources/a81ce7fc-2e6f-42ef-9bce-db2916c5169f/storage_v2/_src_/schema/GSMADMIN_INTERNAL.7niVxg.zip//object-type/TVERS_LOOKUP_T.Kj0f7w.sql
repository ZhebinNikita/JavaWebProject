create TYPE tvers_lookup_t IS TABLE OF tvers_rec;
/

