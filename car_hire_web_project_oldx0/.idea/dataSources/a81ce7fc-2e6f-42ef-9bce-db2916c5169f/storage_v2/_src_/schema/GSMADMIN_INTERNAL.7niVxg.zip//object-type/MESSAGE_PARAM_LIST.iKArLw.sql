create TYPE message_param_list is varray(8) of message_param;
/

