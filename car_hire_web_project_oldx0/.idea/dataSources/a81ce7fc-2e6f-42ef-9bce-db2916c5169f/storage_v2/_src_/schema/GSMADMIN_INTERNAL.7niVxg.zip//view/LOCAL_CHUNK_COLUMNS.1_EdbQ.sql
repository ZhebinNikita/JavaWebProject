create view LOCAL_CHUNK_COLUMNS as
  select
  GT.FAMILY_ID, PK.KEY_LEVEL, PK.COL_NAME, COL_SEQ,
  c.type#, c.charsetid, c.type#, c.length
from
  SYS.COL$ c, SHARDKEY_COLUMNS PK, GLOBAL_TABLE GT
where
  c.NAME = PK.COL_NAME AND c.obj# = GT.TABLE_OBJ# AND GT.REF_TABLE_FLAG = 'R'
with read only
/

