create PACKAGE            MGMT_DB_LL_METRICS AS

TYPE GenericCurType IS REF CURSOR;
/*
This is the version of the livelink package.
Update this if there is any change in the PL/SQL.
Its read by the configVersion.pl script to obtain the installed version
of the PL/SQL.
*/
ORACLE_DATABASE_META_VER CONSTANT VARCHAR(17) := '10.3.7.0.2';
VERSION_817 CONSTANT VARCHAR(3) := '817';
VERSION_9i CONSTANT VARCHAR(3) := '9i';
VERSION_9iR2 CONSTANT VARCHAR(4) := '9iR2';
VERSION_10gR1 CONSTANT VARCHAR(5) := '10gR1';
VERSION_10gR2 CONSTANT VARCHAR(5) := '10gR2';
VERSION_11gR1 CONSTANT VARCHAR(5) := '11gR1';
VERSION_11gR2 CONSTANT VARCHAR(5) := '11gR2';
VERSION_12gR1 CONSTANT VARCHAR(5) := '12gR1';
VERSION_12gR2 CONSTANT VARCHAR(5) := '12gR2';
MIN_SUPPORTED_VERSION CONSTANT VARCHAR2(10) := '08.1.7.0.0';
/*
	Not Supported Version
*/
NOT_SUPPORTED_VERSION CONSTANT VARCHAR(3) := 'NSV';
/*
	Higher Supported Version
*/
HIGHER_SUPPORTED_VERSION CONSTANT VARCHAR(3) := 'HSV';

/*
Puts the config data into the file
By default, this procedure does not raise an exception.
To raise an exception, pass "raise_exp" as TRUE.
*/
procedure collect_config_metrics(directory_location IN VARCHAR2,
  raise_exp BOOLEAN DEFAULT FALSE);

/*
Write some DB info to a file (for RAC discovery/ADR info collection)
By default, this procedure does not raise an exception.
To raise an exception, pass "raise_exp" as TRUE.
*/
procedure write_db_ccr_file(directory_location IN VARCHAR2,
  raise_exp BOOLEAN DEFAULT FALSE);

/*
Puts the statistics config data into the file
By default, this procedure does not raise an exception.
To raise an exception, pass "raise_exp" as TRUE.
*/
procedure collect_stats_metrics(directory_location IN VARCHAR2,
  raise_exp BOOLEAN DEFAULT FALSE);

/*
 Compute the version category
*/
FUNCTION get_version_category RETURN VARCHAR2;

END MGMT_DB_LL_METRICS;
/

