create type bsln_variance_set as table of bsln_variance_t;
/

